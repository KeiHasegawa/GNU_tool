#include "version.h"
const char version[] = "10.2";
const char host_name[] = "i686-pc-linux-gnu";
const char target_name[] = "csky-elf";
