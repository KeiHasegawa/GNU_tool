#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia csky_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void csky_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t csky_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn == 72)
    return cpu->pc;
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  asm("int3");
  return 0;
}

extern "C"
int csky_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { csky_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void csky_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn == 72) {
    cpu->pc = v;
    return;
  }
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  asm("int3");
}

extern "C"
int csky_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  csky_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void lrw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn & 0x7f;
  auto rel = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto addr = cia + (rel << 2);
  addr &= ~3;
  cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  cpu->pc += 4;
}

static void lrw2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 5) & 7;
  int rel = insn & 0x1f;
  rel |= ((insn >> 8) & 15) << 5;
  auto addr = cia + (rel << 2);
  addr &= ~3;
  cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  cpu->pc += 2;
}

static void bsr(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int32_t rel = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  rel |= (insn & 3) << 16;
  rel <<= 17;
  rel >>= 16;
  auto addr = cia + rel;
  cpu->pc = addr;
  cpu->r[15] = cia + 4;
}

static void
subi14(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int imm = (((insn >> 8) & 3) << 7) | ((insn & 0x1f) << 2);
  if ((insn >> 5) & 1)
    cpu->r[14] = cpu->r[14] - imm;
  else
    cpu->r[14] = cpu->r[14] + imm;
  cpu->pc += 2;
}

static void stw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 5) & 15;
  int m = insn & 15;
  int off = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  off &= 0xfff;
  off <<= 2;
  uint32_t addr = cpu->r[m] + off;
  sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[n]);
  cpu->pc += 4;
}

static void ldw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 5) & 15;
  int m = insn & 15;
  int off = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  off &= 0xfff;
  off <<= 2;
  uint32_t addr = cpu->r[m] + off;
  cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  cpu->pc += 4;
}

static void stw2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int t = insn >> 8;
  int n = (t & 8) ? 14 : (t & 7);
  int m = (insn >> 5) & 7;
  int off = (insn & 0x1f) << 2;
  if (t & 8)
    off |= ((insn >> 8) & 7) << 7;
  uint32_t addr = cpu->r[n] + off;
  sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[m]);
  cpu->pc += 2;
}

static void stb2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 8) & 15;
  int m = (insn >> 5) & 7;
  int off = insn & 15;
  uint32_t addr = cpu->r[n] + off;
  sim_core_write_aligned_1(cpu, cia, write_map, addr, cpu->r[m]);
  cpu->pc += 2;
}

static void ldw2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 8) & 15;
  int m = (insn >> 5) & 7;
  int off = (insn & 15) << 2;
  uint32_t addr = cpu->r[n] + off;
  cpu->r[m] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  cpu->pc += 2;
}

static void mov(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 6) & 15;
  int m = (insn >> 2) & 15;
  cpu->r[n] = cpu->r[m];
  cpu->pc += 2;
}

static void addu(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 6) & 15;
  int m = (insn >> 2) & 15;
  cpu->r[n] += cpu->r[m];
  cpu->pc += 2;
}

static void movi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 8) & 15;
  int imm = insn & 0xff;
  cpu->r[n] = imm;
  cpu->pc += 2;
}

static void rts(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc = cpu->r[15];
}
    
static void subi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto tmp = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int n = (insn >> 5) & 15;
  int m = insn & 15;
  int imm = (tmp & 0xfff) + 1;
  cpu->r[n] = cpu->r[m] - imm;
  cpu->pc += 4;
}

static void movih(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int imm = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int n = insn & 0x1f;
  cpu->r[n] = imm << 16;
  cpu->pc += 4;
}

static void
op0xea(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  return (insn & 0x80) ? lrw(sd, cpu, insn, cia) : movih(sd, cpu, insn, cia);  
}

static void br(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int rel = insn & 0x7f;
  rel <<= 26;
  rel >>= 26;
  auto addr = cia + (rel << 1);
  cpu->pc = addr;
}

static void cmpne(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  assert((insn & 3) == 2);  // ne
  int n = (insn >> 2) & 15;
  int m = (insn >> 6) & 15;
  int32_t res = cpu->r[n] - cpu->r[m];
  if (res == 0)
    cpu->psr |= 1;
  else
    cpu->psr &= ~1;
  cpu->pc += 2;
}

static void jbf(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (cpu->psr & 1) {
    int rel = insn & 0x7f;
    rel <<= 26;
    rel >>= 26;
    auto addr = cia + (rel << 1);
    cpu->pc = addr;
  }
  else
    cpu->pc += 2;
}

static void addi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int imm = (insn & 0xff)+1;
  int n = (insn >> 8) & 15;
  cpu->r[n] += imm;
  cpu->pc += 2;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x0c] = jbf;
    (*this)[0x10] = lrw2;
    (*this)[0x12] = lrw2;
    (*this)[0x14] = subi14;
    (*this)[0x15] = subi14;
    (*this)[0x16] = subi14;
    (*this)[0x17] = subi14;
    (*this)[0x20] = addi;
    (*this)[0x21] = addi;
    (*this)[0x30] = movi;
    (*this)[0x31] = movi;
    (*this)[0x32] = movi;
    (*this)[0x33] = movi;
    (*this)[0x60] = addu;
    (*this)[0x64] = cmpne;
    (*this)[0x65] = cmpne;
    (*this)[0x6c] = mov;
    (*this)[0x6e] = mov;
    (*this)[0x6f] = mov;
    (*this)[0x78] = rts;
    (*this)[0x90] = ldw2;
    (*this)[0x91] = ldw2;
    (*this)[0x92] = ldw2;
    (*this)[0x93] = ldw2;
    (*this)[0x94] = ldw2;
    (*this)[0xa0] = stb2;
    (*this)[0xa3] = stb2;
    (*this)[0xb0] = stw2;
    (*this)[0xb1] = stw2;
    (*this)[0xb2] = stw2;
    (*this)[0xb3] = stw2;
    (*this)[0xb4] = stw2;
    (*this)[0xb5] = stw2;
    (*this)[0xb6] = stw2;
    (*this)[0xb7] = stw2;
    (*this)[0xb8] = stw2;
    (*this)[0xb9] = stw2;
    (*this)[0xba] = stw2;
    (*this)[0xbb] = stw2;
    (*this)[0xbc] = stw2;
    (*this)[0xbd] = stw2;
    (*this)[0xbe] = stw2;
    (*this)[0xbf] = stw2;
    (*this)[0xe0] = bsr;
    (*this)[0xe3] = bsr;
    (*this)[0xe4] = subi;
    (*this)[0xe5] = subi;
    (*this)[0xea] = op0xea;
    (*this)[0xd9] = ldw;
    (*this)[0xdc] = stw;
    (*this)[0xdd] = stw;
    (*this)[0x04] = br;
    (*this)[0x07] = br;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  auto p = table.find(insn >> 8);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
