#ifndef FR30_PROTOS_H
#define FR30_PROTOS_H

void fr30_expand_prologue();
void fr30_expand_epilogue();

const char* fr30_movsi(rtx x, rtx y);
const char* fr30_addsi3(rtx x, rtx y, rtx z);
const char* fr30_call_value(rtx x, rtx func);

const char* fr30_cbranch(rtx op);

#endif //  FR30_PROTOS_H
