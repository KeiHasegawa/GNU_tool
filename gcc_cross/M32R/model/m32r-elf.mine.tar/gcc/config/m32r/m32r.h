#ifndef M32R_H
#define M32R_H

#define REGISTER_NAMES \
  { "r0",  "r1",  "r2",  "r3",  "r4",  "r5", "r6",  "r7", \
    "r8",  "r9",  "r10", "r11", "r12", "fp", "lr",  "sp", \
    "dummy" }
#define FIXED_REGISTERS \
  {  0,     0,     0,     0,     1,     1,     1,     1,    \
     1,     1,     1,     1,     1,     1,     1,     1,    \
     1 }
#define CALL_USED_REGISTERS \
  {  1,     1,     1,     1,     1,     1,     1,     1,    \
     1,     1,     1,     1,     1,     1,     1,     1,    \
     1 }

#define       FRAME_POINTER_REGNUM    13
#define       ARG_POINTER_REGNUM      FRAME_POINTER_REGNUM
constexpr int LR_REGNUM             = 14;
constexpr int STACK_POINTER_REGNUM  = 15;
constexpr int DUMMY_REGNUM          = 16;
constexpr int FIRST_PSEUDO_REGISTER = 17;

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000 }, \
/* SPECIAL_REGS */	 { 0x0001e000 }, \
/* GENERAL_REGS */	 { 0x00001fff }, \
/* ALL_REGS */           { 0x0001ffff }}

constexpr int N_REG_CLASSES = (int)LIM_REG_CLASSES;

constexpr int UNITS_PER_WORD = 4;

typedef int CUMULATIVE_ARGS;
extern void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS&, tree, rtx, tree, int);

constexpr int MOVE_MAX = 4;

constexpr bool STRICT_ALIGNMENT = true;

constexpr bool BITS_BIG_ENDIAN  = false;
constexpr bool BYTES_BIG_ENDIAN = true;
constexpr bool WORDS_BIG_ENDIAN = true;

constexpr int FUNCTION_BOUNDARY = 4;

constexpr int TRAMPOLINE_SIZE = 4;

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("M32R")

constexpr int BIGGEST_ALIGNMENT = 8;

constexpr int ATTRIBUTE_ALIGNED_VALUE = 16;

constexpr auto Pmode = SImode;

constexpr int MAX_REGS_PER_ADDRESS = 1;

extern bool FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

constexpr int STACK_BOUNDARY = 8;

constexpr int PARM_BOUNDARY  = 8;

constexpr auto FUNCTION_MODE = QImode;

constexpr reg_class BASE_REG_CLASS = SPECIAL_REGS;

extern bool REGNO_OK_FOR_BASE_P(int);

extern reg_class REGNO_REG_CLASS(int);

constexpr bool SLOW_BYTE_ACCESS = false;

extern void ASM_OUTPUT_ALIGN(FILE*, int);

extern int FIRST_PARM_OFFSET(tree);

constexpr auto CASE_VECTOR_MODE = Pmode;

constexpr const char* ASM_APP_ON = "; Begin inline assembler code\n#APP\n";

constexpr const char* ASM_APP_OFF = "; End of inline assembler code\n#NO_APP\n";

extern void FUNCTION_PROFILER(FILE*, int);

extern bool REGNO_OK_FOR_INDEX_P(int);

constexpr auto INDEX_REG_CLASS = SPECIAL_REGS;

extern void INITIAL_ELIMINATION_OFFSET(int, int, poly_int64_pod&);

constexpr bool DEFAULT_SIGNED_CHAR = false;

extern void m32r_print_operand(FILE*, rtx, int);
#define PRINT_OPERAND m32r_print_operand

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, LR_REGNUM)

#endif // M32R_H
