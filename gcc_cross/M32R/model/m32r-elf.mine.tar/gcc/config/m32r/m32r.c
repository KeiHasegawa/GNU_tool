#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx m32r_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return gen_rtx_REG(mode, 0);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE m32r_function_value

bool m32r_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P m32r_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& nregs, tree fntype, rtx,
			  tree func, int)
{
  (void)fntype;
  (void)func;
  nregs = 0;
}

void m32r_function_arg_advance(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 4)
    ++*nregs;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE m32r_function_arg_advance

rtx m32r_function_incoming_arg(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 4)
    return gen_rtx_REG(arg.mode, *nregs);
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG m32r_function_incoming_arg

rtx m32r_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  return m32r_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG m32r_function_arg

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  return 0<= regno && regno <= 3;
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  return regno < FRAME_POINTER_REGNUM ? GENERAL_REGS : SPECIAL_REGS;
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 32;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  assert(from == FRAME_POINTER_REGNUM);
  assert(to == STACK_POINTER_REGNUM);
  offset = 0;
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  return y == frame_pointer_rtx;
}

void m32r_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  int offset;
  if (fp_rel(x, &offset)) {
    if (offset)
      fprintf(fp, "@(%d, fp)", offset);
    else
      fprintf(fp, "@(fp)");
    return;
  }
  if (SYMBOL_REF_P(x)) {
    auto s = XSTR(x, 0);
    assert(*s == '*');
    ++s;
    fprintf(fp, "%s", s);
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    assert(SYMBOL_REF_P(e0));
    auto s = XSTR(e0, 0);
    fprintf(fp, "%s", s);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

inline void push(rtx x)
{
  auto sp = stack_pointer_rtx;
  auto pd = gen_rtx_PRE_DEC(Pmode, sp);
  auto mem = gen_rtx_MEM(Pmode, pd);
  emit_move_insn(mem, x);
}

void m32r_expand_prologue()
{
  auto fp = frame_pointer_rtx;
  push(fp);
  auto lr = gen_rtx_REG(Pmode, LR_REGNUM);
  push(lr);
  auto sp = stack_pointer_rtx;  
  if (auto size = get_frame_size()) {
    auto minus = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
    emit_move_insn(sp, minus);
  }
  emit_move_insn(fp, sp);  
}

inline void pop(rtx x)
{
  auto sp = stack_pointer_rtx;
  auto pi = gen_rtx_POST_INC(Pmode, sp);
  auto mem = gen_rtx_MEM(Pmode, pi);
  emit_move_insn(x, mem);
}

void m32r_expand_epilogue()
{
  if (auto size = get_frame_size()) {
    auto sp = stack_pointer_rtx;  
    auto plus = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
    emit_move_insn(sp, plus);
  }
  auto lr = gen_rtx_REG(Pmode, LR_REGNUM);
  pop(lr);
  auto fp = frame_pointer_rtx;
  pop(fp);
  emit_jump_insn(ret_rtx);
}

const char* m32r_subsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y) && REGNO(x) == REGNO(y) && CONST_INT_P(z))
    return "addi	%0, #-%2";

  return "%0 := %1 - %2";
}

inline bool is_push(rtx x)
{
  if (!MEM_P(x))
    return false;
  if (GET_MODE(x) != Pmode)
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) != PRE_DEC)
    return false;
  auto z = XEXP(y, 0);
  return z == stack_pointer_rtx;
}

inline bool is_pop(rtx x)
{
  if (!MEM_P(x))
    return false;
  if (GET_MODE(x) != Pmode)
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) != POST_INC)
    return false;
  auto z = XEXP(y, 0);
  return z == stack_pointer_rtx;
}

const char* m32r_movsi(rtx x, rtx y)
{
  if (is_push(x) && REG_P(y))
    return "push	%1";

  if (REG_P(x) && is_pop(y))
    return "pop	%0";

  int offset;
  if (fp_rel(x, &offset) && REG_P(y))
    return "st	%1, %0";

  if (REG_P(x) && REG_P(y))
    return "mv	%0, %1";

  if (REG_P(x) && SYMBOL_REF_P(y))
    return "ld24	%0, #%1";

  if (REG_P(x) && CONST_INT_P(y))
    return "ldi	%0, #%1";

  return "%0 := %1";
}

inline void load(int regno, int offset)
{
  auto fp = reg_names[FRAME_POINTER_REGNUM];
  auto rn = reg_names[regno];
  if (offset)
    fprintf(asm_out_file, "	ld	%s, @(%d, %s)\n", rn, offset, fp);
  else
    fprintf(asm_out_file, "	ld	%s, @(%s)\n", rn, fp);
}

const char* m32r_addsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y) && REGNO(x) == REGNO(y) && CONST_INT_P(z))
    return "addi	%0, #%2";

  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int regno = REGNO(x);
    load(regno, offy);
    int scratch = regno + 1;
    load(scratch, offz);
    auto rn = reg_names[regno];
    auto sc = reg_names[scratch];
    fprintf(asm_out_file, "	add	%s, %s\n", rn, sc);
    return "";
  }
  
  return "%0 := %1 + %2";
}

const char* m32r_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && REGNO(x) == 0 && MEM_P(fun))
    return "bl	%1";

  return "%0 := call %1";
}

const char* m32r_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

bool m32r_function_value_regno_p(int regno)
{
  (void)regno;
  return false;
}
