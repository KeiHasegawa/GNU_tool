#ifndef M32R_PROTOS_H
#define M32R_PROTOS_H

void m32r_expand_prologue();
void m32r_expand_epilogue();
const char* m32r_subsi3(rtx x, rtx y, rtx z);
const char* m32r_movsi(rtx x, rtx y);
const char* m32r_addsi3(rtx x, rtx y, rtx z);
const char* m32r_call_value(rtx x, rtx fun);
	     
const char* m32r_cbranch(rtx op);

#endif //  M32R_PROTOS_H
