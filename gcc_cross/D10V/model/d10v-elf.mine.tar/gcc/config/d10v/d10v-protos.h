#ifndef D10V_PROTOS_H
#define D10V_PROTOS_H

void d10v_expand_prologue();
void d10v_expand_epilogue();
const char* d10v_movhi(rtx x, rtx y);
const char* d10v_addhi3(rtx x, rtx y, rtx z);
const char* d10v_subhi3(rtx x, rtx y, rtx z);
const char* d10v_call_value(rtx x, rtx fun);

const char* d10v_cbranch(rtx op);

#endif //  D10V_PROTOS_H
