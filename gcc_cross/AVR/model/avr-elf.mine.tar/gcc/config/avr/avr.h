#ifndef AVR_H
#define AVR_H

#define REGISTER_NAMES \
  { "r0", "r1",   "r2",  "r3",  "r4",  "r5",  "r6",  "r7",  \
    "r8",  "r9",  "r10", "r11", "r12", "r13", "r14", "r15", \
    "r16", "r17", "r18", "r19", "r20", "r21", "r22", "r23", \
    "r24", "r25", "r26", "r27", "r28", "r29", "r30", "r31", \
    "sreg", "sp", "dummy0", "dummy1" }
#define FIXED_REGISTERS \
  {   1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1,     0,     0,     0,     0, \
      0,     0,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1 }
#define CALL_USED_REGISTERS \
  {   1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1,     1,     1,     1,     1, \
      1,     1,     1,     1 }

#define       FRAME_POINTER_REGNUM    28
#define       ARG_POINTER_REGNUM      FRAME_POINTER_REGNUM
constexpr int SREG_REGNUM           = 32;
constexpr int STACK_POINTER_REGNUM  = 33;
constexpr int DUMMY0_REGNUM         = 34;
constexpr int DUMMY1_REGNUM         = 35;
constexpr int FIRST_PSEUDO_REGISTER = 36;

enum reg_class {
  NO_REGS, R0_REGS, R1_REGS, R2_REGS, R3_REGS,
  R4_REGS, R5_REGS, R6_REGS, R7_REGS,
  R8_REGS, R9_REGS, R10_REGS, R11_REGS,
  R12_REGS, R13_REGS, R14_REGS, R15_REGS,
  R16_REGS, R17_REGS, R18_REGS, R19_REGS,
  R20_REGS, R21_REGS, R22_REGS, R23_REGS,
  R24_REGS, R25_REGS, R26_REGS, R27_REGS,
  R28_REGS, R29_REGS, R30_REGS, R31_REGS,
  SREG_REGS, SP_REGS, DUMMY0_REGS, DUMMY1_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "R0_REGS", "R1_REGS", "R2_REGS", "R3_REGS", \
    "R4_REGS", "R5_REGS", "R6_REGS", "R7_REGS", \
    "R8_REGS", "R9_REGS", "R10_REGS", "R11_REGS", \
    "R12_REGS", "R13_REGS", "R14_REGS", "R15_REGS", \
    "R16_REGS", "R17_REGS", "R18_REGS", "R19_REGS", \
    "R20_REGS", "R21_REGS", "R22_REGS", "R23_REGS", \
    "R24_REGS", "R25_REGS", "R26_REGS", "R27_REGS", \
    "R27_REGS", "R28_REGS", "R30_REGS", "R31_REGS", \
    "SREG_REGS", "SP_REGS", "DUMMY_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000, 0x00000000 }, \
/* R0_REGS */		 { 0x00000001, 0x00000000 }, \
/* R1_REGS */		 { 0x00000002, 0x00000000 }, \
/* R2_REGS */		 { 0x00000004, 0x00000000 }, \
/* R3_REGS */		 { 0x00000008, 0x00000000 }, \
/* R4_REGS */		 { 0x00000010, 0x00000000 }, \
/* R5_REGS */		 { 0x00000020, 0x00000000 }, \
/* R6_REGS */		 { 0x00000040, 0x00000000 }, \
/* R7_REGS */		 { 0x00000080, 0x00000000 }, \
/* R8_REGS */		 { 0x00000100, 0x00000000 }, \
/* R9_REGS */		 { 0x00000200, 0x00000000 }, \
/* R10_REGS */		 { 0x00000400, 0x00000000 }, \
/* R11_REGS */		 { 0x00000800, 0x00000000 }, \
/* R12_REGS */		 { 0x00001000, 0x00000000 }, \
/* R13_REGS */		 { 0x00002000, 0x00000000 }, \
/* R14_REGS */		 { 0x00004000, 0x00000000 }, \
/* R15_REGS */		 { 0x00008000, 0x00000000 }, \
/* R16_REGS */		 { 0x00010000, 0x00000000 }, \
/* R17_REGS */		 { 0x00020000, 0x00000000 }, \
/* R18_REGS */		 { 0x00040000, 0x00000000 }, \
/* R19_REGS */		 { 0x00080000, 0x00000000 }, \
/* R20_REGS */		 { 0x00100000, 0x00000000 }, \
/* R21_REGS */		 { 0x00200000, 0x00000000 }, \
/* R22_REGS */		 { 0x00400000, 0x00000000 }, \
/* R23_REGS */		 { 0x00800000, 0x00000000 }, \
/* R24_REGS */		 { 0x01000000, 0x00000000 }, \
/* R25_REGS */		 { 0x02000000, 0x00000000 }, \
/* R26_REGS */		 { 0x04000000, 0x00000000 }, \
/* R27_REGS */		 { 0x08000000, 0x00000000 }, \
/* R28_REGS */		 { 0x10000000, 0x00000000 }, \
/* R29_REGS */		 { 0x20000000, 0x00000000 }, \
/* R30_REGS */		 { 0x40000000, 0x00000000 }, \
/* R31_REGS */		 { 0x80000000, 0x00000000 }, \
/* SREG_REGS */		 { 0x00000000, 0x00000001 }, \
/* SP_REGS */		 { 0x00000000, 0x00000002 }, \
/* DUMMY_REGS */	 { 0x00000000, 0x0000000c }, \
/* GENERAL_REGS */	 { 0x03f00000, 0x00000000 }, \
/* ALL_REGS */           { 0xffffffff, 0x0000000f }}

constexpr int N_REG_CLASSES = (int)LIM_REG_CLASSES;

constexpr int UNITS_PER_WORD  = 1;
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           16
#define LONG_TYPE_SIZE		32
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

typedef int CUMULATIVE_ARGS;

extern void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS&, tree, rtx, tree, int);

constexpr int MOVE_MAX = 1;

constexpr bool STRICT_ALIGNMENT = false;

constexpr bool BITS_BIG_ENDIAN  = false;
constexpr bool BYTES_BIG_ENDIAN = true;
constexpr bool WORDS_BIG_ENDIAN = true;

constexpr int FUNCTION_BOUNDARY = 4;

constexpr int TRAMPOLINE_SIZE = 4;

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("AVR")

constexpr int BIGGEST_ALIGNMENT = 8;

constexpr int ATTRIBUTE_ALIGNED_VALUE = 16;

constexpr auto Pmode = HImode;

constexpr int MAX_REGS_PER_ADDRESS = 1;

extern bool FUNCTION_ARG_REGNO_P(int regno);

constexpr int STACK_BOUNDARY = 8;

constexpr int PARM_BOUNDARY  = 8;

constexpr auto FUNCTION_MODE = QImode;

constexpr reg_class BASE_REG_CLASS = R0_REGS;

extern bool REGNO_OK_FOR_BASE_P(int);

extern reg_class REGNO_REG_CLASS(int);

constexpr bool SLOW_BYTE_ACCESS = false;

extern void ASM_OUTPUT_ALIGN(FILE*, int);

extern int FIRST_PARM_OFFSET(tree);

constexpr auto CASE_VECTOR_MODE = Pmode;

constexpr const char* ASM_APP_ON = "; Begin inline assembler code\n#APP\n";

constexpr const char* ASM_APP_OFF = "; End of inline assembler code\n#NO_APP\n";

extern void FUNCTION_PROFILER(FILE*, int);

extern bool REGNO_OK_FOR_INDEX_P(int);

constexpr auto INDEX_REG_CLASS = R0_REGS;

#define ELIMINABLE_REGS	{{FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}}

extern void INITIAL_ELIMINATION_OFFSET(int, int, poly_int64_pod&);

constexpr bool DEFAULT_SIGNED_CHAR = false;

extern void avr_print_operand(FILE*, rtx, int);
#define PRINT_OPERAND avr_print_operand

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#undef PREFERRED_DEBUGGING_TYPE
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG

#define STACK_GROWS_DOWNWARD 1

#define PUSH_ROUNDING(X)	(X)

#endif // AVR_H
