#ifndef AVR_PROTOS_H
#define AVR_PROTOS_H

void avr_expand_prologue();
void avr_expand_epilogue();
const char* avr_movhi(rtx x, rtx y);
const char* avr_subhi3(rtx x, rtx y, rtx z);
const char* avr_addhi3(rtx x, rtx y, rtx z);
const char* avr_call_value(rtx x, rtx fun);
const char* avr_pushhi1(rtx x);

const char* avr_cbranch(rtx op);

#endif //  AVR_PROTOS_H
