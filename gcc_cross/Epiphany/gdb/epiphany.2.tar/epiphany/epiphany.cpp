#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia epiphany_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void epiphany_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t epiphany_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == sizeof cpu->r/sizeof cpu->r[0])
    return cpu->pc;
  if (rn == sizeof cpu->r/sizeof cpu->r[0]+1)
    return cpu->status;
  asm("int3");
  return 0;
}

extern "C"
int epiphany_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { epiphany_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void epiphany_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->pc = v;
    return;
  }
  if (rn == sizeof cpu->r/sizeof cpu->r[0]+1) {
    cpu->status = v;
    return;
  }
  asm("int3");
}

extern "C"
int epiphany_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  epiphany_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 2;
}

static void jalr2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn >> 10;
  cpu->r[14] = cpu->pc + 2;
  cpu->pc = cpu->r[n];
}

static void jalr4(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		  sim_cia cia, instruction_word next)
{
  int n = insn >> 10;
  n += 8;
  cpu->r[14] = cpu->pc + 4;
  cpu->pc = cpu->r[n];
}

static void mov_imm(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia, instruction_word next)
{
  int n = (insn >> 13) | ((next >> 13) << 3);
  uint16_t imm = ((insn >> 5) & 0xff) | (next << 4) & 0xff00;
  cpu->r[n] = imm;
  cpu->pc += 4;
}

static void set_status(sim_cpu* cpu, uint32_t res)
{
  cpu->status &= ~1;
  if (res == 0)
    cpu->status |= 1;
}

static void add_imm(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia, instruction_word next)
{
  int n = (insn >> 13) | ((next >> 13) << 3);
  int m = ((insn >> 10) & 7) | ((next >> 10) & 7) << 3;
  int imm = ((insn >> 7) & 7) | ((next & 7) << 3);
  cpu->r[n] = cpu->r[m] + imm;
  set_status(cpu, cpu->r[n]);
  cpu->pc += 4;
}

static void movt(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia,
		 instruction_word next)
{
  int n = (insn >> 13) | ((next >> 13) << 3);
  uint16_t imm = ((insn >> 5) & 0xff) | (next << 4) & 0xff00;
  cpu->r[n] |= imm << 16;
  cpu->pc += 4;
}

static void mov2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn >> 13;
  int m = (insn >> 10) & 0x7;
  cpu->r[n] = cpu->r[m];
  cpu->pc += 2;
}

static void
op0x2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 4) & 0xf;
  switch (t) {
  case 0x5: return jalr2(sd, cpu, insn, cia);
  case 0xa: return nop(sd, cpu, insn, cia);
  case 0xe: return mov2(sd, cpu, insn, cia);
  default:
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }
}


static void
op0xb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  if ((next >> 12) & 1)
    return movt(sd, cpu, insn, cia, next);
  if ((insn >> 4) & 1)
    return add_imm(sd, cpu, insn, cia, next);
  return mov_imm(sd, cpu, insn, cia, next);
}

static void str_ldr4(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia, instruction_word next)
{
  int n = (insn >> 13) | ((next >> 13) << 3);
  int m = ((insn >> 10) & 7) | ((next >> 10) & 7) << 3;
  int k = ((insn >> 7) & 7) | ((next & 0x1f) << 3);
  auto sz = (insn >> 5) & 3;
  k <<= sz;  
  int off = (next & 0x0100) ? -k : k;
  uint32_t addr = cpu->r[m];
  auto pm = (next >> 9) & 1;
  if (!pm)
    addr += off;
  auto st = (insn >> 4) & 1;
  if (st) {
    switch (sz) {
    case 0:
      sim_core_write_aligned_1(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 1:
      sim_core_write_aligned_2(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 2:
      sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 3:
      sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[n]);
      sim_core_write_aligned_4(cpu, cia, write_map, addr+4, cpu->r[n+1]);
      break;
    }
  }
  else {
    switch (sz) {
    case 0:
      cpu->r[n] = sim_core_read_aligned_1(cpu, cia, read_map, addr);
      break;
    case 1:
      cpu->r[n] = sim_core_read_aligned_2(cpu, cia, read_map, addr);
      break;
    case 2:
      cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
      break;
    case 3:
      cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
      cpu->r[n+1] = sim_core_read_aligned_4(cpu, cia, read_map, addr+4);
      break;
    }
  }
  if (pm)
    cpu->r[m] += off;
  cpu->pc += 4;
}

static void str_ldr2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia)
{
  int n = insn >> 13;
  int m = (insn >> 10) & 0x7;
  int off = (insn >> 7) & 0x7;
  auto sz = (insn >> 5) & 3;
  off <<= sz;
  uint32_t addr = cpu->r[m];
  addr += off;
  auto st = (insn >> 4) & 1;
  if (st) {
    switch (sz) {
    case 0:
      sim_core_write_aligned_1(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 1:
      sim_core_write_aligned_2(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 2:
      sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[n]);
      break;
    case 3:
      sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[n]);
      sim_core_write_aligned_4(cpu, cia, write_map, addr+4, cpu->r[n+1]);
      break;
    }
  }
  else {
    switch (sz) {
    case 0:
      cpu->r[n] = sim_core_read_aligned_1(cpu, cia, read_map, addr);
      break;
    case 1:
      cpu->r[n] = sim_core_read_aligned_2(cpu, cia, read_map, addr);
      break;
    case 2:
      cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
      break;
    case 3:
      cpu->r[n] = sim_core_read_aligned_4(cpu, cia, read_map, addr);
      cpu->r[n+1] = sim_core_read_aligned_4(cpu, cia, read_map, addr+4);
      break;
    }
  }
  cpu->pc += 2;
}

static void
op0xc(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  return str_ldr4(sd, cpu, insn, cia, next);
}

static void mov(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia,
		instruction_word next)
{
  int n = (insn >> 13) | ((next >> 13) << 3);
  int m = ((insn >> 10) & 7) | ((next >> 10) & 7) << 3;
  cpu->r[n] = cpu->r[m];
  cpu->pc += 4;
}

static void add(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia,
		instruction_word next)
{
  asm("int3");
  cpu->pc += 4;
}

static void rts(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia,
		instruction_word next)
{
  cpu->pc = cpu->r[14];
}

static void
op0xf(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto t = (insn >> 4) & 0xf;
  switch (t) {
  case 0x1: return add(sd, cpu, insn, cia, next);
  case 0x4: return rts(sd, cpu, insn, cia, next);
  case 0x5: return jalr4(sd, cpu, insn, cia, next);
  case 0xe: return mov(sd, cpu, insn, cia, next);
  default:
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }
}

static void
mov_imm8(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn >> 13;
  uint8_t imm = insn >> 5;
  cpu->r[n] = imm;
  cpu->pc += 2;
}

static void
add_imm8(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn >> 13;
  int m = (insn >> 10) & 7;
  int imm = (insn >> 7) & 7;
  cpu->r[n] = cpu->r[m] + imm;
  cpu->pc += 2;
}

static void
add_sub2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = insn >> 13;
  int m = (insn >> 10) & 0x7;
  int k = (insn >> 7) & 0x7;
  auto sub = (insn >> 5) & 1;
  if (sub)
    cpu->r[n] = cpu->r[m] - cpu->r[k];
  else
    cpu->r[n] = cpu->r[m] + cpu->r[k];
  set_status(cpu, cpu->r[n]);
  cpu->pc += 2;
}

static bool taken(sim_cpu* cpu, instruction_word insn)
{
  auto t = (insn >> 4) & 0xf;
  switch (t) {
  case 0x0: // beq
    return cpu->status & 1;
  case 0xe: // b
    return true;
  default:
    asm("int3");
    return false;
  }
}

static void
branch(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int32_t rel = insn >> 8;
  rel <<= 28;
  rel >>= 27;
  if (taken(cpu, insn))
    cpu->pc += rel;
  else
    cpu->pc += 2;
}

static void
op0x3(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 4) & 1;
  if (t)
    return add_imm8(sd, cpu, insn, cia);
  return mov_imm8(sd, cpu, insn, cia);  
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x0] = branch;
    (*this)[0x2] = op0x2;
    (*this)[0x3] = op0x3;
    (*this)[0x4] = str_ldr2;
    (*this)[0xa] = add_sub2;
    (*this)[0xb] = op0xb;
    (*this)[0xc] = op0xc;
    (*this)[0xf] = op0xf;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  uint8_t key = insn & 0xf;
  auto p = table.find(key);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
