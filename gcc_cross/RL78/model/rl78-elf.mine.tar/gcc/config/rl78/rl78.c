#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx rl78_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return gen_rtx_REG(mode, 8);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE rl78_function_value

bool rl78_legitimate_address_p(machine_mode mode, rtx x, bool strict)
{
  (void)mode; (void)strict;
  if (MEM_P(x))
    return false;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P rl78_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum, tree fntype, rtx,
			  tree func, int)
{
  (void)fntype;
  (void)func;
  (void)cum;
}

void rl78_function_arg_advance(cumulative_args_t,
			       const function_arg_info&)
{
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE rl78_function_arg_advance

rtx rl78_function_incoming_arg(cumulative_args_t, const function_arg_info&)
{
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG rl78_function_incoming_arg

rtx rl78_function_arg(cumulative_args_t, const function_arg_info&)
{
  return nullptr;
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG rl78_function_arg

void rl78_asm_file_start()
{
  for (int i = 0; i != 8; ++i) {
    fprintf(asm_out_file, "r%d\t=\t0x%x\n",  8 + i, 0xffef0 + i);
    fprintf(asm_out_file, "r%d\t=\t0x%x\n", 16 + i, 0xffee8 + i);
    fprintf(asm_out_file, "r%d\t=\t0x%x\n", 24 + i, 0xffee0 + i);
  }
}

#undef  TARGET_ASM_FILE_START
#define TARGET_ASM_FILE_START rl78_asm_file_start

#undef TARGET_LRA_P
#define TARGET_LRA_P hook_bool_void_false

bool rl78_target_can_eliminate(int from, int to)
{
  assert(from == ARG_POINTER_REGNUM);
  assert(to == STACK_POINTER_REGNUM);
  frame_pointer_needed = false;
  return true;
}

#undef TARGET_CAN_ELIMINATE
#define TARGET_CAN_ELIMINATE rl78_target_can_eliminate

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  (void)regno;
  return false;
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  return regno < 8 ? GENERAL_REGS : SPECIAL_REGS;
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;  
  return 0;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  assert(from == ARG_POINTER_REGNUM);
  assert(to == STACK_POINTER_REGNUM);
  offset = get_frame_size() + 4;
}

int rl78_dwarf_frame_regnum(int regno)
{
  if (regno == ARG_POINTER_REGNUM)
    return STACK_POINTER_REGNUM;
  assert(regno == STACK_POINTER_REGNUM);
  return regno;
}

void print_reg(FILE* fp, int regno, machine_mode mode)
{
  auto rn = reg_names[regno];
  if (regno >= 8)
    return (void)fprintf(fp, "%s", rn);

  auto lo = (regno & 1) ? rn : reg_names[regno+1];
  auto hi = (regno & 1) ? reg_names[regno-1] : rn;
  switch (mode) {
  case HImode:
    fprintf(fp, "%s%s", lo, hi);
    break;
  default:
    abort();
  }
}

inline bool rel(rtx x, int* offset, unsigned int regno)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == regno;
}

inline bool sp_rel(rtx x, int* offset)
{
  return rel(x, offset, STACK_POINTER_REGNUM);
}

void rl78_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x))
    return print_reg(fp, REGNO(x), GET_MODE(x));
  if (CONST_INT_P(x))
    return (void)fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
  int offset;
  if (sp_rel(x, &offset)) {
    auto sp = reg_names[STACK_POINTER_REGNUM];
    fprintf(fp, "[%s+%d]", sp, offset);
    return;
  }
  if (SYMBOL_REF_P(x)) {
    auto s = XSTR(x, 0);
    assert(*s == '*');
    ++s;
    fprintf(fp, "%s", s);
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    assert(SYMBOL_REF_P(e0));
    auto s = XSTR(e0, 0);
    ASM_OUTPUT_LABELREF(fp, s);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void rl78_expand_prologue()
{
  auto size = get_frame_size();
  size += crtl->outgoing_args_size;
  if (!size)
    return;
  auto sp = stack_pointer_rtx;
  auto delta = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
  auto insn = emit_move_insn(sp, delta);
  RTX_FRAME_RELATED_P(insn) = true;
}

inline bool sp_adj(rtx x, rtx y, rtx z)
{
  if (!REG_P(x))
    return false;
  if (!REG_P(y))
    return false;
  unsigned rx = REGNO(x);
  if (rx != REGNO(y))
    return false;
  if (rx != STACK_POINTER_REGNUM)
    return false;
  return CONST_INT_P(z);
}

const char* rl78_subhi3(rtx x, rtx y, rtx z)
{
  if (sp_adj(x, y, z))
    return "subw	%0, #%2";

  return "%0 := %1 - %2";
}

void rl78_expand_epilogue()
{
  auto size = get_frame_size();
  size += crtl->outgoing_args_size;
  if (size) {
    auto sp = stack_pointer_rtx;
    auto delta = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
    emit_move_insn(sp, delta);
  }
  emit_jump_insn(ret_rtx);
}

const char* rl78_movhi(rtx x, rtx y)
{
  if (REG_P(x) && REG_P(y)) {
    int xno = REGNO(x);
    if (xno < 8)
      return "movw	%0, %1";
    int yno = REGNO(y);
    fprintf(asm_out_file, "	movw	");
    int ax = 0;
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, ", ");
    print_reg(asm_out_file, yno, HImode);
    fprintf(asm_out_file, "\n");

    fprintf(asm_out_file, "	movw	");
    print_reg(asm_out_file, xno, HImode);
    fprintf(asm_out_file, ", ");
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, "\n");
    return "";
  }

  int offset;
  if (sp_rel(x, &offset) && SYMBOL_REF_P(y)) {
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    int scratch = 0;
    fprintf(asm_out_file, "	movw	");
    print_reg(asm_out_file, scratch, HImode);
    fprintf(asm_out_file, ", #%s\n", s);
    auto sp = reg_names[STACK_POINTER_REGNUM];
    fprintf(asm_out_file, "	movw	[%s], ", sp);
    print_reg(asm_out_file, scratch, HImode);
    fprintf(asm_out_file, "\n");
    return "";
  }

  if (REG_P(x) && CONST_INT_P(y))
    return "movw	%0, #%1";

  if (sp_rel(x, &offset) && CONST_INT_P(y)) {
    int v = INTVAL(y);
    fprintf(asm_out_file, "	movw	");
    int ax = 0;
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, ", ");
    fprintf(asm_out_file, "#%d\n", v);

    auto sp = reg_names[STACK_POINTER_REGNUM];
    if (offset)
      fprintf(asm_out_file, "	movw	[%s+%d], ", sp, offset);
    else
      fprintf(asm_out_file, "	movw	[%s], ", sp);
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, "\n");
    return "";
  }

  if (sp_rel(x, &offset) && REG_P(y)) {
    fprintf(asm_out_file, "	movw	");
    int ax = 0;
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, ", ");
    int regno = REGNO(y);
    print_reg(asm_out_file, regno, HImode);
    fprintf(asm_out_file, "\n");
    auto sp = reg_names[STACK_POINTER_REGNUM];
    fprintf(asm_out_file, "	movw	[%s+%d], ", sp, offset);
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, "\n");
    return "";
  }
  
  return "%0 := %1";
}

inline void load(int regno, int offset)
{
  fprintf(asm_out_file, "	movw	");
  print_reg(asm_out_file, regno, HImode);
  auto sp = reg_names[STACK_POINTER_REGNUM];
  fprintf(asm_out_file, ", [%s+%d]\n", sp, offset);
}

const char* rl78_addhi3(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && sp_rel(y, &offy) && sp_rel(z, &offz)) {

    // ax := [sp+offz]
    int ax = 0;
    load(ax, offz);

    // r := ax
    int regno = REGNO(x);
    fprintf(asm_out_file, "	movw	");
    print_reg(asm_out_file, regno, HImode);
    fprintf(asm_out_file, ", ");
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, "\n");

    // ax := [sp+offy]
    load(ax, offy);

    // ax := ax + r
    fprintf(asm_out_file, "	addw	");
    print_reg(asm_out_file, ax, HImode);
    fprintf(asm_out_file, ", ");
    print_reg(asm_out_file, regno, HImode);
    fputc('\n', asm_out_file);

    // r := ax
    fprintf(asm_out_file, "	movw	");
    print_reg(asm_out_file, regno, HImode);
    fprintf(asm_out_file, ", ");
    print_reg(asm_out_file, ax, HImode);    
    fprintf(asm_out_file, "\n");
    return "";
  }

  if (sp_adj(x, y, z))
    return "addw	%0, #%2";

  return "%0 := %1 + %2";
}

const char* rl78_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && REGNO(x) == 8 && MEM_P(fun))
    return "call	!!%%code(%1)";

  return "%0 := call %1";
}

const char* rl78_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

bool rl78_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}
