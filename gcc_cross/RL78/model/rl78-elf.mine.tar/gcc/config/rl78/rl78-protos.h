#ifndef RL78_PROTOS_H
#define RL78_PROTOS_H

void rl78_expand_prologue();
const char* rl78_subhi3(rtx x, rtx y, rtx z);
const char* rl78_movhi(rtx x, rtx y);

void rl78_expand_epilogue();
const char* rl78_addhi3(rtx x, rtx y, rtx z);

const char* rl78_call_value(rtx x, rtx fun);

const char* rl78_cbranch(rtx op);

#endif //  RL78_PROTOS_H
