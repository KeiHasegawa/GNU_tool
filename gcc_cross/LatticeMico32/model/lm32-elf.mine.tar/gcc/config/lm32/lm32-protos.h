#ifndef LM32_PROTOS_H
#define LM32_PROTOS_H

void lm32_expand_prologue();
void lm32_expand_epilogue();

const char* lm32_subsi3(rtx x, rtx y, rtx z);
const char* lm32_movsi(rtx x, rtx y);
const char* lm32_addsi3(rtx x, rtx y, rtx z);
const char* lm32_call_value(rtx x, rtx fun);

const char* lm32_cbranch(rtx op);

bool lm32_addsi3_expand(rtx, rtx, rtx);

#endif //  LM32_PROTOS_H
