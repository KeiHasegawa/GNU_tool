#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx lm32_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return gen_rtx_REG(mode, 1);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE lm32_function_value

bool lm32_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P lm32_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& nregs, tree fntype, rtx,
			  tree func, int)
{
  (void)fntype;
  (void)func;
  nregs = 0;
}

void lm32_function_arg_advance(cumulative_args_t pcum_v,
				   const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 9)
    ++*nregs;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE lm32_function_arg_advance

rtx lm32_function_incoming_arg(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 9)
    return gen_rtx_REG(arg.mode, 1 + *nregs);
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG lm32_function_incoming_arg

rtx lm32_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  return lm32_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG lm32_function_arg

HOST_WIDE_INT lm32_starting_frame_offset()
{
  return 4;
}

#undef  TARGET_STARTING_FRAME_OFFSET
#define TARGET_STARTING_FRAME_OFFSET lm32_starting_frame_offset

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  return 1 <= regno && regno <= 8;
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case STACK_POINTER_REGNUM:
  case FRAME_POINTER_REGNUM:
  case RA_REGNUM:
  case 0:
  case DUMMY_REGNUM:
    return SPECIAL_REGS;
  default:
    return GENERAL_REGS;
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 8;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  assert(from = FRAME_POINTER_REGNUM);
  assert(to = STACK_POINTER_REGNUM);
  offset = 0;
}

inline rtx rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return nullptr;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return nullptr;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return nullptr;
  return y;
}

void lm32_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  int offset;
  if (rtx r = rel(x, &offset)) {
    int regno = REGNO(r);
    auto rn = reg_names[regno];
    fprintf(fp, "(%s+%d)", rn, offset);
    return;
  }
  if (SYMBOL_REF_P(x)) {
    auto s0 = XSTR(x, 0);
    fprintf(fp, "%s", s0);
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    lm32_print_operand(fp, e0, 0);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void lm32_expand_prologue()
{
  // sp := sp - (size+12)
  auto sp = stack_pointer_rtx;
  auto size = get_frame_size();
  auto delta = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size+12));
  emit_move_insn(sp, delta);

  // [sp+8] := fp
  auto p8 = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, 8));
  auto mem8 = gen_rtx_MEM(Pmode, p8);
  auto fp = frame_pointer_rtx;
  emit_move_insn(mem8, fp);

  // [sp+4] ;= ra
  auto p4 = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, 4));
  auto mem4 = gen_rtx_MEM(Pmode, p4);
  auto ra = gen_rtx_REG(Pmode, RA_REGNUM);
  emit_move_insn(mem4, ra);

  // fp := sp
  emit_move_insn(fp, sp);
 
  // fp := fp + (size+12)
  emit_move_insn(fp, delta);
}

void lm32_expand_epilogue()
{
  // fp := [sp+8]
  auto fp = frame_pointer_rtx;
  auto sp = stack_pointer_rtx;
  auto p8 = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, 8));
  auto mem8 = gen_rtx_MEM(Pmode, p8);
  emit_move_insn(fp, mem8);


  // ra := [sp+4]
  auto p4 = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, 4));
  auto mem4 = gen_rtx_MEM(Pmode, p4);
  auto ra = gen_rtx_REG(Pmode, RA_REGNUM);
  emit_move_insn(ra, mem4);

  // sp := sp + (size+12)
  auto size = get_frame_size();
  auto delta = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size+12));
  emit_move_insn(sp, delta);

  emit_jump_insn(ret_rtx);
}

const char* lm32_subsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y) && CONST_INT_P(z))
    return "addi	%0, %1, -%2";

  return "%0 := %1 - %2";
}

const char* lm32_movsi(rtx x, rtx y)
{
  int offset;
  if (rel(x, &offset) && REG_P(y))
    return "sw	%0, %1";

  if (REG_P(x) && rel(y, &offset))
    return "lw	%0, %1";
  
  if (REG_P(x) && REG_P(y))
    return "or	%0, %1, r0";

  if (REG_P(x) && SYMBOL_REF_P(y)) {
    int regno = REGNO(x);
    auto rn = reg_names[regno];
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    fprintf(asm_out_file, "	orhi	%s, r0, hi(%s)\n", rn, s);
    fprintf(asm_out_file, "	ori	%s, %s, lo(%s)\n", rn, rn , s);
    return "";
  }

  if (REG_P(x) && CONST_INT_P(y))
    return "addi	%0, r0, %1";

  return "%0 := %1";
}

inline bool fp_rel(rtx x, int* offset)
{
  rtx r = rel(x, offset);
  if (!r)
    return false;
  assert(REG_P(r));
  return REGNO(r) == FRAME_POINTER_REGNUM;
}

inline void load(int regno, int offset)
{
  auto rn = reg_names[regno];
  auto fp = reg_names[FRAME_POINTER_REGNUM];
  fprintf(asm_out_file, "	lw	%s, (%s+%d)\n", rn, fp, offset);
}

const char* lm32_addsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y) && CONST_INT_P(z))
    return "addi	%0, %1, %2";

  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int regno = REGNO(x);
    load(regno, offy);
    int scratch = regno + 1;
    load(scratch, offz);
    auto rn = reg_names[regno];
    auto sc = reg_names[scratch];
    fprintf(asm_out_file, "	add	%s, %s, %s\n", rn, rn, sc);
    return "";
  }

  return "%0 := %1 + %2";
}

const char* lm32_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && REGNO(x) == 1 && MEM_P(fun))
    return "calli	%1";

  return "%0 := call %1";
}

const char* lm32_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

bool lm32_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}
