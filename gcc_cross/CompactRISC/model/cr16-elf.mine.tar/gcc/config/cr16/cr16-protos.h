#ifndef CR16_PROTOS_H
#define CR16_PROTOS_H

void cr16_expand_prologue();
void cr16_expand_epilogue();

const char* cr16_subsi3(rtx x, rtx y, rtx z);
const char* cr16_movsi(rtx x, rtx y);
const char* cr16_movhi(rtx x, rtx y);
const char* cr16_addhi3(rtx x, rtx y, rtx z);
const char* cr16_addsi3(rtx x, rtx y, rtx z);
const char* cr16_call_value(rtx x, rtx fun);
const char* cr16_pushhi1(rtx x);
const char* cr16_pushsi1(rtx x);

const char* cr16_cbranch(rtx op);

#endif //  CR16_PROTOS_H
