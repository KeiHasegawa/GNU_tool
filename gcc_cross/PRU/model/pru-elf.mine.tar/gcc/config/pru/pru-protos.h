#ifndef PRU_PROTOS_H
#define PRU_PROTOS_H

void pru_expand_prologue();
void pru_expand_epilogue();

const char* pru_movsi(rtx x, rtx y);
const char* pru_addsi3(rtx x, rtx y, rtx z);
const char* pru_subsi3(rtx x, rtx y, rtx z);
const char* pru_call_value(rtx x, rtx fun);

const char* pru_cbranch(rtx op);

#endif //  PRU_PROTOS_H
