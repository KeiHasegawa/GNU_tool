#ifndef x86_16_PROTOS_H
#define x86_16_PROTOS_H

namespace x86_16 {
  void expand_prologue();
  void expand_epilogue();
  namespace hi {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace hi
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  const char* cbranch(rtx op);
} // end of namespace x86_16

#endif //  x86_16_PROTOS_H
