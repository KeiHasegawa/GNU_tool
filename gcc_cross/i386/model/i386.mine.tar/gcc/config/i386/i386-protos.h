#ifndef I386_PROTOS_H
#define I386_PROTOS_H

void i386_expand_prologue();
void i386_expand_epilogue();

const char* i386_movsi(rtx x, rtx y);
const char* i386_addsi3(rtx x, rtx y, rtx z);
const char* i386_subsi3(rtx x, rtx y, rtx z);
const char* i386_call_value(rtx x, rtx fun);

const char* i386_cbranch(rtx op);

#endif //  I386_PROTOS_H
