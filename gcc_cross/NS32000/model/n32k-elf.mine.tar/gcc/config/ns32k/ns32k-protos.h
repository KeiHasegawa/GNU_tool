#ifndef NS32K_PROTOS_H
#define NS32K_PROTOS_H

namespace ns32k {
  void expand_prologue();
  void expand_epilogue();
  namespace si {
    const char* mov(rtx, rtx);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  const char* call_value(rtx x, rtx fun);
  const char* cbranch(rtx op);
} // end of namespace ns32k

#endif //  NS32K_PROTOS_H
