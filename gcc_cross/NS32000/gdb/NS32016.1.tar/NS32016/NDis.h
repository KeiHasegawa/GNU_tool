extern const char InstuctionText[InstructionCount][8];
