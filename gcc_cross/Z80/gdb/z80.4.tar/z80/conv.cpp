#include <string>
#include <cassert>
#include <cstring>

extern "C" void conv16(char* fmt)
{
  using namespace std;
  string tmp = fmt;
  auto p = tmp.find_first_of('l');
  assert(p != string::npos);
  tmp.erase(p,1);
  strcpy(fmt, tmp.c_str());
}

extern "C" void conv32(char* fmt)
{
  using namespace std;
  string tmp = fmt;
  auto p = tmp.find_first_of('l');
  assert(p != string::npos);
  assert(tmp[p+1] == 'l');
  tmp.erase(p,2);
  strcpy(fmt, tmp.c_str());
}

extern "C" void conv_DFLT(char* fmt)
{
  using namespace std;
  string tmp = fmt;
  auto p = tmp.find_first_of('L');
  assert(p != string::npos);
  tmp.erase(p,1);
  strcpy(fmt, tmp.c_str());
}
