#ifndef Z80_H
#define Z80_H

#define REGISTER_NAMES \
  { "a", "f", "b", "c", "d", "e", "h", "l", "ix", "iy", "sp", "ap", "dummy" }

#define A_REGNUM              0
#define FRAME_POINTER_REGNUM  8
#define STACK_POINTER_REGNUM  10
#define ARG_POINTER_REGNUM    11
#define DUMMY_REGNUM          12
#define FIRST_PSEUDO_REGISTER 13

#define FIXED_REGISTERS \
  {  0 ,  1 ,  1 ,  1 ,  1 ,  1 ,  1 ,  1 ,   1 ,   1 ,   1 ,   1,     1  }

#define CALL_USED_REGISTERS \
  {  1 ,  1 ,  1 ,  1 ,  1 ,  1 ,  1 ,  1 ,   1 ,   1 ,   1 ,   1,     1  }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000 }, \
/* SPECIAL_REGS */	 { 0x00001f00 }, \
/* GENERAL_REGS */	 { 0x000000ff }, \
/* ALL_REGS */           { 0x00001fff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 1
#define SHORT_TYPE_SIZE		8
#define INT_TYPE_SIZE           8
#define LONG_TYPE_SIZE		16
#define LONG_LONG_TYPE_SIZE     32
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        32
#define LONG_DOUBLE_TYPE_SIZE   32
#define POINTER_SIZE            16

typedef int CUMULATIVE_ARGS;
extern void z80_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  z80_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 2

#define STRICT_ALIGNMENT 0
#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 0
#define WORDS_BIG_ENDIAN 0

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("z80")

#define BIGGEST_ALIGNMENT 4

#define ATTRIBUTE_ALIGNED_VALUE 8

#define Pmode HImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { \
  {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}, \
  {ARG_POINTER_REGNUM, STACK_POINTER_REGNUM}, \
  {ARG_POINTER_REGNUM, FRAME_POINTER_REGNUM} }

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY 8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

extern void ASM_OUTPUT_ALIGN(FILE*, int);

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

extern void FUNCTION_PROFILER(FILE*, int);

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

extern int z80_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET) \
  (OFFSET) = z80_initial_elimination_offset(FROM, TO)

#define DEFAULT_SIGNED_CHAR 0

extern void z80_print_operand(FILE*, rtx, int);
#define PRINT_OPERAND z80_print_operand

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1

#define ASM_OUTPUT_LABELREF(FILE,NAME) 	fprintf(FILE, "_%s", NAME)

#define PUSH_ROUNDING(X)	(X)

#define INCOMING_RETURN_ADDR_RTX gen_rtx_MEM(Pmode, stack_pointer_rtx)

#define FRAME_POINTER_CFA_OFFSET(FDECL) 2

#endif // Z80_H
