#ifndef Z80_PROTOS_H
#define Z80_PROTOS_H

void z80_expand_prologue();
void z80_expand_epilogue();

const char* z80_movqi(rtx x, rtx y);
const char* z80_addqi3(rtx x, rtx y, rtx z);

const char* z80_movhi(rtx x, rtx y);
const char* z80_addhi3(rtx x, rtx y, rtx z);
const char* z80_subhi3(rtx x, rtx y, rtx z);

const char* z80_call_value(rtx x, rtx fun);

const char* z80_cbranch(rtx op);

#endif //  Z80_PROTOS_H
