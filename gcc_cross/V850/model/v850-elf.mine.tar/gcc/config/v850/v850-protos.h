#ifndef V850_PROTOS_H
#define V850_PROTOS_H

void v850_expand_prologue();
void v850_expand_epilogue();
const char* v850_movsi(rtx x, rtx y);
const char* v850_addsi3(rtx x, rtx y, rtx z);
const char* v850_subsi3(rtx x, rtx y, rtx z);
const char* v850_call_value(rtx x, rtx fun);

const char* v850_cbranch(rtx op);

#endif //  V850_PROTOS_H
