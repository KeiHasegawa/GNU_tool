#ifndef SPARC_PROTOS_H
#define SPARC_PROTOS_H

void sparc_expand_prologue();
void sparc_expand_epilogue();

const char* sparc_movsi(rtx x, rtx y);
const char* sparc_addsi3(rtx x, rtx y, rtx z);
const char* sparc_subsi3(rtx x, rtx y, rtx z);

const char* sparc_call_value(rtx x, rtx fun);

const char* sparc_cbranch(rtx op);

#endif //  SPARC_PROTOS_H
