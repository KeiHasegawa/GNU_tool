#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx sparc_function_value(const_tree ret_type, const_tree, bool outgoing)
{
  auto mode = TYPE_MODE(ret_type);
  int n = outgoing ? I0_REGNUM : O0_REGNUM;
  return gen_rtx_REG(mode, n);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE sparc_function_value

bool sparc_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P sparc_legitimate_address_p

void sparc_init_cumulative_args(CUMULATIVE_ARGS* nregs, tree fntype,
				rtx, tree func, int)
{
  (void)fntype;
  (void)func;
  *nregs = 0;
}

void sparc_function_arg_advance(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 6)
    ++*nregs;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE sparc_function_arg_advance

rtx sparc_function_incoming_arg(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  auto mode = arg.mode;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 6)
    return gen_rtx_REG(mode, I0_REGNUM + *nregs);
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG sparc_function_incoming_arg

rtx sparc_function_arg(cumulative_args_t pcum_v,
		       const function_arg_info& arg)
{
  auto mode = arg.mode;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 6)
    return gen_rtx_REG(mode, O0_REGNUM + *nregs);
  return nullptr;
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG sparc_function_arg

HOST_WIDE_INT sparc_starting_frame_offset()
{
  return 68;
}

#undef  TARGET_STARTING_FRAME_OFFSET
#define TARGET_STARTING_FRAME_OFFSET sparc_starting_frame_offset

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

int FUNCTION_ARG_REGNO_P(int regno)
{
  return O0_REGNUM <= regno && regno <= O0_REGNUM + 5;
}

int REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case 0:
  case STACK_POINTER_REGNUM:
  case FRAME_POINTER_REGNUM:
    return SPECIAL_REGS;
  }

  if (regno < 16)
    return GENERAL_REGS;

  return FLOAT_REGS;
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 0;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

int REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

int sparc_incoming_args_size()
{
  auto func = TREE_TYPE(current_function_decl);
  auto chain = TYPE_ARG_TYPES(func);

  int s = 0;
  for ( ; chain ; chain = TREE_CHAIN(chain)) {
    auto arg = TREE_VALUE(chain);
    auto mode = TYPE_MODE(arg);
    int size = GET_MODE_SIZE(mode);
    size = (size + 3) & ~3;
    s += size;
  }
  return s;
}

int sparc_initial_elimination_offset(int from, int to)
{
  assert(from == FRAME_POINTER_REGNUM && to == STACK_POINTER_REGNUM);
  return get_frame_size() - sparc_incoming_args_size() + 96;
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code != PLUS)
    return false;
  auto z = XEXP(y, 1);
  if (!CONST_INT_P(z))
    return false;
  *offset = INTVAL(z);
  auto u = XEXP(y, 0);
  return u == frame_pointer_rtx;
}

void sparc_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  int offset;
  if (fp_rel(x, &offset)) {
    auto rn = reg_names[FRAME_POINTER_REGNUM];
    fprintf(fp, "[%s + %d]", rn, offset);
    return;
  }
  if (MEM_P(x)) {
    auto y = XEXP(x, 0);
    if (SYMBOL_REF_P(y)) {
      auto s = XSTR(y, 0);
      fprintf(fp, "%s", s);
      return;
    }
  }
  if (SYMBOL_REF_P(x)) {
    auto s = XSTR(x, 0);
    assert(*s == '*');
    ++s;
    fprintf(fp, "%s", s);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void sparc_expand_prologue()
{
  auto size = get_frame_size() - sparc_incoming_args_size() + 96;
  auto delta = gen_rtx_CONST_INT(Pmode, size);
  emit_insn(gen_save(delta));
}

void sparc_expand_epilogue()
{
  auto size = get_frame_size() - sparc_incoming_args_size() + 96;
  auto delta = gen_rtx_CONST_INT(Pmode, size);
  emit_insn(gen_restore(delta));
  emit_jump_insn(ret_rtx);
}

const char* sparc_movsi(rtx x, rtx y)
{
  int offx;
  if (fp_rel(x, &offx) && REG_P(y))
    return "st	%1, %0";

  if (REG_P(x) && REG_P(y))
    return "mov	%1, %0";

  if (REG_P(x) && SYMBOL_REF_P(y)) {
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    int regno = REGNO(x);
    auto rn = reg_names[regno];
    fprintf(asm_out_file, "	sethi	%%hi(%s), %s\n", s, rn);
    fprintf(asm_out_file, "	or	%s, %%lo(%s), %s\n", rn, s, rn);
    return "";
  }

  if (REG_P(x) && CONST_INT_P(y))
    return "mov	%1, %0";
  
  asm("int3");
  return "%0 := %1";
}

namespace si {
  inline void ldfp(int regno, int offy)
  {
    auto rn = reg_names[regno];
    auto fp = reg_names[FRAME_POINTER_REGNUM];
    fprintf(asm_out_file, "	ld	[%s + %d], %s\n", fp, offy, rn);
  }
} // end of namespace si

const char* sparc_addsi3(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int regno = REGNO(x);
    si::ldfp(regno, offy);
    int scratch = 6;
    si::ldfp(scratch, offz);    
    auto rn = reg_names[regno];
    auto sc = reg_names[scratch];
    fprintf(asm_out_file, "	add	%s, %s, %s\n", rn, sc, rn);
    return "";
  }

  asm("int3");
  return "%0 := %1 + %2";
}

const char* sparc_subsi3(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  return "%0 := %1 - %2";
}

const char* sparc_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && MEM_P(fun)) {
    int regno = REGNO(x);
    assert(regno == O0_REGNUM);
    auto e0 = XEXP(fun, 0);
    assert(SYMBOL_REF_P(e0));
    auto s = XSTR(e0, 0);
    fprintf(asm_out_file, "	call	%s, 0\n", s);
    fprintf(asm_out_file, "	nop\n");
    return "";
  }
      
  asm("int3");
  return "%0 := call %1";
}

const char* sparc_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

int sparc_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}

rtx sparc_incoming_return_addr_rtx()
{
  auto o7 = gen_rtx_REG(Pmode, O0_REGNUM+7);
  auto plus8 = gen_rtx_PLUS(Pmode, o7, gen_rtx_CONST_INT(Pmode, 8));
  return plus8;
}

