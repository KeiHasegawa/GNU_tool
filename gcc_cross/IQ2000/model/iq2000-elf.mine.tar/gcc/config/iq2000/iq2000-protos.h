#ifndef IQ2000_PROTOS_H
#define IQ2000_PROTOS_H

void iq2000_expand_prologue();
void iq2000_expand_epilogue();
const char* iq2000_subsi3(rtx x, rtx y , rtx z);
const char* iq2000_movsi(rtx x, rtx y);
const char* iq2000_addsi3(rtx x, rtx y , rtx z);
const char* iq2000_call_value(rtx x, rtx fun);

const char* iq2000_cbranch(rtx op);

#endif //  IQ2000_PROTOS_H
