#include "sim-main.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia tic6x_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void tic6x_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t tic6x_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < 16)
    return cpu->a[rn];
  if (rn < 32)
    return cpu->b[rn-16];
  if (rn == 32)
    return cpu->csr;
  if (rn == 33)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int tic6x_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { tic6x_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void tic6x_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < 16) {
    cpu->a[rn] = v;
    return;
  }
  if (rn < 32) {
    cpu->b[rn-16] = v;
    return;
  }
  if (rn == 32) {
    cpu->csr = v;
    return;
  }
  if (rn == 33) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int tic6x_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  tic6x_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

namespace tic6x {
  using namespace std;
  struct delay {
    virtual void exec() = 0;
    virtual ~delay(){}
  };
  list<delay*> delay_slot;
  void consume(int n)
  {
    while (!delay_slot.empty() && n--) {
      if (auto p = delay_slot.front()) {
	p->exec();
	delete p;
      }
      delay_slot.pop_front();
    }
  }
  struct consumer {
    int cnt;
    consumer(int n) : cnt{n} {}
    ~consumer()
    {
      consume(cnt);
    }
  };
} // end of namespace tic6x

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  int src = ((insn >> 13) & 0xf) + 1;
  consumer obj(src);
  cpu->pc += 4;
}

static void mvk(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int16_t cst = insn >> 7;
  if (insn & (1 << 6))
    cst >>= 6;
  int dst = (insn >> 23) & 0xf;
  if (insn & 2)
    cpu->b[dst] = cst;
  else
    cpu->a[dst] = cst;
  cpu->pc += 4;
}

static void addk(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int16_t cst = insn >> 7;
  int dst = (insn >> 23) & 0xf;
  if (insn & 2)
    cpu->b[dst] += cst;
  else
    cpu->a[dst] += cst;
  cpu->pc += 4;
}
  
static void mvkh(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int16_t cst = insn >> 7;
  int dst = (insn >> 23) & 0xf;
  if (insn & 2) {
    cpu->b[dst] &= 0xffff;
    cpu->b[dst] |= cst << 16;
  }
  else {
    cpu->a[dst] &= 0xffff;
    cpu->a[dst] |= cst << 16;
  }
  cpu->pc += 4;
}

static void addab(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 2) & 0xf;
  int imm = (insn >> 8) & 0x3ff;
  uint32_t data = (insn & 2) ? cpu->a[src] : cpu->b[src];
  // cross        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  if (insn & 2)
    cpu->b[dst] = data + imm;
  else
    cpu->a[dst] = data + imm;
  cpu->pc += 4;  
}

static void addah(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data + (imm << 1);
  else
    cpu->a[dst] = data + (imm << 1);
  cpu->pc += 4;
}

static void addaw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data + (imm << 2);
  else
    cpu->a[dst] = data + (imm << 2);
  cpu->pc += 4;
}

static void addad(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data + (imm << 3);
  else
    cpu->a[dst] = data + (imm << 3);
  cpu->pc += 4;
}

static void callp(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int cst = (insn >> 7) & 0x1fffff;
  cst <<= 11;
  cst >>= 9;
  cpu->pc = (cia & ~31) + cst;
  cpu->b[3] = cia + 4;
}

static bool taken(SIM_DESC sd, sim_cpu* cpu, sim_cia cia, int creg)
{
  switch (creg) {
  case 0: return true;
  case 1: return cpu->b[0];
  case 2: return cpu->b[1];
  case 3: return cpu->b[2];
  case 4: return cpu->a[1];
  case 5: return cpu->a[2];
  case 6: return cpu->a[0];
  default:
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
    return false;
  }
}

namespace tic6x {
  struct delay32 : delay {
    uint32_t* dst;
    uint32_t src;
    delay32(uint32_t* d, uint32_t s) : dst{d}, src{s} {}
    void exec()
    {
      *dst = src;
    }
  };
} // end of namespace tic6x;

static void
b_cst21(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int cst = (insn >> 7) & 0x1fffff;
  cst <<= 11;
  cst >>= 9;
  int creg = (insn >> 29) & 7;
  if (taken(sd, cpu, cia, creg)) {
    while (delay_slot.size() < 4)
      delay_slot.push_back(nullptr);
    uint32_t addr = (cia & ~31) + cst;
    delay_slot.push_back(new delay32(&cpu->pc, addr));
  }
  cpu->pc += 4;
}

static void
stw_15bit(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int ucst15 = (insn >> 6) & 0x7ffc;
  auto y = (insn >> 7) & 1;
  auto addr = y ? cpu->b[15] : cpu->b[14];
  addr += ucst15;
  auto data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  sim_core_write_aligned_4(cpu, cia, write_map, addr, data);
  cpu->pc += 4;
}

static void stw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if ((insn >> 3) & 1)
    return stw_15bit(sd, cpu, insn, cia);
    
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  switch (mode) {
  case 0x0:
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 2), data);
    break;
  case 0x1:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 2), data);
    break;
  case 0x8:
    while (ucst5--)
      *r -= 4;
    sim_core_write_aligned_4(cpu, cia, write_map, *r, data);
    break;
  case 0xa:
    sim_core_write_aligned_4(cpu, cia, write_map, *r, data);
    while (ucst5--)
      *r -= 4;
    break;
  case 0xe:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+offsetR, data);
    *r -= 4;
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void stb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  switch (mode) {
  case 0x0:
    sim_core_write_aligned_1(cpu, cia, write_map, *r-ucst5, data);
    break;
  case 0x1:
    sim_core_write_aligned_1(cpu, cia, write_map, *r+ucst5, data);
    break;
  case 0xa:
    sim_core_write_aligned_1(cpu, cia, write_map, *r, data);
    while (ucst5--)
      *r -= 4;
    break;
  case 0xe:
    sim_core_write_aligned_1(cpu, cia, write_map, *r+offsetR, data);
    *r -= 4;
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void
ldw_15bit(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int ucst15 = (insn >> 6) & 0x7ffc;
  int y = (insn >> 7) & 1;
  auto addr = y ? cpu->b[15] : cpu->b[14];
  addr += ucst15;
  auto data = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  if (insn & 2)
    delay_slot.push_back(new delay32(&cpu->b[dst], data));
  else
    delay_slot.push_back(new delay32(&cpu->a[dst], data));
  cpu->pc += 4;
}

static void ldw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if ((insn >> 3) & 1)
    return ldw_15bit(sd, cpu, insn, cia);
  
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t* d = (insn & 2) ? &cpu->b[dst] : &cpu->a[dst];
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  switch (mode) {
  case 0x0:
    {
      uint32_t data =
	sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 2));
      delay_slot.push_back(new delay32(d, data)); 
    }
    break;
  case 0x1:
    {
      uint32_t data =
	sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 2));
      delay_slot.push_back(new delay32(d, data));
    }
    break;
  case 0x9:
    {
      while (ucst5--)
	*r += 4;
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data)); 
    }
    break;
  case 0xa:
    {
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data)); 
      while (ucst5--)
	*r -= 4;
    }
    break;
  case 0xc:
    {
      *r -= 4;
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r+offsetR);
      delay_slot.push_back(new delay32(d, data));
    }
    break;
  case 0xe:
    {
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r+offsetR);
      delay_slot.push_back(new delay32(d, data));
      *r -= 4;
    }
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

namespace tic6x {
  struct delay64 : delay {
    uint32_t* dl;
    uint32_t* dh;
    uint32_t sl;
    uint32_t sh;
    delay64(uint32_t* l, uint32_t* h, uint32_t x, uint32_t y)
      : dl{l}, dh{h}, sl{x}, sh{y} {}
    void exec()
    {
      *dl = sl;
      *dh = sh;
    }
  };
};

static void lddw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t* lo = (insn & 2) ? &cpu->b[dst] : &cpu->a[dst];
  uint32_t* hi = (insn & 2) ? &cpu->b[dst+1] : &cpu->a[dst+1];
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  switch (mode) {
  case 0x0:
    {
      uint32_t l = sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 3));
      uint32_t h =
	sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 3)+4);
      delay_slot.push_back(new delay64(lo, hi, l, h));
    }
    break;
  case 0x1:
    {
      uint32_t l = sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 3));
      uint32_t h =
	sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 3)+4);
      delay_slot.push_back(new delay64(lo, hi, l, h));
    }
    break;
  case 0x9:
    {
      while (ucst5--)
	*r += 4;
      uint32_t l = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      uint32_t h = sim_core_read_aligned_4(cpu, cia, read_map, *r+4);
      delay_slot.push_back(new delay64(lo, hi, l, h));
    }
    break;
  case 0xa:
    {
      uint32_t l = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      uint32_t h = sim_core_read_aligned_4(cpu, cia, read_map, *r+4);
      delay_slot.push_back(new delay64(lo, hi, l, h));
      while (ucst5--)
	*r -= 4;
    }
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void
addi_cross(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  imm <<= 27;
  imm >>= 27;
  uint32_t data = (insn & 2) ? cpu->a[src] : cpu->b[src];
  // cross        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  if (insn & 2)
    cpu->b[dst] = data + imm;
  else
    cpu->a[dst] = data + imm;
  cpu->pc += 4;
}

static void addi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  imm <<= 27;
  imm >>= 27;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data + imm;
  else
    cpu->a[dst] = data + imm;
  cpu->pc += 4;
}

static void sub(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  imm <<= 24;
  imm >>= 24;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data - imm;
  else
    cpu->a[dst] = data - imm;
  cpu->pc += 4;
}

static void _or(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0xf;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data | imm;
  else
    cpu->a[dst] = data | imm;
  cpu->pc += 4;
}

static void b(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int r = (insn >> 18) & 0xf;
  uint32_t addr = (insn & 2) ? cpu->b[r] : cpu->a[r];
  while (delay_slot.size() < 4)
    delay_slot.push_back(nullptr);
  delay_slot.push_back(new delay32(&cpu->pc, addr));
  cpu->pc += 4;
}

static void add(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src1 = (insn >> 18) & 0xf;
  if (insn & (1 << 8)) {
    int imm = (insn >> 13) & 0x1f;
    cpu->a[dst] = cpu->a[src1] + imm;
  }
  else {
    int src2 = (insn >> 13) & 0xf;
    cpu->a[dst] = cpu->a[src1] + cpu->a[src2];
  }
  cpu->pc += 4;
}

static void
op0x10(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 11) & 1;
  if (!t)
    return mvk(sd, cpu, insn, cia);
  auto s = (insn >> 10) & 1;
  if (s)
    return addaw(sd, cpu, insn, cia);
  auto u = (insn >> 9) & 1;
  if (!u)
    return add(sd, cpu, insn, cia);
  auto v = (insn >> 6) & 1;
  return v ? addah(sd, cpu, insn, cia) : addab(sd, cpu, insn, cia);
}

static void stdw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t lo = (insn & 2) ? cpu->b[src] : cpu->a[src];
  uint32_t hi = (insn & 2) ? cpu->b[src+1] : cpu->a[src+1];
  switch (mode) {
  case 0x0:
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 3), lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 3)+4, hi);
    break;
  case 0x1:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 3), lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 3)+4, hi);
    break;
  case 0xa:
    sim_core_write_aligned_4(cpu, cia, write_map, *r, lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+4, hi);
    while (ucst5--)
      *r -= 4;
    break;
  case 0xe:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+offsetR, lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+offsetR+4, hi);
    *r -= 4;
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void stndw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t lo = (insn & 2) ? cpu->b[src] : cpu->a[src];
  uint32_t hi = (insn & 2) ? cpu->b[src+1] : cpu->a[src+1];
  switch (mode) {
  case 0x0:
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 3), lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 3)+4, hi);
    break;
  case 0x1:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 3), lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 3)+4, hi);
    break;
  case 0xa:
    sim_core_write_aligned_4(cpu, cia, write_map, *r, lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+4, hi);
    while (ucst5--)
      *r -= 4;
    break;
  case 0xe:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+offsetR, lo);
    sim_core_write_aligned_4(cpu, cia, write_map, *r+offsetR+4, hi);
    *r -= 4;
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void subah(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  imm <<= 24;
  imm >>= 24;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data - (imm << 1);
  else
    cpu->a[dst] = data - (imm << 1);
  cpu->pc += 4;
}

static void subaw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src = (insn >> 18) & 0xf;
  int imm = (insn >> 13) & 0x1f;
  imm <<= 24;
  imm >>= 24;
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  if (insn & 2)
    cpu->b[dst] = data - (imm << 2);
  else
    cpu->a[dst] = data - (imm << 2);
  cpu->pc += 4;
}

static void
op0x30(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 9) & 1;
  if (!t) {
#if 0    
    auto s = (insn >> 11) & 1;
#else
    auto s = (insn >> 12) & 1;
#endif    
    return s ? subaw(sd, cpu, insn, cia) : sub(sd, cpu, insn, cia);
  }
  auto s = (insn >> 8) & 1;
  return s ? subah(sd, cpu, insn, cia) : addad(sd, cpu, insn, cia);
}

static void
op0x19(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = insn & (1 << 8);
  return t ? lddw(sd, cpu, insn, cia) : ldw(sd, cpu, insn, cia);
}

static void ldnw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t* d = (insn & 2) ? &cpu->b[dst] : &cpu->a[dst];
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  switch (mode) {
  case 0x0:
    {
      uint32_t data =
	sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 2));
      delay_slot.push_back(new delay32(d, data)); 
    }
    break;
  case 0x1:
    {
      uint32_t data =
	sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 2));
      delay_slot.push_back(new delay32(d, data)); 
    }
    break;
  case 0x9:
    {
      while (ucst5--)
	*r += 4;
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data)); 
    }
    break;
  case 0xa:
    {
      uint32_t data = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data));
      while (ucst5--)
	*r -= 4;
    }
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void stnw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int src = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t data = (insn & 2) ? cpu->b[src] : cpu->a[src];
  switch (mode) {
  case 0x0:
    sim_core_write_aligned_4(cpu, cia, write_map, *r-(ucst5 << 2), data);
    break;
  case 0x1:
    sim_core_write_aligned_4(cpu, cia, write_map, *r+(ucst5 << 2), data);
    break;
  case 0x9:
    while (ucst5--)
      *r += 4;
    sim_core_write_aligned_4(cpu, cia, write_map, *r, data);
    break;
  case 0xa:
    sim_core_write_aligned_4(cpu, cia, write_map, *r, data);
    while (ucst5--)
      *r -= 4;
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void ldndw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t* lo = (insn & 2) ? &cpu->b[dst] : &cpu->a[dst];
  uint32_t* hi = (insn & 2) ? &cpu->b[dst+1] : &cpu->a[dst+1];
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  switch (mode) {
  case 0x0:
    {
      uint32_t ll =
	sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 3));
      uint32_t hh =
	sim_core_read_aligned_4(cpu, cia, read_map, *r-(ucst5 << 3)+4);
      delay_slot.push_back(new delay64(lo, hi, ll, hh));
    }
    break;
  case 0x1:
    {
      uint32_t ll =
	sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 3));
      uint32_t hh =
	sim_core_read_aligned_4(cpu, cia, read_map, *r+(ucst5 << 3)+4);
      delay_slot.push_back(new delay64(lo, hi, ll, hh));
    }
    break;
  case 0x9:
    {
      while (ucst5--)
	*r += 4;
      uint32_t ll = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      uint32_t hh = sim_core_read_aligned_4(cpu, cia, read_map, *r+4);
      delay_slot.push_back(new delay64(lo, hi, ll, hh));
    }
    break;
  case 0xa:
    {
      uint32_t ll = sim_core_read_aligned_4(cpu, cia, read_map, *r);
      uint32_t hh = sim_core_read_aligned_4(cpu, cia, read_map, *r+4);
      delay_slot.push_back(new delay64(lo, hi, ll, hh));
      while (ucst5--)
	*r -= 4;
    }
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void ldb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int baseR = (insn >> 18) & 0xf;
  int offsetR = (insn >> 13) & 0x1f;
  int ucst5 = offsetR;
  int mode = (insn >> 9) & 0xf;
  uint32_t* r = (insn & (1 << 7)) ? &cpu->b[baseR] : &cpu->a[baseR];
  uint32_t* d = (insn & 2) ? &cpu->b[dst] : &cpu->a[dst];
  while (delay_slot.size() < 3)
    delay_slot.push_back(nullptr);
  switch (mode) {
  case 0x0:
    {
      uint32_t data = sim_core_read_aligned_1(cpu, cia, read_map, *r-ucst5);
      delay_slot.push_back(new delay32(d, data));
    }
    break;
  case 0x1:
    {
      uint32_t data = sim_core_read_aligned_1(cpu, cia, read_map, *r+ucst5);
      delay_slot.push_back(new delay32(d, data));
    }
    break;
  case 0x9:
    {
      while (ucst5--)
	*r += 4;
      uint32_t data = sim_core_read_aligned_1(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data));
    }
    break;
  case 0xa:
    {
      uint32_t data = sim_core_read_aligned_1(cpu, cia, read_map, *r);
      delay_slot.push_back(new delay32(d, data));
      while (ucst5--)
	*r -= 4;
    }
    break;
  default:
    asm("int3");
  }
  cpu->pc += 4;
}

static void
op0x09(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = insn & (1 << 8);
  return t ? ldndw(sd, cpu, insn, cia) : ldb(sd, cpu, insn, cia);
}

static void
op0x1d(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = insn & (1 << 8);
  return t ? stndw(sd, cpu, insn, cia) : stw(sd, cpu, insn, cia);
}

static void
op0x0d(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = insn & (1 << 8);
  return t ? ldnw(sd, cpu, insn, cia) : stb(sd, cpu, insn, cia);
}

static void
op0x1f(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 2) & 1;
  return t ? stw_15bit(sd, cpu, insn, cia) : addaw(sd, cpu, insn, cia);
}

static void
cmpeq(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  using namespace tic6x;
  consumer obj(1);
  int dst = (insn >> 23) & 0xf;
  int src1 = (insn >> 18) & 0xf;
  int src2 = (insn >> 13) & 0xf;
  if (insn & 2) {
    if (cpu->b[src1] == cpu->b[src2])
      cpu->b[dst] = 0xffffffff;
    else
      cpu->b[dst] = 0x0;
  }
  else {
    if (cpu->a[src1] == cpu->a[src2])
      cpu->a[dst] = 0xffffffff;
    else
      cpu->a[dst] = 0x0;
  }
  cpu->pc += 4;
}

static void
op0x04(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 28) & 1;
  return t ? callp(sd, cpu, insn, cia) : b_cst21(sd, cpu, insn, cia);
}

static void
op0x24(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto t = (insn >> 28) & 1;
  return t ? callp(sd, cpu, insn, cia) : b_cst21(sd, cpu, insn, cia);
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x00] = nop;
    (*this)[0x04] = op0x04;
    (*this)[0x09] = op0x09;
    (*this)[0x0a] = mvk;
    (*this)[0x0d] = op0x0d;
    (*this)[0x10] = op0x10;
    (*this)[0x11] = stdw;
    (*this)[0x14] = addk;
    (*this)[0x15] = stnw;
    (*this)[0x18] = b;
    (*this)[0x16] = addi_cross;
    (*this)[0x19] = op0x19;
    (*this)[0x1a] = mvkh;
    (*this)[0x1b] = ldw;
    (*this)[0x1e] = cmpeq;
    (*this)[0x1f] = op0x1f;
    (*this)[0x1d] = op0x1d;
    (*this)[0x24] = op0x24;
    (*this)[0x28] = addi;
    (*this)[0x2a] = mvk;
    (*this)[0x2f] = addab;
    (*this)[0x30] = op0x30;
    (*this)[0x39] = ldw;
    (*this)[0x3b] = ldw;
    (*this)[0x3c] = _or;
    (*this)[0x3d] = stw;
    (*this)[0x3f] = stw;
    
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  uint8_t key = (insn >> 2) & 0x3f;
  auto p = table.find(key);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
