#ifndef TIC6X_PROTOS_H
#define TIC6X_PROTOS_H

namespace tic6x {
  void expand_prologue();
  void expand_epilogue();
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
} // end of namespace tic6x

#endif //  TIC6X_PROTOS_H
