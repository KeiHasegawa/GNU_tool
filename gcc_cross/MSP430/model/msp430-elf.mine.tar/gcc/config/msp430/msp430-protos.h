#ifndef MSP430_PROTOS_H
#define MSP430_PROTOS_H

void msp430_expand_prologue();
void msp430_expand_epilogue();
const char* msp430_movhi(rtx x, rtx y);
const char* msp430_addhi3(rtx x, rtx y, rtx z);
const char* msp430_subhi3(rtx x, rtx y, rtx z);
const char* msp430_call_value(rtx x, rtx fun);

const char* msp430_cbranch(rtx op);

#endif //  MSP430_PROTOS_H
