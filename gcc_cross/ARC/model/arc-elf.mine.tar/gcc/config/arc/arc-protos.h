#ifndef ARC_PROTOS_H
#define ARC_PROTOS_H

namespace arc {
  void expand_prologue();
  void expand_epilogue();
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  namespace si {
    const char* mov(rtx, rtx);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
} // end of namespace arc

#endif //  ARC_PROTOS_H
