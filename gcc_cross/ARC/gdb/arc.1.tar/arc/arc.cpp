#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia arc_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void arc_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t arc_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < 64)
    return cpu->r[rn];
  if (rn == 64)
    return cpu->pc;
  if (rn == 65)
    return cpu->status;
  asm("int3");
  return 0;
}

extern "C"
int arc_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { arc_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void arc_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < 64) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 64) {
    cpu->pc = v;
    return;
  }
  if (rn == 65) {
    cpu->status = v;
    return;
  }
  asm("int3");
}

extern "C"
int arc_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  arc_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 4;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x70] = nop;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  auto p = table.find(insn >> 24);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
