#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia arc_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void arc_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t arc_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < 64)
    return cpu->r[rn];
  if (rn == 64)
    return cpu->pc;
  if (rn == 65)
    return cpu->status;
  asm("int3");
  return 0;
}

extern "C"
int arc_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { arc_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void arc_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < 64) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 64) {
    cpu->pc = v;
    return;
  }
  if (rn == 65) {
    cpu->status = v;
    return;
  }
  asm("int3");
}

extern "C"
int arc_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  arc_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void set_ZN(sim_cpu* cpu, int32_t v)
{
  if (!v)
    cpu->status = (cpu->status & ~(1 << 11)) | (1 << 11);
  if (v < 0)
    cpu->status = (cpu->status & ~(1 << 10)) | (1 << 10);
}

static int32_t sign_ext(int32_t v, int c)
{
  return (v << (31-c)) >> (31-c);
}


static void mov(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint16_t next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int b = ((next >> 9) & 0x38) | ((insn >> 8) & 7);
  uint32_t tmp = next & 0x0f00;
  if (tmp == 0x0f00) {
    // MOV<.cc><.f> b,limm 0010 0bbb 1100 1010 FBBB 11111 00QQ QQQ L
    uint32_t hi = sim_core_read_aligned_2(cpu, cia, read_map, cia+4);
    uint32_t lo = sim_core_read_aligned_2(cpu, cia, read_map, cia+6);
    int32_t imm = (hi << 16) | lo;
    cpu->r[b] = imm;
    set_ZN(cpu, imm); 
    cpu->pc += 8;
    return;
  }

  uint32_t nib2 = (insn >> 4) & 0xf;
  if (nib2 == 0x4) {
    int32_t imm = sign_ext(((next >> 6) & 0x3f) | ((next & 0x3f) << 6), 11);
    cpu->r[b] = imm;
    cpu->pc += 4;
    return;
  }

  // MOV<.cc><.f> b,c 0010 0bbb 1100 1010 FBBB CCCC CC0Q QQQQ
  int c = (next >> 6) & 0x3f;
  cpu->r[b] = cpu->r[c];
  set_ZN(cpu, cpu->r[c]);
  cpu->pc += 4;
}

static void bl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->r[31] = cpu->pc + 4;
  uint32_t next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int32_t rel = sign_ext(((next >> 6) << 11) | (insn & 0x07fc), 18);
  cpu->pc += rel;
  if (cpu->pc & 2)
    cpu->pc -= 2;
}

static void
push_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint8_t tmp = insn;
  switch (tmp) {
  case 0xf1:
    cpu->r[28] -= 4;
    sim_core_write_aligned_4(cpu, cia, write_map, cpu->r[28], cpu->r[31]);
    break;
  default:
    assert(tmp == 0xe1);
    asm("int3");
    break;
  }
  cpu->pc += 2;
}

static uint32_t get_addr(int aa, uint32_t rb, int32_t imm, int zz)
{
  if (aa == 0 || aa == 1)
    return rb + imm;
  if (aa == 2)
    return rb;
  assert(aa == 3);
  switch (zz) {
  case 0:
    return rb + (imm << 2);
  default:
    assert(zz == 2);
    return rb + (imm << 1);
  }
}

static void update_addr(int aa, uint32_t* rb, int32_t imm)
{
  switch (aa) {
  case 0:
    return;
  case 1:
  case 2:
    *rb += imm;
    break;
  default:
    assert(aa == 3);
    return;
  }
}

static void st(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint16_t next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int32_t imm = sign_ext(((next >> 7 ) & 0x100) | (insn & 0xff), 8);
  int b = ((next >> 9) & 0x38) | ((insn >> 8) & 7);
  int c = (next >> 6) & 0x3f;
  int aa = (next >> 3) & 3;
  int zz = (next >> 1) & 3;
  uint32_t addr = get_addr(aa, cpu->r[b], imm, zz);
  sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[c]);
  update_addr(aa, &cpu->r[b], imm);
  cpu->pc += 4;
}

static void mov_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t tmp = insn >> 11;
  if (tmp == 0x1b) {
    // MOV_S b, u 1101 1bbb uuuu uuuu    
    int b = (insn >> 8) & 7;
    uint8_t u = insn;
    cpu->r[b] = u;
    set_ZN(cpu, u);
    cpu->pc += 2;
    return;
  }

  if (tmp == 0x0e) {
    // MOV_S b, h 0111 0bbb hhh0 1HHH
    assert(((insn >> 3) & 3) == 1);
    int b = (insn >> 8) & 7;
    int h = ((insn >> 5) & 7) | ((insn & 7) << 3);
    cpu->r[b] = cpu->r[h];
    set_ZN(cpu, cpu->r[h]);
    cpu->pc += 2;
    return;
  }

  asm("int3");
}

static void set_C(sim_cpu* cpu)
{
  cpu->status = (cpu->status & ~(1 << 9)) | (1 << 9);
}

static void set_V(sim_cpu* cpu)
{
  cpu->status = (cpu->status & ~(1 << 8)) | (1 << 8);
}

static void sub_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint8_t tmp = insn >> 8;
  if (tmp == 0xc1) {
    // sub_s sp, sp, u7
    // 1100 0001 101u uuuu
    if ((insn & 0xe0) != 0xa0)
      sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
    uint8_t u7 = (insn & 0x1f) << 2;
    int32_t sp = cpu->r[28];
    int32_t r = sp - u7;
    if (sp < 0 && r >= 0)
      set_V(cpu);
    if (cpu->r[28] < u7)
      set_C(cpu);
    cpu->r[28] = r;
    set_ZN(cpu, r);
    cpu->pc += 2;
    return;
  }

  /// sub_s b, b, u5
  // 1011 1bbb 011u uuuu
  int b = (insn >> 8) & 7;
  uint8_t u = insn;
  if (cpu->r[b] < u)
    set_C(cpu);
  int32_t rb = cpu->r[b];
  int32_t r = rb - u;
  if (rb < 0 && r >= 0)
    set_V(cpu);
  cpu->r[b] = r;
  set_ZN(cpu, r);
  cpu->pc += 2;
}

static void nop_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 2;
}

static void ld(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  // 0001 0bbb ssss ssss SBBB DaaZ ZXAA AAAA
  uint16_t next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int32_t imm = sign_ext(((next >> 7) & 0x100) | (insn & 0xff), 8);
  int b = ((next >> 9) & 0x38) | ((insn >> 8) & 7);
  int aa = (next >> 9) & 3;
  int zz = (next >> 6) & 3;
  uint32_t addr = get_addr(aa, cpu->r[b], imm, zz);
  int a = next & 0x3f;
  cpu->r[a] = sim_core_read_aligned_4(cpu, cia, write_map, addr);
  update_addr(aa, &cpu->r[b], imm);
  cpu->pc += 4;
}

static void add_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (insn & 0x800) {
    // ADD_S c,b,u3 0110 1bbb ccc0 0uuu
    int b = (insn >> 8) & 7;
    int c = (insn >> 5) & 7;
    int u3 = insn & 7;
    cpu->r[c] = cpu->r[b] + u3;
    cpu->pc += 2;
    return;
  }

  // ADD_S a,b,c  0110 0bbb ccc1 1aaa
  if (!(insn & 0x10))
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  if (!(insn & 0x8))
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  uint8_t a = insn & 7;
  uint8_t b = (insn >> 8) & 7;
  uint8_t c = (insn >> 5) & 7;
  int32_t rb = cpu->r[b];
  int32_t rc = cpu->r[c];
  int32_t ra = rb + rc;
  cpu->r[a] = ra;
  if (rb > 0 && rc > 0 && ra <= 0)
    set_V(cpu);
  if (rb < 0 && rc < 0 && ra >= 0)
    set_V(cpu);
  uint64_t bb = cpu->r[b];
  uint64_t cc = cpu->r[c];
  if ((bb + cc) >> 32)
    set_C(cpu);
  set_ZN(cpu, ra);
  cpu->pc += 2;
}

static void j_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (((insn >> 11) & 0xf) != 0xf)
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  // J_S [blink] 0111 1110 1110 0000
  if (insn == 0x7ee0) {
    cpu->pc = cpu->r[31];
    return;
  }

  // J_S [b] 01111bbb00000000  
  if (insn & 0xff)
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  int b = (insn >> 8) & 7;
  cpu->pc = cpu->r[b];
}

static void sub(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t nib2 = (insn >> 4) & 0xf;
  uint32_t nib3 = insn & 0xf;
  uint16_t next = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  int b = ((next >> 9) & 0x38) | ((insn >> 8) & 7);
  if (nib2 == 8 && nib3 == 2) {
    // SUB<.f> b,b,s12 0010 0bbb 1000 0010 FBBB ssss ssSS SSSS
    int32_t imm = sign_ext(((next >> 6) & 0x3f) | ((next & 0x3f) << 6), 11);
    cpu->r[b] -= imm;
    cpu->pc += 4;
    return;    
  }
  
  if (nib2 == 4 && nib3 == 2) {
    // SUB<.f> a,b,u6 0010 0bbb 0100 0010 FBBB uuuu uuAA AAAA
    int a = next & 0x3f;
    uint32_t u6 = (next >> 6) & 0x3f;
    cpu->r[a] = cpu->r[b] - u6;
    cpu->pc += 4;
    return;
  }

  asm("int3");  
}

static void
op0x2x(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t tmp = insn & 0xf;
  if (tmp == 0xa)
    return mov(sd, cpu, insn, cia);
  return sub(sd, cpu, insn, cia);
}

static void
pop_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint8_t tmp = insn;
  if (tmp == 0xd1) {
    // POP_S blink 1100 0RRR 1101 0001
    cpu->r[31] = sim_core_read_aligned_4(cpu, cia, read_map, cpu->r[28]);
    cpu->r[28] -= 4;
    cpu->pc += 2;
    return;
  }

  if (tmp == 0xc1) {
    // POP_S b 1100 0bbb 1100 0001
    asm("int3");
  }

  sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
}

static void
op0xc0(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint8_t tmp = insn;
  switch (tmp) {
  case 0xf1: case 0xe1:
    return push_s(sd, cpu, insn, cia);
  default:
    assert(tmp == 0xd1);
    return pop_s(sd,cpu, insn, cia);
  }
}

static void
st_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t nib0 = insn >> 12;
  int b = (insn >> 8) & 7;  
  if (nib0 == 0xa) {
    // ST_S c,[b,u7] 1010 0bbb cccu uuuu
    int c = (insn >> 5) & 7;
    uint8_t u7 = (insn & 0x1f) << 2;
    uint32_t addr = cpu->r[b] + u7;
    sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[c]);
    cpu->pc += 2;
    return;
  }

  // ST_S b,[sp,u7] 1100 0bbb 010u uuuu
  assert(nib0 == 0xc);
  assert(((insn >> 5) & 7) == 2);
  int u7 = (insn & 0x1f) << 2;
  uint32_t addr = cpu->r[28] + u7;
  sim_core_write_aligned_4(cpu, cia, write_map, addr, cpu->r[b]);
  cpu->pc += 2;
}


static void
stb_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t nib0 = insn >> 12;
  if (nib0 == 0xa) {
    // STB_S c,[b,u5] 1010 1bbb cccu uuuu
    int b = (insn >> 8) & 7;
    int c = (insn >> 5) & 7;
    int u5 = insn & 0x1f;
    uint32_t addr = cpu->r[b] + u5;
    sim_core_write_aligned_1(cpu, cia, write_map, addr, cpu->r[c]);
    cpu->pc += 2;
    return;
  }

  // STB_S b,[sp,u7] 1100 0bbb 011u uuuu
  asm("int3");
}

static void
cmp_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  // CMP_S b,h 0111 0bbb hhh1 0HHH
  assert(((insn >> 3) & 3) == 2);  
  int b = (insn >> 8) & 7;
  int h = ((insn & 7) << 3) | ((insn >> 5) & 7);
  if (cpu->r[b] < cpu->r[h])
    set_C(cpu);
  int32_t rb = cpu->r[b];
  int32_t rh = cpu->r[h];
  int32_t r = cpu->r[b] - cpu->r[h];    
  if (rb < 0 && rh > 0 && r >= 0)
    set_V(cpu);
  if (rb > 0 && rh < 0 && r <= 0)
    set_V(cpu);
  set_ZN(cpu, r);
  cpu->pc += 2;
}

static void
op0x70(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  uint32_t tmp = (insn >> 3) & 3;
  if (tmp == 2)
    return cmp_s(sd, cpu, insn, cia);
  mov_s(sd, cpu, insn, cia);
}

static void beq_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  // BEQ_S s10 1111 001s ssss ssss
  int imm = sign_ext(insn & 0x1ff, 8) << 1;
  if (cpu->status & (1 << 11)) {
    cpu->pc += imm;
    if (cpu->pc & 2)
      cpu->pc -= 2;
  }
  else
    cpu->pc += 2;
}

static void b_s(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  // B_S s10 1111 000s ssssssss
  int imm = sign_ext(insn & 0x1ff, 8) << 1;
  cpu->pc += imm;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x08] = bl;
    (*this)[0x09] = bl;
    (*this)[0x0a] = bl;
    (*this)[0x0b] = bl;
    (*this)[0x0c] = bl;
    (*this)[0x0e] = bl;
    (*this)[0x0f] = bl;
    (*this)[0x12] = ld;
    (*this)[0x13] = ld;
    (*this)[0x14] = ld;
    (*this)[0x1a] = st;
    (*this)[0x1b] = st;
    (*this)[0x1c] = st;
    (*this)[0x20] = op0x2x;
    (*this)[0x21] = op0x2x;
    (*this)[0x22] = op0x2x;
    (*this)[0x23] = op0x2x;
    (*this)[0x24] = op0x2x;
    (*this)[0x25] = op0x2x;
    (*this)[0x26] = op0x2x;
    (*this)[0x27] = op0x2x;
    (*this)[0x63] = add_s;
    (*this)[0x68] = add_s;
    (*this)[0x6a] = add_s;
    (*this)[0x70] = op0x70;
    (*this)[0x71] = mov_s;    
    (*this)[0x73] = mov_s;
    (*this)[0x78] = nop_s;
    (*this)[0x7e] = j_s;
    (*this)[0xa2] = st_s;
    (*this)[0xa8] = stb_s;    
    (*this)[0xaa] = stb_s;
    (*this)[0xc0] = op0xc0;
    (*this)[0xc1] = sub_s;
    (*this)[0xc2] = st_s;
    (*this)[0xc3] = st_s;
    (*this)[0xd8] = mov_s;
    (*this)[0xd9] = mov_s;
    (*this)[0xdb] = mov_s;
    (*this)[0xda] = mov_s;
    (*this)[0xf0] = b_s;
    (*this)[0xf1] = b_s;
    (*this)[0xf2] = beq_s;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  auto p = table.find(insn >> 8);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
