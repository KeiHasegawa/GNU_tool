#include <stdint.h>
#include "extern.h"
#include "var.h"

#include <cstring>
#include <cassert>
#include <utility>

typedef struct sim_cpu_ sim_cpu;
typedef uint32_t sim_cia;

extern "C" sim_cia m68k_pc_get(sim_cpu* cpu)
{
  return PC;
}

extern "C" void m68k_pc_set(sim_cpu* cpu, sim_cia pc)
{
  PC = pc;
}

uint32_t m68k_reg_get_1(int rn)
{
  if (rn == 17)
    return PC;
  if (rn < 8)
    return D[rn];
  if (rn < 16)
    return A[rn-8];
  if (rn == 16)
    return SR;
  return 0;
}

void m68k_reg_set_1(int rn, uint32_t v)
{
  if (rn == 17) {
    PC = v;
    return;
  }
  if (rn < 8) {
    D[rn] = v;
    return;
  }
  if (rn < 16) {
    A[rn-8] = v;
    return ;
  }
  asm("int3");
}

extern "C" int
m68k_reg_get(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { m68k_reg_get_1(rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" int
m68k_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  m68k_reg_set_1(rn, u.i);
  return length;

}
