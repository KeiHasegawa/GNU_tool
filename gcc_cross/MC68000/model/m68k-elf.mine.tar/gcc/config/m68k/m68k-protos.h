#ifndef M68K_PROTOS_H
#define M68K_PROTOS_H

namespace m68k {
  void expand_prologue();
  void expand_epilogue();
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  const char* call_value(rtx x, rtx fun);
  const char* cbranch(rtx op);
} // end of namespace m68k

#endif //  M68K_PROTOS_H
