#ifndef MCORE_PROTOS_H
#define MCORE_PROTOS_H

void mcore_expand_prologue();
void mcore_expand_epilogue();
const char* mcore_subsi3(rtx x, rtx y, rtx z);
const char* mcore_movsi(rtx x, rtx y);
const char* mcore_addsi3(rtx x, rtx y, rtx z);
const char* mcore_call_value(rtx x, rtx fun);

const char* mcore_cbranch(rtx op);

#endif //  MCORE_PROTOS_H
