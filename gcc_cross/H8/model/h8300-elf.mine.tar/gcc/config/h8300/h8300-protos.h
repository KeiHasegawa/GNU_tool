#ifndef H8300_PROTOS_H
#define H8300_PROTOS_H

void h8300_expand_prologue();
void h8300_expand_epilogue();
const char* h8300_subhi3(rtx x, rtx y, rtx z);
const char* h8300_addhi3(rtx x, rtx y, rtx z);
const char* h8300_movhi(rtx x, rtx y);
const char* h8300_call_value(rtx x, rtx fun);
const char* h8300_pushhi1(rtx x);

const char* h8300_cbranch(rtx op);

#endif //  H8300_PROTOS_H
