#ifndef I960_PROTOS_H
#define I960_PROTOS_H

void i960_expand_prologue();
void i960_expand_epilogue();

const char* i960_movsi(rtx x, rtx y);
const char* i960_call_value(rtx x, rtx fun);
const char* i960_addsi3(rtx x, rtx y, rtx z);
  
const char* i960_cbranch(rtx op);

#endif //  I960_PROTOS_H
