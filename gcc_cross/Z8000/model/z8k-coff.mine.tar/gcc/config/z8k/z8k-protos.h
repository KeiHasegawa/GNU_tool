#ifndef Z8K_PROTOS_H
#define Z8K_PROTOS_H

void z8k_expand_prologue();
void z8k_expand_epilogue();
const char* z8k_movhi(rtx x, rtx y);
const char* z8k_subhi3(rtx x, rtx y, rtx z);

const char* z8k_addhi3(rtx x, rtx y, rtx z);
const char* z8k_call_value(rtx x, rtx fun);

const char* z8k_cbranch(rtx op);

#endif //  Z8K_PROTOS_H
