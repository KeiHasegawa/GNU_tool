/* instruction interpreter module 2
   Copyright (C) 1987, 1992 Free Software Foundation, Inc.

This file is part of Z8KSIM

Z8KSIM is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

Z8KSIM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Z8KZIM; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#include "config.h"
#include <ansidecl.h>
#include "tm.h"
#include "sim.h"

#include "sim-main.h"

#include "inlines.h"

extern SIM_DESC g_sd;
			/* NOT -SHORTCUTS */
/* adc rd,rs */
int sfop_0(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 op_src += COND(context,7);tmp = op_dst + op_src ;;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* adcb rbd,rbs */
int sfop_1(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 op_src += COND(context,7);tmp = op_dst + op_src ;;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,@rs */
int sfop_2(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,address_src */
int sfop_3(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,address_src(rs) */
int sfop_4(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,imm16 */
int sfop_5(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,rs */
int sfop_6(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,@rs */
int sfop_7(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,address_src */
int sfop_8(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,address_src(rs) */
int sfop_9(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,imm8 */
int sfop_10(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,rbs */
int sfop_11(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,@rs */
int sfop_12(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,address_src */
int sfop_13(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,address_src(rs) */
int sfop_14(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,imm32 */
int sfop_15(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,rrs */
int sfop_16(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,@rs */
int sfop_17(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,address_src */
int sfop_18(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,address_src(rs) */
int sfop_19(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,imm16 */
int sfop_20(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,rs */
int sfop_21(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,@rs */
int sfop_22(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,address_src */
int sfop_23(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,address_src(rs) */
int sfop_24(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,imm8 */
int sfop_25(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,rbs */
int sfop_26(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bit @rd,imm4 */
int sfop_27(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit address_dst(rd),imm4 */
int sfop_28(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit address_dst,imm4 */
int sfop_29(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit rd,imm4 */
int sfop_30(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit rd,rs */
int sfop_31(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bitb @rd,imm4 */
int sfop_32(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb address_dst(rd),imm4 */
int sfop_33(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb address_dst,imm4 */
int sfop_34(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb rbd,imm4 */
int sfop_35(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bitb rbd,rs */
int sfop_36(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,8);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bpt */
int sfop_37(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 2;
	{
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* brk */
int sfop_38(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		tmp = fail(context,191);
	}
	return pc;
}
/* call @rd */
int sfop_39(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		put_word_reg(context,15,tmp =  get_word_reg(context,15) - 2);
		put_word_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* call address_dst */
int sfop_40(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		put_word_reg(context,15,tmp =  get_word_reg(context,15) - 2);
		put_word_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* call address_dst(rd) */
int sfop_41(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		put_word_reg(context,15,tmp =  get_word_reg(context,15) - 2);
		put_word_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* calr disp12 */
int sfop_42(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register int FAIL1=fail(context,2);
		tmp = fail(context,10);
	}
	return pc;
}
/* clr @rd */
int sfop_43(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr address_dst */
int sfop_44(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr address_dst(rd) */
int sfop_45(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr rd */
int sfop_46(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* clrb @rd */
int sfop_47(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb address_dst */
int sfop_48(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb address_dst(rd) */
int sfop_49(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb rbd */
int sfop_50(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* com @rd */
int sfop_51(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com address_dst */
int sfop_52(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com address_dst(rd) */
int sfop_53(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com rd */
int sfop_54(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* comb @rd */
int sfop_55(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb address_dst */
int sfop_56(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb address_dst(rd) */
int sfop_57(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb rbd */
int sfop_58(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* comflg flags */
int sfop_59(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		tmp = fail(context,15);
	}
	return pc;
}
/* cp @rd,imm16 */
int sfop_60(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp address_dst(rd),imm16 */
int sfop_61(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register unsigned imm_src=(iwords_2);
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp address_dst,imm16 */
int sfop_62(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register unsigned imm_src=(iwords_2);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,@rs */
int sfop_63(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,address_src */
int sfop_64(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,address_src(rs) */
int sfop_65(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,imm16 */
int sfop_66(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,rs */
int sfop_67(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb @rd,imm8 */
int sfop_68(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb address_dst(rd),imm8 */
int sfop_69(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register unsigned int imm_src=(iwords_2>>8);
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb address_dst,imm8 */
int sfop_70(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register unsigned int imm_src=(iwords_2>>8);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,@rs */
int sfop_71(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,address_src */
int sfop_72(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,address_src(rs) */
int sfop_73(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,imm8 */
int sfop_74(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,rbs */
int sfop_75(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpd rd,@rs,rr,cc */
int sfop_76(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,18);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdb rbd,@rs,rr,cc */
int sfop_77(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,19);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdr rd,@rs,rr,cc */
int sfop_78(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,20);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdrb rbd,@rs,rr,cc */
int sfop_79(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,21);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpi rd,@rs,rr,cc */
int sfop_80(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,22);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpib rbd,@rs,rr,cc */
int sfop_81(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,23);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpir rd,@rs,rr,cc */
int sfop_82(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,24);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpirb rbd,@rs,rr,cc */
int sfop_83(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,25);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpl rrd,@rs */
int sfop_84(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,address_src */
int sfop_85(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,address_src(rs) */
int sfop_86(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,imm32 */
int sfop_87(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,rrs */
int sfop_88(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpsd @rd,@rs,rr,cc */
int sfop_89(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,27);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdb @rd,@rs,rr,cc */
int sfop_90(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,28);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdr @rd,@rs,rr,cc */
int sfop_91(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,29);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdrb @rd,@rs,rr,cc */
int sfop_92(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,30);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsi @rd,@rs,rr,cc */
int sfop_93(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,31);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 		abort(); 	}
	return pc;
}
/* cpsib @rd,@rs,rr,cc */
int sfop_94(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,32);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 		abort(); 	}
	return pc;
}
/* cpsir @rd,@rs,rr,cc */
int sfop_95(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,33);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsirb @rd,@rs,rr,cc */
int sfop_96(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,34);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* dab rbd */
int sfop_97(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,35);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* dbjnz rbd,disp7 */
int sfop_98(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register int FAIL2=fail(context,2);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,36);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* dec @rd,imm4m1 */
int sfop_99(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec address_dst(rd),imm4m1 */
int sfop_100(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec address_dst,imm4m1 */
int sfop_101(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec rd,imm4m1 */
int sfop_102(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* decb @rd,imm4m1 */
int sfop_103(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb address_dst(rd),imm4m1 */
int sfop_104(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb address_dst,imm4m1 */
int sfop_105(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb rbd,imm4m1 */
int sfop_106(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* di i2 */
int sfop_107(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf)&0x2;
		register int op_src = imm_src;
		tmp = fail(context,39);
	}
	return pc;
}
/* div rrd,@rs */
int sfop_108(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,address_src */
int sfop_109(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 107;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,address_src(rs) */
int sfop_110(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,imm16 */
int sfop_111(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 107;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,rs */
int sfop_112(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* divl rqd,@rs */
int sfop_113(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 744;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,address_src */
int sfop_114(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 745;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,address_src(rs) */
int sfop_115(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 746;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,imm32 */
int sfop_116(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 744;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		UDItype op_dst ;
		register int op_src = imm_src;
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,rrs */
int sfop_117(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 744;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		UDItype op_dst ;
		register int op_src = get_long_reg(context,reg_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* djnz rd,disp7 */
int sfop_118(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register int FAIL2=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,42);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ei i2 */
int sfop_119(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf)&0x2;
		register int op_src = imm_src;
		tmp = fail(context,43);
	}
	return pc;
}
/* ex rd,@rs */
int sfop_120(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,address_src */
int sfop_121(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,address_src(rs) */
int sfop_122(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,rs */
int sfop_123(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src; 
		put_word_reg(context,reg_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,@rs */
int sfop_124(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,address_src */
int sfop_125(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,address_src(rs) */
int sfop_126(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,rbs */
int sfop_127(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src; 
		put_byte_reg(context,reg_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ext0e imm8 */
int sfop_128(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext0f imm8 */
int sfop_129(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext8e imm8 */
int sfop_130(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext8f imm8 */
int sfop_131(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* exts rrd */
int sfop_132(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_long_reg(context,reg_dst);
		if (tmp & (1<<15)) {
			tmp |= 0xffff0000;
		}
		else
		{
			tmp &= 0xffff;
		}
		put_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* extsb rd */
int sfop_133(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_word_reg(context,reg_dst);
		if (tmp & (1<<7)) {
			tmp |= 0xffffff00;
		}
		else
		{
			tmp &= 0xff;
		}
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* extsl rqd */
int sfop_134(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_long_reg(context,reg_dst+2);
		if (tmp & (1<<31)) {
			put_long_reg(context,reg_dst, 0xffffffff);
		}
		else
		{
			put_long_reg(context,reg_dst, 0);
		}
	}
	return pc;
}
/* halt */
int sfop_135(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		tmp = fail(context,49);
	}
	return pc;
}
/* in rd,@ri */
int sfop_136(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,50);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* in rd,imm16 */
int sfop_137(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,50);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inb rbd,@ri */
int sfop_138(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,51);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inb rbd,imm16 */
int sfop_139(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,51);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inc @rd,imm4m1 */
int sfop_140(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc address_dst(rd),imm4m1 */
int sfop_141(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc address_dst,imm4m1 */
int sfop_142(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc rd,imm4m1 */
int sfop_143(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* incb @rd,imm4m1 */
int sfop_144(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb address_dst(rd),imm4m1 */
int sfop_145(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb address_dst,imm4m1 */
int sfop_146(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb rbd,imm4m1 */
int sfop_147(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ind @rd,@ri,ra */
int sfop_148(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssss 1000 0000 aaaa ddN0 1000 *** ind @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_150(context,pc,iwords0);
    /* 0011 1011 ssss 1000 0000 aaaa ddN0 0000 *** indr @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,54);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indb @rd,@ri,ra */
int sfop_149(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssss 1000 0000 aaaa ddN0 1000 *** indb @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_151(context,pc,iwords0);
    /* 0011 1010 ssss 1000 0000 aaaa ddN0 0000 *** indrb @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,55);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indr @rd,@ri,ra */
int sfop_150(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,56);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indrb @rd,@ri,ra */
int sfop_151(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,57);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ini @rd,@ri,ra */
int sfop_152(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssss 0000 0000 aaaa ddN0 1000 *** ini @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_154(context,pc,iwords0);
    /* 0011 1011 ssss 0000 0000 aaaa ddN0 0000 *** inir @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,58);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inib @rd,@ri,ra */
int sfop_153(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssss 0000 0000 aaaa ddN0 1000 *** inib @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_155(context,pc,iwords0);
    /* 0011 1010 ssss 0000 0000 aaaa ddN0 0000 *** inirb @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,59);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inir @rd,@ri,ra */
int sfop_154(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,60);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inirb @rd,@ri,ra */
int sfop_155(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,61);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* iret */
int sfop_156(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		tmp = fail(context,62);
	}
	return pc;
}
/* jp cc,@rd */
int sfop_157(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jp cc,address_dst */
int sfop_158(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jp cc,address_dst(rd) */
int sfop_159(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jr cc,disp8 */
int sfop_160(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int op_cc=((iwords_0>>8) & 0xf);
		register unsigned int oplval_dst=((ibytes_1 << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 9)) + pc;
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* ld @rd,imm16 */
int sfop_161(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld @rd,rs */
int sfop_162(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst(rd),imm16 */
int sfop_163(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register unsigned imm_src=(iwords_2);
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst(rd),rs */
int sfop_164(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst,imm16 */
int sfop_165(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register unsigned imm_src=(iwords_2);
		register  int oplval_dst=base_dst;
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst,rs */
int sfop_166(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd(imm16),rs */
int sfop_167(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd(rx),rs */
int sfop_168(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd,@rs */
int sfop_169(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,address_src */
int sfop_170(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,address_src(rs) */
int sfop_171(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,imm16 */
int sfop_172(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs */
int sfop_173(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 3;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs(imm16) */
int sfop_174(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_word_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs(rx) */
int sfop_175(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* lda prd,address_src */
int sfop_176(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		tmp = oplval_src; 
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,address_src(rs) */
int sfop_177(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		tmp = oplval_src; 
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,rs(imm16) */
int sfop_178(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_word_reg(context,reg_src) + (short)(imm_src);
		tmp = oplval_src; 
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,rs(rx) */
int sfop_179(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		tmp = oplval_src; 
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* ldar prd,disp16 */
int sfop_180(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		tmp = fail(context,67);
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* ldb @rd,imm8 */
int sfop_181(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb @rd,rbs */
int sfop_182(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst(rd),imm8 */
int sfop_183(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register unsigned int imm_src=(iwords_2>>8);
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst(rd),rbs */
int sfop_184(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst,imm8 */
int sfop_185(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register unsigned int imm_src=(iwords_2>>8);
		register  int oplval_dst=base_dst;
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst,rbs */
int sfop_186(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb rbd,@rs */
int sfop_187(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,address_src */
int sfop_188(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,address_src(rs) */
int sfop_189(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,imm8 */
int sfop_190(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register unsigned int imm_src=(iwords_0&0xff);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,imm8 */
int sfop_191(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rbs */
int sfop_192(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 3;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rs(imm16) */
int sfop_193(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_word_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rs(rx) */
int sfop_194(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rd(imm16),rbs */
int sfop_195(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb rd(rx),rbs */
int sfop_196(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldctl ctrl,rs */
int sfop_197(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register int FAIL3=fail(context,2);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,69);
	}
	return pc;
}
/* ldctl rd,ctrl */
int sfop_198(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int FAIL3=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,69);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldctlb ctrl,rbs */
int sfop_199(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,189);
	}
	return pc;
}
/* ldctlb rbd,ctrl */
int sfop_200(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,189);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldd @rd,@rs,rr */
int sfop_201(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 1011 1011 ssN0 1001 0000 rrrr ddN0 1000 *** ldd @rd,@rs,rr */
  case 8: break;
  case 0: return sfop_203(context,pc,iwords0);
    /* 1011 1011 ssN0 1001 0000 rrrr ddN0 0000 *** lddr @rd,@rs,rr */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_word_reg(context,reg_src);
			int rd = get_word_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_word_mem_da(context,rd, get_word_mem_da(context,rs));
				rd += -2;
				rs += -2;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_word_reg(context,reg_src, rs);
			put_word_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* lddb @rd,@rs,rr */
int sfop_202(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 1011 1010 ssN0 1001 0000 rrrr ddN0 1000 *** lddb @rd,@rs,rr */
  case 8: break;
  case 0: return sfop_204(context,pc,iwords0);
    /* 1011 1010 ssN0 1001 0000 rrrr ddN0 0000 *** lddrb @rd,@rs,rr */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_word_reg(context,reg_src);
			int rd = get_word_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_byte_mem_da(context,rd, get_byte_mem_da(context,rs));
				rd += -1;
				rs += -1;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_word_reg(context,reg_src, rs);
			put_word_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* lddr @rd,@rs,rr */
int sfop_203(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,183);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* lddrb @rd,@rs,rr */
int sfop_204(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,184);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldi @rd,@rs,rr */
int sfop_205(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 1011 1011 ssN0 0001 0000 rrrr ddN0 1000 *** ldi @rd,@rs,rr */
  case 8: break;
  case 0: return sfop_207(context,pc,iwords0);
    /* 1011 1011 ssN0 0001 0000 rrrr ddN0 0000 *** ldir @rd,@rs,rr */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_word_reg(context,reg_src);
			int rd = get_word_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_word_mem_da(context,rd, get_word_mem_da(context,rs));
				rd += 2;
				rs += 2;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_word_reg(context,reg_src, rs);
			put_word_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* ldib @rd,@rs,rr */
int sfop_206(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 1011 1010 ssN0 0001 0000 rrrr ddN0 1000 *** ldib @rd,@rs,rr */
  case 8: break;
  case 0: return sfop_208(context,pc,iwords0);
    /* 1011 1010 ssN0 0001 0000 rrrr ddN0 0000 *** ldirb @rd,@rs,rr */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_word_reg(context,reg_src);
			int rd = get_word_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_byte_mem_da(context,rd, get_byte_mem_da(context,rs));
				rd += 1;
				rs += 1;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_word_reg(context,reg_src, rs);
			put_word_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* ldir @rd,@rs,rr */
int sfop_207(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,70);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldirb @rd,@rs,rr */
int sfop_208(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,71);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldk rd,imm4 */
int sfop_209(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl @rd,rrs */
int sfop_210(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl address_dst(rd),rrs */
int sfop_211(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl address_dst,rrs */
int sfop_212(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rd(imm16),rrs */
int sfop_213(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rd(rx),rrs */
int sfop_214(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rrd,@rs */
int sfop_215(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,address_src */
int sfop_216(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,address_src(rs) */
int sfop_217(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,imm32 */
int sfop_218(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_src = imm_src;
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rrs */
int sfop_219(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rs(imm16) */
int sfop_220(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_word_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rs(rx) */
int sfop_221(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldm @rd,rs,n */
int sfop_222(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm address_dst(rd),rs,n */
int sfop_223(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_dst=fail(context,123);
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm address_dst,rs,n */
int sfop_224(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_dst=fail(context,123);
		register  int oplval_dst=base_dst;
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,@rs,n */
int sfop_225(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register  int oplval_src = get_word_reg(context,reg_src);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,address_src(rs),n */
int sfop_226(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_src=fail(context,123);
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,address_src,n */
int sfop_227(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_src=fail(context,123);
		register  int oplval_src=base_src;
		tmp = fail(context,74);
	}
	return pc;
}
/* ldps @rs */
int sfop_228(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldps address_src */
int sfop_229(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldps address_src(rs) */
int sfop_230(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldr disp16,rs */
int sfop_231(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,76);
	}
	return pc;
}
/* ldr rd,disp16 */
int sfop_232(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,76);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldrb disp16,rbs */
int sfop_233(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,77);
	}
	return pc;
}
/* ldrb rbd,disp16 */
int sfop_234(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,77);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldrl disp16,rrs */
int sfop_235(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_long_reg(context,reg_src);
		tmp = fail(context,78);
	}
	return pc;
}
/* ldrl rrd,disp16 */
int sfop_236(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_long_reg(context,reg_dst);
		tmp = fail(context,78);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* mbit */
int sfop_237(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		tmp = fail(context,79);
	}
	return pc;
}
/* mreq rd */
int sfop_238(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,80);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* mres */
int sfop_239(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		tmp = fail(context,81);
	}
	return pc;
}
/* mset */
int sfop_240(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		tmp = fail(context,82);
	}
	return pc;
}
/* mult rrd,@rs */
int sfop_241(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,address_src */
int sfop_242(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 70;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,address_src(rs) */
int sfop_243(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,imm16 */
int sfop_244(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 70;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,rs */
int sfop_245(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,@rs */
int sfop_246(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,address_src */
int sfop_247(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 282;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,address_src(rs) */
int sfop_248(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,imm32 */
int sfop_249(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 282;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		UDItype op_dst ;
		register int op_src = imm_src;
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,rrs */
int sfop_250(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		UDItype op_dst ;
		register int op_src = get_long_reg(context,reg_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* neg @rd */
int sfop_251(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg address_dst */
int sfop_252(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg address_dst(rd) */
int sfop_253(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg rd */
int sfop_254(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* negb @rd */
int sfop_255(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb address_dst */
int sfop_256(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb address_dst(rd) */
int sfop_257(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb rbd */
int sfop_258(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* nop */
int sfop_259(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
	}
	return pc;
}
/* or rd,@rs */
int sfop_260(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,address_src */
int sfop_261(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,address_src(rs) */
int sfop_262(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,imm16 */
int sfop_263(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,rs */
int sfop_264(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,@rs */
int sfop_265(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,address_src */
int sfop_266(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,address_src(rs) */
int sfop_267(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,imm8 */
int sfop_268(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,rbs */
int sfop_269(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* otdr @ro,@rs,ra */
int sfop_270(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssN0 1010 0000 aaaa dddd 0000 *** otdr @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_278(context,pc,iwords0);
    /* 0011 1011 ssN0 1010 0000 aaaa dddd 1000 *** outd @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,90);
		abort(); 	}
	return pc;
}
/* otdrb @ro,@rs,ra */
int sfop_271(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssN0 1010 0000 aaaa dddd 0000 *** otdrb @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_279(context,pc,iwords0);
    /* 0011 1010 ssN0 1010 0000 aaaa dddd 1000 *** outdb @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,91);
		abort(); 	}
	return pc;
}
/* otir @ro,@rs,ra */
int sfop_272(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssN0 0010 0000 aaaa dddd 0000 *** otir @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_280(context,pc,iwords0);
    /* 0011 1011 ssN0 0010 0000 aaaa dddd 1000 *** outi @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

  

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,92);
		abort(); 	}
	return pc;
}
/* otirb @ro,@rs,ra */
int sfop_273(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssN0 0010 0000 aaaa dddd 0000 *** otirb @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_281(context,pc,iwords0);
    /* 0011 1010 ssN0 0010 0000 aaaa dddd 1000 *** outib @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,93);
		abort(); 	}
	return pc;
}
/* out @ro,rs */
int sfop_274(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,94);
		abort(); 	}
	return pc;
}
/* out imm16,rs */
int sfop_275(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,94);
	}
	return pc;
}
/* outb @ro,rbs */
int sfop_276(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,95);
		abort(); 	}
	return pc;
}
/* outb imm16,rbs */
int sfop_277(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,95);
	}
	return pc;
}
/* outd @ro,@rs,ra */
int sfop_278(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,96);
		abort(); 	}
	return pc;
}
/* outdb @ro,@rs,ra */
int sfop_279(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,97);
		abort(); 	}
	return pc;
}
/* outi @ro,@rs,ra */
int sfop_280(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,98);
		abort(); 	}
	return pc;
}
/* outib @ro,@rs,ra */
int sfop_281(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,99);
		abort(); 	}
	return pc;
}
/* pop @rd,@rs */
int sfop_282(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop address_dst(rd),@rs */
int sfop_283(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop address_dst,@rs */
int sfop_284(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop rd,@rs */
int sfop_285(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 2);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* popl @rd,@rs */
int sfop_286(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 19;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl address_dst(rd),@rs */
int sfop_287(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 23;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl address_dst,@rs */
int sfop_288(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 23;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl rrd,@rs */
int sfop_289(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_src, oplval_src + 4);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* push @rd,@rs */
int sfop_290(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_word_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,address_src */
int sfop_291(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_word_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,address_src(rs) */
int sfop_292(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_word_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,imm16 */
int sfop_293(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		oplval_dst -= 2;
		put_word_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,rs */
int sfop_294(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_word_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,@rs */
int sfop_295(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 20;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_word_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,address_src */
int sfop_296(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src=base_src;
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_word_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,address_src(rs) */
int sfop_297(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_word_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,rrs */
int sfop_298(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_word_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res @rd,imm4 */
int sfop_299(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res address_dst(rd),imm4 */
int sfop_300(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res address_dst,imm4 */
int sfop_301(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res rd,imm4 */
int sfop_302(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* res rd,rs */
int sfop_303(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst & ~(1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resb @rd,imm4 */
int sfop_304(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb address_dst(rd),imm4 */
int sfop_305(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb address_dst,imm4 */
int sfop_306(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb rbd,imm4 */
int sfop_307(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resb rbd,rs */
int sfop_308(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,105);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resflg flags */
int sfop_309(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		 COND (context, 0x0b);
		{ int on =0;
 			if (imm_src & 1)
			PSW_OVERFLOW = on;
			if (imm_src & 2)
			PSW_SIGN = on;
			if (imm_src & 4)
			PSW_ZERO = on;
			if (imm_src & 8)
			PSW_CARRY = on;
		}
	}
	return pc;
}
/* ret cc */
int sfop_310(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int op_cc=((ibytes_1) & 0xf);
		if(op_cc == 8 || COND(context,op_cc))
{
			pc = get_word_mem_ir(context,15);
			put_word_reg(context,15, get_word_reg(context,15) + 2);
		};
	}
	return pc;
}
/* rl rd,imm1or2 */
int sfop_311(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (15))&1;
			op_dst <<=1;
			if (rotbit) op_dst |= 1;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlb rbd,imm1or2 */
int sfop_312(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (7))&1;
			op_dst <<=1;
			if (rotbit) op_dst |= 1;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlc rd,imm1or2 */
int sfop_313(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (15))&1;
			op_dst <<=1;
			if (context->carry) op_dst |=1;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlcb rbd,imm1or2 */
int sfop_314(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (7))&1;
			op_dst <<=1;
			if (context->carry) op_dst |=1;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rldb rbb,rba */
int sfop_315(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_b=((ibytes_1) & 0xf);
		register int op_aux_b = get_byte_reg(context,reg_aux_b);
		register int op_aux_a = get_byte_reg(context,reg_aux_a);
		tmp = fail(context,112);
	}
	return pc;
}
/* rr rd,imm1or2 */
int sfop_316(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= rotbit << 15;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrb rbd,imm1or2 */
int sfop_317(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= rotbit << 7;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrc rd,imm1or2 */
int sfop_318(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= context->carry << 15;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrcb rbd,imm1or2 */
int sfop_319(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= context->carry << 7;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrdb rbb,rba */
int sfop_320(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_b=((ibytes_1) & 0xf);
		register int op_aux_b = get_byte_reg(context,reg_aux_b);
		register int op_aux_a = get_byte_reg(context,reg_aux_a);
		tmp = fail(context,117);
	}
	return pc;
}
/* rsvd36 */
int sfop_321(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd38 */
int sfop_322(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd78 */
int sfop_323(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd7e */
int sfop_324(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd9d */
int sfop_325(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd9f */
int sfop_326(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvdb9 */
int sfop_327(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvdbf */
int sfop_328(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* sbc rd,rs */
int sfop_329(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 op_src +=  COND(context,7);tmp = op_dst - op_src ;;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sbcb rbd,rbs */
int sfop_330(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,119);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sc imm8 */
int sfop_331(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 33;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		register int op_src = imm_src;
		support_call(context,imm_src);
	}
	return pc;
}
/* sda rd,rs */
int sfop_332(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( short)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdab rbd,rs */
int sfop_333(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( char)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdal rrd,rs */
int sfop_334(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( long)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdl rd,rs */
int sfop_335(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned short)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdlb rbd,rs */
int sfop_336(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned char)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdll rrd,rs */
int sfop_337(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned long)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* set @rd,imm4 */
int sfop_338(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set address_dst(rd),imm4 */
int sfop_339(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set address_dst,imm4 */
int sfop_340(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set rd,imm4 */
int sfop_341(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* set rd,rs */
int sfop_342(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst | (1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setb @rd,imm4 */
int sfop_343(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb address_dst(rd),imm4 */
int sfop_344(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb address_dst,imm4 */
int sfop_345(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb rbd,imm4 */
int sfop_346(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setb rbd,rs */
int sfop_347(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,127);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setflg flags */
int sfop_348(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		 COND (context, 0x0b);
		{ int on =1;
 			if (imm_src & 1)
			PSW_OVERFLOW = on;
			if (imm_src & 2)
			PSW_SIGN = on;
			if (imm_src & 4)
			PSW_ZERO = on;
			if (imm_src & 8)
			PSW_CARRY = on;
		}
	}
	return pc;
}
/* sin rd,imm16 */
int sfop_349(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,129);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sinb rbd,imm16 */
int sfop_350(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,130);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sind @rd,@ri,ra */
int sfop_351(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssss 1001 0000 aaaa ddN0 1000 *** sind @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_353(context,pc,iwords0);
    /* 0011 1011 ssss 1001 0000 aaaa ddN0 0000 *** sindr @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,131);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindb @rd,@ri,ra */
int sfop_352(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssss 1001 0000 aaaa ddN0 1000 *** sindb @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_354(context,pc,iwords0);
    /* 0011 1010 ssss 1001 0000 aaaa ddN0 0000 *** sindrb @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,132);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindr @rd,@ri,ra */
int sfop_353(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,133);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindrb @rd,@ri,ra */
int sfop_354(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,134);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sini @rd,@ri,ra */
int sfop_355(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssss 0001 0000 aaaa ddN0 1000 *** sini @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_357(context,pc,iwords0);
    /* 0011 1011 ssss 0001 0000 aaaa ddN0 0000 *** sinir @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,135);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinib @rd,@ri,ra */
int sfop_356(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssss 0001 0000 aaaa ddN0 1000 *** sinib @rd,@ri,ra */
  case 8: break;
  case 0: return sfop_358(context,pc,iwords0);
    /* 0011 1010 ssss 0001 0000 aaaa ddN0 0000 *** sinirb @rd,@ri,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,136);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinir @rd,@ri,ra */
int sfop_357(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,137);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinirb @rd,@ri,ra */
int sfop_358(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,138);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sla rd,imm8 */
int sfop_359(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b2 = get_byte_mem_da(context,pc+2);
  switch (b2 & 0xff) {
    /* 1011 0011 dddd 1001 0000 0000 imm8 *** sla rd,imm8 */
  case 0: break;
  case 0xff: return sfop_375(context,pc,iwords0);
    /* 1011 0011 dddd 1001 1111 1111 nim8 *** sra rd,imm8 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( short)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slab rbd,imm4 */
int sfop_360(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 0xf0) {
    /* 1011 0010 dddd 1001 iiii iiii 0000 imm4 *** slab rbd,imm4 */
  case 0: break;
  case 0xf0: return sfop_376(context,pc,iwords0);
    /* 1011 0010 dddd 1001 iiii iiii 1111 nim4 *** srab rbd,imm4 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( char)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slal rrd,imm8 */
int sfop_361(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b2 = get_byte_mem_da(context,pc+2);
  switch (b2 & 0xff) {
    /* 1011 0011 dddd 1101 0000 0000 imm8 *** slal rrd,imm8 */
  case 0: break;
  case 0xff: return sfop_377(context,pc,iwords0);
    /* 1011 0011 dddd 1101 1111 1111 nim8 *** sral rrd,imm8 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( long)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sll rd,imm8 */
int sfop_362(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b2 = get_byte_mem_da(context,pc+2);
  switch (b2 & 0xff) {
    /* 1011 0011 dddd 0001 0000 0000 imm8 *** sll rd,imm8 */
  case 0: break;
  case 0xff: return sfop_378(context,pc,iwords0);
    /* 1011 0011 dddd 0001 1111 1111 nim8 *** srl rd,imm8 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned short)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sllb rbd,imm4 */
int sfop_363(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 0xf0) {
    /* 1011 0010 dddd 0001 iiii iiii 0000 imm4 *** sllb rbd,imm4 */
  case 0: break;
  case 0xf0: return sfop_379(context,pc,iwords0);
    /* 1011 0010 dddd 0001 iiii iiii 1111 nim4 *** srlb rbd,imm4 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned char)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slll rrd,imm8 */
int sfop_364(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b2 = get_byte_mem_da(context,pc+2);
  switch (b2 & 0xff) {
    /* 1011 0011 dddd 0101 0000 0000 imm8 *** slll rrd,imm8 */
  case 0: break;
  case 0xff: return sfop_380(context,pc,iwords0);
    /* 1011 0011 dddd 0101 1111 1111 nim8 *** srll rrd,imm8 */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned long)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sotdr @ro,@rs,ra */
int sfop_365(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1011 ssN0 1011 0000 aaaa dddd 0000 *** sotdr @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_371(context,pc,iwords0);
    /* 0011 1011 ssN0 1011 0000 aaaa dddd 1000 *** soutd @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,145);
		abort(); 	}
	return pc;
}
/* sotdrb @ro,@rs,ra */
int sfop_366(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssN0 1011 0000 aaaa dddd 0000 *** sotdrb @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_372(context,pc,iwords0);
    /* 0011 1010 ssN0 1011 0000 aaaa dddd 1000 *** soutdb @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,146);
		abort(); 	}
	return pc;
}
/* sotir @ro,@rs,ra */
int sfop_367(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssN0 0011 0000 aaaa dddd 0000 *** sotirb @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_373(context,pc,iwords0);
    /* 0011 1011 ssN0 0011 0000 aaaa dddd 1000 *** souti @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }
  
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,147);
		abort(); 	}
	return pc;
}
/* sotirb @ro,@rs,ra */
int sfop_368(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  uint8_t b3 = get_byte_mem_da(context,pc+3);
  switch (b3 & 15) {
    /* 0011 1010 ssN0 0011 0000 aaaa dddd 0000 *** sotirb @ro,@rs,ra */
  case 0: break;
  case 8: return sfop_374(context,pc,iwords0);
    /* 0011 1010 ssN0 0011 0000 aaaa dddd 1000 *** soutib @ro,@rs,ra */
  default:
    sim_engine_halt(g_sd, g_cpu, 0, g_cia, sim_stopped, SIM_SIGILL);
    break;
  }

	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,148);
		abort(); 	}
	return pc;
}
/* sout imm16,rs */
int sfop_369(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,149);
	}
	return pc;
}
/* soutb imm16,rbs */
int sfop_370(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,150);
	}
	return pc;
}
/* soutd @ro,@rs,ra */
int sfop_371(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,151);
		abort(); 	}
	return pc;
}
/* soutdb @ro,@rs,ra */
int sfop_372(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,152);
		abort(); 	}
	return pc;
}
/* souti @ro,@rs,ra */
int sfop_373(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,153);
		abort(); 	}
	return pc;
}
/* soutib @ro,@rs,ra */
int sfop_374(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,154);
		abort(); 	}
	return pc;
}
/* sra rd,imm8 */
int sfop_375(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,155);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srab rbd,imm4 */
int sfop_376(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src = - ((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,156);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sral rrd,imm8 */
int sfop_377(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,157);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srl rd,imm8 */
int sfop_378(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,158);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srlb rbd,imm4 */
int sfop_379(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src = - ((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,159);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srll rrd,imm8 */
int sfop_380(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,160);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,@rs */
int sfop_381(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,address_src */
int sfop_382(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,address_src(rs) */
int sfop_383(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,imm16 */
int sfop_384(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,rs */
int sfop_385(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,@rs */
int sfop_386(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,address_src */
int sfop_387(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,address_src(rs) */
int sfop_388(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,imm8 */
int sfop_389(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,rbs */
int sfop_390(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,@rs */
int sfop_391(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,address_src */
int sfop_392(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,address_src(rs) */
int sfop_393(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,imm32 */
int sfop_394(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,rrs */
int sfop_395(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* tcc cc,rd */
int sfop_396(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		if(op_cc == 8 || COND(context,op_cc)) put_word_reg(context,reg_dst, 1);
	}
	return pc;
}
/* tccb cc,rbd */
int sfop_397(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		if(op_cc == 8 || COND(context,op_cc)) put_word_reg(context,reg_dst, 1);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* test @rd */
int sfop_398(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* test address_dst */
int sfop_399(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}

uint16_t first_arg(sim_state_type* context, _Bool ref_stack)
{
  if (ref_stack) {
    uint16_t sp = context->regs[15].word;
    uint16_t arg = get_word_mem_da(context, sp+2);
    return arg;
  }
  
  uint16_t arg = context->regs[7].word;
  return arg;
}

const char* first_string(sim_state_type* context, int pc, _Bool ref_stack)
{
  uint16_t addr = first_arg(context, ref_stack);
  static char buf[1024];
  for (int i = 0 ; i != sizeof buf/sizeof buf[0] ; ++i) {
    char c = get_byte_mem_da(context, addr+i);
    buf[i] = c;
    if (c == '\0')
      return &buf[0]; // OK
  }
  abort(); // not enough buffer
}

enum arg_class { NONE, WORD, LONG, LONG_LONG, DF, LDF, STR };

static const char* get_part(const char* fmt, enum arg_class* how)
{
  for ( ; *fmt ; ++fmt) {
    char c = *fmt;
    if (c == 'd' || c == 'i' || c == 'x' || c == 'u') {
      if (*how == NONE)
	*how = WORD;
      return ++fmt;
    }
    if (c == 'c') {
      *how = WORD;
      return ++fmt;
    }
    if (c == 'f') {
      char prev = *(fmt-1);
      *how = prev == 'L' ? LDF : DF;
      return ++fmt;
    }
    if (c == 's') {
      *how = STR;
      return ++fmt;
    }
    if (c == 'l') {
      if (*how == NONE)
	*how = LONG;
      else
	*how = LONG_LONG;
    }
  }
  abort(); // unexpected format
}

#include <assert.h>

static int arg16(sim_state_type* context, int nth)
{
  assert(nth);
  int sp = context->regs[15].word;
  int addr = sp + 2 * (nth+1);
  return (uint16_t)get_word_mem_da(context, addr);
}

static int arg32(sim_state_type* context, int nth)
{
  assert(nth);
  int sp = context->regs[15].word;
  int addr = sp + 2 * (nth+1);
  return get_long_mem_da(context, addr);
}

static uint64_t arg64(sim_state_type* context, int nth)
{
  int sp = context->regs[15].word;
  int addr = sp + 2 * (nth+1);
  uint64_t hi = (uint32_t)get_long_mem_da(context, addr);
  uint64_t lo = (uint32_t)get_long_mem_da(context, addr+4);
  return (hi << 32) | lo;
}

const char* handle(sim_state_type* context, int pc,
		   const char* fmt, int* nth, int* ret)
{
  char c = *fmt;
  if (c != '%') {
    putchar(c);
    ++*ret;
    return fmt+1;
  }
  const char* beg = fmt;
  c = *++fmt;
  if (c == '%') {
    putchar(c);
    ++*ret;
    return fmt+1;
  }
  enum arg_class how = NONE;
  const char* end = get_part(fmt, &how);
  char part_fmt[256];
  int n = end - beg;
  assert(n + 1 < sizeof part_fmt/sizeof part_fmt[0]);
  strncpy(&part_fmt[0], beg, n);
  part_fmt[n] = '\0';
  if (how == WORD) {
    int arg = arg16(context, (*nth)++);
    *ret += printf(part_fmt, arg);
    return end;
  }
  if (how == LONG) {
    uint64_t arg = arg32(context, *nth);
    *nth += 2;
    *ret += printf(part_fmt, arg);
    return end;
  }
  if (how == LONG_LONG) {
    uint64_t arg = arg64(context, *nth);
    *nth += 4;
    *ret += printf(part_fmt, arg);
    return end;
  }
  if (how == DF || how == LDF) {
    union {
      uint64_t i;
      double d;
    } u = { arg64(context, *nth) };
    *nth += 4;
    if (how == DF)
      *ret += printf(part_fmt, u.d);
    else
      *ret += printf(part_fmt, (long double)u.d);
    return end;
  }
  if (how == STR) {
    uint32_t addr = arg16(context, (*nth)++);
    char buf[256];
    for (int i = 0 ; i != sizeof buf/sizeof buf[0] ; ++i) {
      char c = get_byte_mem_da(context, addr+i);
      buf[i] = c;
      if (c == '\0') {
	*ret += printf(part_fmt, &buf[0]);  // ok
	return end;
      }
    }
    abort(); // not enough buffer
    return end;
  }
  abort();  // unexpected format string
  return end;
}

void do_printf(sim_state_type* context, int pc)
{
  const char* fmt = first_string(context, pc, TRUE);
  int nargc = 1;
  int ret = 0;
  while (*fmt)
    fmt = handle(context, pc, fmt, &nargc, &ret);
  context->regs[2].word = ret;
}

void do_puts(sim_state_type* context, int pc)
{
  const char* arg = first_string(context, pc, FALSE);
  int ret = puts(arg);
  context->regs[2].word = ret;
}

void do_putchar(sim_state_type* context, int pc)
{
  int arg = first_arg(context, FALSE);
  int ret = putchar(arg);
  context->regs[2].word = ret;
}

/* test address_dst(rd) */
int sfop_400(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
  switch (iwords0) {
  case 0x0c00: exit(0);
  case 0x0c01: do_printf(context, pc);  return pc+2;
  case 0x0c02: do_puts(context, pc);    return pc+2;
  case 0x0c03: do_putchar(context, pc); return pc+2;
  }
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* test rd */
int sfop_401(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* testb @rd */
int sfop_402(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb address_dst */
int sfop_403(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb address_dst(rd) */
int sfop_404(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb rbd */
int sfop_405(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testl @rd */
int sfop_406(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl address_dst */
int sfop_407(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 16;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl address_dst(rd) */
int sfop_408(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl rrd */
int sfop_409(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* trdb @rd,@rs,rr */
int sfop_410(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,169);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trdrb @rd,@rs,rr */
int sfop_411(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,170);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trib @rd,@rs,rr */
int sfop_412(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,171);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trirb @rd,@rs,rr */
int sfop_413(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,172);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trtdb @ra,@rb,rr */
int sfop_414(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_word_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_word_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,190);
	}
	return pc;
}
/* trtdrb @ra,@rb,rr */
int sfop_415(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_word_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_word_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,173);
	}
	return pc;
}
/* trtib @ra,@rb,rr */
int sfop_416(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_word_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_word_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,174);
	}
	return pc;
}
/* trtirb @ra,@rb,rr */
int sfop_417(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_word_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_word_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,175);
	}
	return pc;
}
/* tset @rd */
int sfop_418(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset address_dst */
int sfop_419(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset address_dst(rd) */
int sfop_420(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset rd */
int sfop_421(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,177);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* tsetb @rd */
int sfop_422(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_word_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb address_dst */
int sfop_423(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned base_dst=iwords_1;
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb address_dst(rd) */
int sfop_424(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=iwords_1;
		register  unsigned short oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb rbd */
int sfop_425(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,178);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,@rs */
int sfop_426(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,address_src */
int sfop_427(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,address_src(rs) */
int sfop_428(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,imm16 */
int sfop_429(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,rs */
int sfop_430(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,@rs */
int sfop_431(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_word_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,address_src */
int sfop_432(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,address_src(rs) */
int sfop_433(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=iwords_1;
		register  unsigned short oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,imm8 */
int sfop_434(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,rbs */
int sfop_435(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
int sfop_436(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_437(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_438(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_439(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_440(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_441(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_442(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_443(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_444(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_445(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_446(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_447(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_448(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_449(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_450(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_451(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_452(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_453(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_454(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_455(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_456(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_457(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_458(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_459(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_460(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_461(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_462(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_463(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_464(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_465(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_466(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_467(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_468(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_469(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_470(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_471(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_472(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_473(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_474(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_475(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_476(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_477(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_478(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_479(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_480(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_481(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_482(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_483(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_484(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_485(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_486(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_487(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_488(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_489(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_490(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_491(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_492(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_493(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_494(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_495(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_496(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_497(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_498(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_499(context,pc)
sim_state_type *context;
int pc;
{ sfop_bad1();return pc; }
int sfop_bad() ;
int (*(sfop_table[]))() = {	sfop_0
,	sfop_1
,	sfop_2
,	sfop_3
,	sfop_4
,	sfop_5
,	sfop_6
,	sfop_7
,	sfop_8
,	sfop_9
,	sfop_10
,	sfop_11
,	sfop_12
,	sfop_13
,	sfop_14
,	sfop_15
,	sfop_16
,	sfop_17
,	sfop_18
,	sfop_19
,	sfop_20
,	sfop_21
,	sfop_22
,	sfop_23
,	sfop_24
,	sfop_25
,	sfop_26
,	sfop_27
,	sfop_28
,	sfop_29
,	sfop_30
,	sfop_31
,	sfop_32
,	sfop_33
,	sfop_34
,	sfop_35
,	sfop_36
,	sfop_37
,	sfop_38
,	sfop_39
,	sfop_40
,	sfop_41
,	sfop_42
,	sfop_43
,	sfop_44
,	sfop_45
,	sfop_46
,	sfop_47
,	sfop_48
,	sfop_49
,	sfop_50
,	sfop_51
,	sfop_52
,	sfop_53
,	sfop_54
,	sfop_55
,	sfop_56
,	sfop_57
,	sfop_58
,	sfop_59
,	sfop_60
,	sfop_61
,	sfop_62
,	sfop_63
,	sfop_64
,	sfop_65
,	sfop_66
,	sfop_67
,	sfop_68
,	sfop_69
,	sfop_70
,	sfop_71
,	sfop_72
,	sfop_73
,	sfop_74
,	sfop_75
,	sfop_76
,	sfop_77
,	sfop_78
,	sfop_79
,	sfop_80
,	sfop_81
,	sfop_82
,	sfop_83
,	sfop_84
,	sfop_85
,	sfop_86
,	sfop_87
,	sfop_88
,	sfop_89
,	sfop_90
,	sfop_91
,	sfop_92
,	sfop_93
,	sfop_94
,	sfop_95
,	sfop_96
,	sfop_97
,	sfop_98
,	sfop_99
,	sfop_100
,	sfop_101
,	sfop_102
,	sfop_103
,	sfop_104
,	sfop_105
,	sfop_106
,	sfop_107
,	sfop_108
,	sfop_109
,	sfop_110
,	sfop_111
,	sfop_112
,	sfop_113
,	sfop_114
,	sfop_115
,	sfop_116
,	sfop_117
,	sfop_118
,	sfop_119
,	sfop_120
,	sfop_121
,	sfop_122
,	sfop_123
,	sfop_124
,	sfop_125
,	sfop_126
,	sfop_127
,	sfop_128
,	sfop_129
,	sfop_130
,	sfop_131
,	sfop_132
,	sfop_133
,	sfop_134
,	sfop_135
,	sfop_136
,	sfop_137
,	sfop_138
,	sfop_139
,	sfop_140
,	sfop_141
,	sfop_142
,	sfop_143
,	sfop_144
,	sfop_145
,	sfop_146
,	sfop_147
,	sfop_148
,	sfop_149
,	sfop_150
,	sfop_151
,	sfop_152
,	sfop_153
,	sfop_154
,	sfop_155
,	sfop_156
,	sfop_157
,	sfop_158
,	sfop_159
,	sfop_160
,	sfop_161
,	sfop_162
,	sfop_163
,	sfop_164
,	sfop_165
,	sfop_166
,	sfop_167
,	sfop_168
,	sfop_169
,	sfop_170
,	sfop_171
,	sfop_172
,	sfop_173
,	sfop_174
,	sfop_175
,	sfop_176
,	sfop_177
,	sfop_178
,	sfop_179
,	sfop_180
,	sfop_181
,	sfop_182
,	sfop_183
,	sfop_184
,	sfop_185
,	sfop_186
,	sfop_187
,	sfop_188
,	sfop_189
,	sfop_190
,	sfop_191
,	sfop_192
,	sfop_193
,	sfop_194
,	sfop_195
,	sfop_196
,	sfop_197
,	sfop_198
,	sfop_199
,	sfop_200
,	sfop_201
,	sfop_202
,	sfop_203
,	sfop_204
,	sfop_205
,	sfop_206
,	sfop_207
,	sfop_208
,	sfop_209
,	sfop_210
,	sfop_211
,	sfop_212
,	sfop_213
,	sfop_214
,	sfop_215
,	sfop_216
,	sfop_217
,	sfop_218
,	sfop_219
,	sfop_220
,	sfop_221
,	sfop_222
,	sfop_223
,	sfop_224
,	sfop_225
,	sfop_226
,	sfop_227
,	sfop_228
,	sfop_229
,	sfop_230
,	sfop_231
,	sfop_232
,	sfop_233
,	sfop_234
,	sfop_235
,	sfop_236
,	sfop_237
,	sfop_238
,	sfop_239
,	sfop_240
,	sfop_241
,	sfop_242
,	sfop_243
,	sfop_244
,	sfop_245
,	sfop_246
,	sfop_247
,	sfop_248
,	sfop_249
,	sfop_250
,	sfop_251
,	sfop_252
,	sfop_253
,	sfop_254
,	sfop_255
,	sfop_256
,	sfop_257
,	sfop_258
,	sfop_259
,	sfop_260
,	sfop_261
,	sfop_262
,	sfop_263
,	sfop_264
,	sfop_265
,	sfop_266
,	sfop_267
,	sfop_268
,	sfop_269
,	sfop_270
,	sfop_271
,	sfop_272
,	sfop_273
,	sfop_274
,	sfop_275
,	sfop_276
,	sfop_277
,	sfop_278
,	sfop_279
,	sfop_280
,	sfop_281
,	sfop_282
,	sfop_283
,	sfop_284
,	sfop_285
,	sfop_286
,	sfop_287
,	sfop_288
,	sfop_289
,	sfop_290
,	sfop_291
,	sfop_292
,	sfop_293
,	sfop_294
,	sfop_295
,	sfop_296
,	sfop_297
,	sfop_298
,	sfop_299
,	sfop_300
,	sfop_301
,	sfop_302
,	sfop_303
,	sfop_304
,	sfop_305
,	sfop_306
,	sfop_307
,	sfop_308
,	sfop_309
,	sfop_310
,	sfop_311
,	sfop_312
,	sfop_313
,	sfop_314
,	sfop_315
,	sfop_316
,	sfop_317
,	sfop_318
,	sfop_319
,	sfop_320
,	sfop_321
,	sfop_322
,	sfop_323
,	sfop_324
,	sfop_325
,	sfop_326
,	sfop_327
,	sfop_328
,	sfop_329
,	sfop_330
,	sfop_331
,	sfop_332
,	sfop_333
,	sfop_334
,	sfop_335
,	sfop_336
,	sfop_337
,	sfop_338
,	sfop_339
,	sfop_340
,	sfop_341
,	sfop_342
,	sfop_343
,	sfop_344
,	sfop_345
,	sfop_346
,	sfop_347
,	sfop_348
,	sfop_349
,	sfop_350
,	sfop_351
,	sfop_352
,	sfop_353
,	sfop_354
,	sfop_355
,	sfop_356
,	sfop_357
,	sfop_358
,	sfop_359
,	sfop_360
,	sfop_361
,	sfop_362
,	sfop_363
,	sfop_364
,	sfop_365
,	sfop_366
,	sfop_367
,	sfop_368
,	sfop_369
,	sfop_370
,	sfop_371
,	sfop_372
,	sfop_373
,	sfop_374
,	sfop_375
,	sfop_376
,	sfop_377
,	sfop_378
,	sfop_379
,	sfop_380
,	sfop_381
,	sfop_382
,	sfop_383
,	sfop_384
,	sfop_385
,	sfop_386
,	sfop_387
,	sfop_388
,	sfop_389
,	sfop_390
,	sfop_391
,	sfop_392
,	sfop_393
,	sfop_394
,	sfop_395
,	sfop_396
,	sfop_397
,	sfop_398
,	sfop_399
,	sfop_400
,	sfop_401
,	sfop_402
,	sfop_403
,	sfop_404
,	sfop_405
,	sfop_406
,	sfop_407
,	sfop_408
,	sfop_409
,	sfop_410
,	sfop_411
,	sfop_412
,	sfop_413
,	sfop_414
,	sfop_415
,	sfop_416
,	sfop_417
,	sfop_418
,	sfop_419
,	sfop_420
,	sfop_421
,	sfop_422
,	sfop_423
,	sfop_424
,	sfop_425
,	sfop_426
,	sfop_427
,	sfop_428
,	sfop_429
,	sfop_430
,	sfop_431
,	sfop_432
,	sfop_433
,	sfop_434
,	sfop_435
,	sfop_436
,	sfop_437
,	sfop_438
,	sfop_439
,	sfop_440
,	sfop_441
,	sfop_442
,	sfop_443
,	sfop_444
,	sfop_445
,	sfop_446
,	sfop_447
,	sfop_448
,	sfop_449
,	sfop_450
,	sfop_451
,	sfop_452
,	sfop_453
,	sfop_454
,	sfop_455
,	sfop_456
,	sfop_457
,	sfop_458
,	sfop_459
,	sfop_460
,	sfop_461
,	sfop_462
,	sfop_463
,	sfop_464
,	sfop_465
,	sfop_466
,	sfop_467
,	sfop_468
,	sfop_469
,	sfop_470
,	sfop_471
,	sfop_472
,	sfop_473
,	sfop_474
,	sfop_475
,	sfop_476
,	sfop_477
,	sfop_478
,	sfop_479
,	sfop_480
,	sfop_481
,	sfop_482
,	sfop_483
,	sfop_484
,	sfop_485
,	sfop_486
,	sfop_487
,	sfop_488
,	sfop_489
,	sfop_490
,	sfop_491
,	sfop_492
,	sfop_493
,	sfop_494
,	sfop_495
,	sfop_496
,	sfop_497
,	sfop_498
,	sfop_499
};



