/* instruction interpreter module 3
   Copyright (C) 1992, 1993 Free Software Foundation, Inc.

This file is part of Z8KSIM

Z8KSIM is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

Z8KSIM is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Z8KZIM; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#include "config.h"
#define ushort_type unsigned short
#include <ansidecl.h>
#include "tm.h"
#include "sim.h"
#include "inlines.h"

			/* NOT -SHORTCUTS */
/* adc rd,rs */
int bfop_0(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 op_src += COND(context,7);tmp = op_dst + op_src ;;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* adcb rbd,rbs */
int bfop_1(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 op_src += COND(context,7);tmp = op_dst + op_src ;;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,@rs */
int bfop_2(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,address_src */
int bfop_3(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,address_src(rs) */
int bfop_4(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,imm16 */
int bfop_5(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* add rd,rs */
int bfop_6(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,@rs */
int bfop_7(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,address_src */
int bfop_8(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,address_src(rs) */
int bfop_9(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,imm8 */
int bfop_10(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addb rbd,rbs */
int bfop_11(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,@rs */
int bfop_12(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,address_src */
int bfop_13(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,address_src(rs) */
int bfop_14(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,imm32 */
int bfop_15(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* addl rrd,rrs */
int bfop_16(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,0); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,@rs */
int bfop_17(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,address_src */
int bfop_18(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,address_src(rs) */
int bfop_19(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,imm16 */
int bfop_20(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* and rd,rs */
int bfop_21(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,@rs */
int bfop_22(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,address_src */
int bfop_23(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,address_src(rs) */
int bfop_24(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,imm8 */
int bfop_25(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* andb rbd,rbs */
int bfop_26(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst & op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bit @rd,imm4 */
int bfop_27(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit address_dst(rd),imm4 */
int bfop_28(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit address_dst,imm4 */
int bfop_29(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit rd,imm4 */
int bfop_30(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bit rd,rs */
int bfop_31(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		context->zero = (op_dst & (1<<op_src))==0;
		context->broken_flags = 0;
	}
	return pc;
}
/* bitb @rd,imm4 */
int bfop_32(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb address_dst(rd),imm4 */
int bfop_33(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb address_dst,imm4 */
int bfop_34(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* bitb rbd,imm4 */
int bfop_35(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,8);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bitb rbd,rs */
int bfop_36(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,8);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* bpt */
int bfop_37(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 2;
	{
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* brk */
int bfop_38(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		tmp = fail(context,191);
	}
	return pc;
}
/* call @rd */
int bfop_39(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		put_ptr_long_reg(context,14,tmp =  get_ptr_long_reg(context,14) - 4);
		put_ptr_long_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* call address_dst */
int bfop_40(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		put_ptr_long_reg(context,14,tmp =  get_ptr_long_reg(context,14) - 4);
		put_ptr_long_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* call address_dst(rd) */
int bfop_41(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		put_ptr_long_reg(context,14,tmp =  get_ptr_long_reg(context,14) - 4);
		put_ptr_long_mem_da(context,tmp, pc);
		pc = oplval_dst;
	}
	return pc;
}
/* calr disp12 */
int bfop_42(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register int FAIL1=fail(context,2);
		tmp = fail(context,10);
	}
	return pc;
}
/* clr @rd */
int bfop_43(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr address_dst */
int bfop_44(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr address_dst(rd) */
int bfop_45(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = 0;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clr rd */
int bfop_46(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* clrb @rd */
int bfop_47(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb address_dst */
int bfop_48(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb address_dst(rd) */
int bfop_49(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = 0;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* clrb rbd */
int bfop_50(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* com @rd */
int bfop_51(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com address_dst */
int bfop_52(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com address_dst(rd) */
int bfop_53(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* com rd */
int bfop_54(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* comb @rd */
int bfop_55(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb address_dst */
int bfop_56(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb address_dst(rd) */
int bfop_57(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* comb rbd */
int bfop_58(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		 tmp = ~ op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* comflg flags */
int bfop_59(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		tmp = fail(context,15);
	}
	return pc;
}
/* cp @rd,imm16 */
int bfop_60(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp address_dst(rd),imm16 */
int bfop_61(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned imm_src=(iwords_3);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp address_dst,imm16 */
int bfop_62(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned imm_src=(iwords_3);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,@rs */
int bfop_63(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,address_src */
int bfop_64(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,address_src(rs) */
int bfop_65(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,imm16 */
int bfop_66(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cp rd,rs */
int bfop_67(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb @rd,imm8 */
int bfop_68(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb address_dst(rd),imm8 */
int bfop_69(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned int imm_src=(/* WHO */iwords_3&0xff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb address_dst,imm8 */
int bfop_70(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned int imm_src=(/* WHO */iwords_3&0xff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,@rs */
int bfop_71(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,address_src */
int bfop_72(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,address_src(rs) */
int bfop_73(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,imm8 */
int bfop_74(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpb rbd,rbs */
int bfop_75(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpd rd,@rs,rr,cc */
int bfop_76(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,18);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdb rbd,@rs,rr,cc */
int bfop_77(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,19);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdr rd,@rs,rr,cc */
int bfop_78(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,20);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpdrb rbd,@rs,rr,cc */
int bfop_79(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,21);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpi rd,@rs,rr,cc */
int bfop_80(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,22);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpib rbd,@rs,rr,cc */
int bfop_81(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,23);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpir rd,@rs,rr,cc */
int bfop_82(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,24);
		put_word_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpirb rbd,@rs,rr,cc */
int bfop_83(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,25);
		put_byte_reg(context,reg_dst,tmp);
		abort(); 	}
	return pc;
}
/* cpl rrd,@rs */
int bfop_84(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,address_src */
int bfop_85(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,address_src(rs) */
int bfop_86(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,imm32 */
int bfop_87(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpl rrd,rrs */
int bfop_88(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
	}
	return pc;
}
/* cpsd @rd,@rs,rr,cc */
int bfop_89(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,27);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdb @rd,@rs,rr,cc */
int bfop_90(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,28);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdr @rd,@rs,rr,cc */
int bfop_91(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,29);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsdrb @rd,@rs,rr,cc */
int bfop_92(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,30);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsi @rd,@rs,rr,cc */
int bfop_93(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,31);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 		abort(); 	}
	return pc;
}
/* cpsib @rd,@rs,rr,cc */
int bfop_94(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,32);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 		abort(); 	}
	return pc;
}
/* cpsir @rd,@rs,rr,cc */
int bfop_95(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,33);
		put_word_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* cpsirb @rd,@rs,rr,cc */
int bfop_96(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_3) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,34);
		put_byte_mem_da(context,oplval_dst, tmp);
		abort(); 	}
	return pc;
}
/* dab rbd */
int bfop_97(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,35);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* dbjnz rbd,disp7 */
int bfop_98(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register int FAIL2=fail(context,2);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,36);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* dec @rd,imm4m1 */
int bfop_99(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec address_dst(rd),imm4m1 */
int bfop_100(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec address_dst,imm4m1 */
int bfop_101(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* dec rd,imm4m1 */
int bfop_102(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* decb @rd,imm4m1 */
int bfop_103(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb address_dst(rd),imm4m1 */
int bfop_104(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb address_dst,imm4m1 */
int bfop_105(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* decb rbd,imm4m1 */
int bfop_106(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* di i2 */
int bfop_107(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf)&0x2;
		register int op_src = imm_src;
		tmp = fail(context,39);
	}
	return pc;
}
/* div rrd,@rs */
int bfop_108(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,address_src */
int bfop_109(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 107;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,address_src(rs) */
int bfop_110(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,imm16 */
int bfop_111(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 107;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* div rrd,rs */
int bfop_112(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 107;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			tmp = (long)op_dst / (short)op_src;
			put_word_reg(context,reg_dst+1, tmp);
			put_word_reg(context,reg_dst, (long) op_dst % (short)op_src);
			context->zero = op_src == 0 || op_dst==0;
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffff0000) != 0;
			context->carry = (tmp & 0xfffeffff) != 0;
		}
	}
	return pc;
}
/* divl rqd,@rs */
int bfop_113(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 744;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,address_src */
int bfop_114(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 745;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,address_src(rs) */
int bfop_115(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 746;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,imm32 */
int bfop_116(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 744;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		UDItype op_dst ;
		register int op_src = imm_src;
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* divl rqd,rrs */
int bfop_117(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 744;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		UDItype op_dst ;
		register int op_src = get_long_reg(context,reg_src);
		if (op_src==0)
		{
			context->exception = SIM_DIV_ZERO;
		}
		else
		{
			op_dst.low = (int)get_long_reg(context,reg_dst+2);
			op_dst.high = (int)get_long_reg(context,reg_dst+0);
			tmp = (((long long)op_dst.high << 32) + (op_dst.low)) / (int)op_src;
			put_long_reg(context,reg_dst+2, tmp);
			put_long_reg(context,reg_dst, (((long long)op_dst.high << 32) + (op_dst.low)) % (int)op_src);
			context->zero = op_src == 0 || (op_dst.low==0 && op_dst.high==0);
			context->sign = (int)tmp < 0;
			context->overflow =(tmp & 0xffffffff) != 0;
			context->carry = (tmp & 0xfffffffe) != 0;
		}
	}
	return pc;
}
/* djnz rd,disp7 */
int bfop_118(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register int FAIL2=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,42);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ei i2 */
int bfop_119(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf)&0x2;
		register int op_src = imm_src;
		tmp = fail(context,43);
	}
	return pc;
}
/* ex rd,@rs */
int bfop_120(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,address_src */
int bfop_121(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,address_src(rs) */
int bfop_122(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src; 
		put_word_mem_da(context, oplval_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ex rd,rs */
int bfop_123(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src; 
		put_word_reg(context,reg_src, op_dst);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,@rs */
int bfop_124(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,address_src */
int bfop_125(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,address_src(rs) */
int bfop_126(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src; 
		put_byte_mem_da(context, oplval_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* exb rbd,rbs */
int bfop_127(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src; 
		put_byte_reg(context,reg_src, op_dst);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ext0e imm8 */
int bfop_128(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext0f imm8 */
int bfop_129(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext8e imm8 */
int bfop_130(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* ext8f imm8 */
int bfop_131(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* exts rrd */
int bfop_132(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_long_reg(context,reg_dst);
		if (tmp & (1<<15)) {
			tmp |= 0xffff0000;
		}
		else
		{
			tmp &= 0xffff;
		}
		put_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* extsb rd */
int bfop_133(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_word_reg(context,reg_dst);
		if (tmp & (1<<7)) {
			tmp |= 0xffffff00;
		}
		else
		{
			tmp &= 0xff;
		}
		put_word_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* extsl rqd */
int bfop_134(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		tmp= get_long_reg(context,reg_dst+2);
		if (tmp & (1<<31)) {
			put_long_reg(context,reg_dst, 0xffffffff);
		}
		else
		{
			put_long_reg(context,reg_dst, 0);
		}
	}
	return pc;
}
/* halt */
int bfop_135(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		tmp = fail(context,49);
	}
	return pc;
}
/* in rd,@ri */
int bfop_136(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,50);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* in rd,imm16 */
int bfop_137(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,50);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inb rbd,@ri */
int bfop_138(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,51);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inb rbd,imm16 */
int bfop_139(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,51);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* inc @rd,imm4m1 */
int bfop_140(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc address_dst(rd),imm4m1 */
int bfop_141(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc address_dst,imm4m1 */
int bfop_142(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inc rd,imm4m1 */
int bfop_143(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,0); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* incb @rd,imm4m1 */
int bfop_144(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb address_dst(rd),imm4m1 */
int bfop_145(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb address_dst,imm4m1 */
int bfop_146(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* incb rbd,imm4m1 */
int bfop_147(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf) + 1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst + op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,0); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ind @rd,@ri,ra */
int bfop_148(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,54);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indb @rd,@ri,ra */
int bfop_149(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,55);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indr @rd,@ri,ra */
int bfop_150(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,56);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* indrb @rd,@ri,ra */
int bfop_151(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,57);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ini @rd,@ri,ra */
int bfop_152(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,58);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inib @rd,@ri,ra */
int bfop_153(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,59);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inir @rd,@ri,ra */
int bfop_154(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,60);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* inirb @rd,@ri,ra */
int bfop_155(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,61);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* iret */
int bfop_156(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		tmp = fail(context,62);
	}
	return pc;
}
/* jp cc,@rd */
int bfop_157(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jp cc,address_dst */
int bfop_158(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 7;
	{
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jp cc,address_dst(rd) */
int bfop_159(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* jr cc,disp8 */
int bfop_160(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int op_cc=((iwords_0>>8) & 0xf);
		register unsigned int oplval_dst=((ibytes_1 << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 9)) + pc;
		if(op_cc == 8 || COND(context,op_cc)) pc = oplval_dst;
	}
	return pc;
}
/* ld @rd,imm16 */
int bfop_161(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld @rd,rs */
int bfop_162(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst(rd),imm16 */
int bfop_163(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned imm_src=(iwords_3);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst(rd),rs */
int bfop_164(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst,imm16 */
int bfop_165(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned imm_src=(iwords_3);
		register  int oplval_dst=base_dst;
		register int op_src = imm_src;
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld address_dst,rs */
int bfop_166(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd(imm16),rs */
int bfop_167(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd(rx),rs */
int bfop_168(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ld rd,@rs */
int bfop_169(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,address_src */
int bfop_170(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,address_src(rs) */
int bfop_171(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,imm16 */
int bfop_172(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs */
int bfop_173(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 3;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs(imm16) */
int bfop_174(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_ptr_long_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ld rd,rs(rx) */
int bfop_175(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* lda prd,address_src */
int bfop_176(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		tmp = oplval_src; 
		put_ptr_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,address_src(rs) */
int bfop_177(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		tmp = oplval_src; 
		put_ptr_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,rs(imm16) */
int bfop_178(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_ptr_long_reg(context,reg_src) + (short)(imm_src);
		tmp = oplval_src; 
		put_ptr_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* lda prd,rs(rx) */
int bfop_179(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		tmp = oplval_src; 
		put_ptr_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* ldar prd,disp16 */
int bfop_180(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		tmp = fail(context,67);
		put_ptr_long_reg(context,reg_dst, tmp);
	}
	return pc;
}
/* ldb @rd,imm8 */
int bfop_181(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb @rd,rbs */
int bfop_182(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst(rd),imm8 */
int bfop_183(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned int imm_src=(/* WHO */iwords_3&0xff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst(rd),rbs */
int bfop_184(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst,imm8 */
int bfop_185(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register unsigned int imm_src=(/* WHO */iwords_3&0xff);
		register  int oplval_dst=base_dst;
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb address_dst,rbs */
int bfop_186(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb rbd,@rs */
int bfop_187(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,address_src */
int bfop_188(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,address_src(rs) */
int bfop_189(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,imm8 */
int bfop_190(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((iwords_0>>8) & 0xf);
		register unsigned int imm_src=(iwords_0&0xff);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,imm8 */
int bfop_191(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_src = imm_src;
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rbs */
int bfop_192(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 3;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rs(imm16) */
int bfop_193(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_ptr_long_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rbd,rs(rx) */
int bfop_194(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_byte_mem_da(context,oplval_src);
		tmp = op_src;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldb rd(imm16),rbs */
int bfop_195(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldb rd(rx),rbs */
int bfop_196(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = op_src;
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldctl ctrl,rs */
int bfop_197(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register int FAIL3=fail(context,2);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,69);
	}
	return pc;
}
/* ldctl rd,ctrl */
int bfop_198(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int FAIL3=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,69);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldctlb ctrl,rbs */
int bfop_199(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,189);
	}
	return pc;
}
/* ldctlb rbd,ctrl */
int bfop_200(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,189);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldd @rd,@rs,rr */
int bfop_201(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_ptr_long_reg(context,reg_src);
			int rd = get_ptr_long_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_word_mem_da(context,rd, get_word_mem_da(context,rs));
				rd += -2;
				rs += -2;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_ptr_long_reg(context,reg_src, rs);
			put_ptr_long_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* lddb @rd,@rs,rr */
int bfop_202(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_ptr_long_reg(context,reg_src);
			int rd = get_ptr_long_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_byte_mem_da(context,rd, get_byte_mem_da(context,rs));
				rd += -1;
				rs += -1;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_ptr_long_reg(context,reg_src, rs);
			put_ptr_long_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* lddr @rd,@rs,rr */
int bfop_203(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,183);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* lddrb @rd,@rs,rr */
int bfop_204(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,184);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldi @rd,@rs,rr */
int bfop_205(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_ptr_long_reg(context,reg_src);
			int rd = get_ptr_long_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_word_mem_da(context,rd, get_word_mem_da(context,rs));
				rd += 2;
				rs += 2;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_ptr_long_reg(context,reg_src, rs);
			put_ptr_long_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* ldib @rd,@rs,rr */
int bfop_206(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		{ 
			int type = ((ibytes_3) & 0xf);
			int rs = get_ptr_long_reg(context,reg_src);
			int rd = get_ptr_long_reg(context,reg_dst);
			int rr = get_word_reg(context,reg_aux_r);
			do {
				put_byte_mem_da(context,rd, get_byte_mem_da(context,rs));
				rd += 1;
				rs += 1;
				rr --;
				context->cycles += 9;
			} while (!type && rr != 0 && context->exception <= 1);
			if (context->exception>1) pc -=4;
			put_ptr_long_reg(context,reg_src, rs);
			put_ptr_long_reg(context,reg_dst, rd);
			put_word_reg(context,reg_aux_r, rr);
		}
	}
	return pc;
}
/* ldir @rd,@rs,rr */
int bfop_207(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,70);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldirb @rd,@rs,rr */
int bfop_208(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,71);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldk rd,imm4 */
int bfop_209(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_src = imm_src;
		tmp = op_src;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl @rd,rrs */
int bfop_210(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl address_dst(rd),rrs */
int bfop_211(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl address_dst,rrs */
int bfop_212(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rd(imm16),rrs */
int bfop_213(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst) + (short)(imm_src);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rd(rx),rrs */
int bfop_214(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst)
		  + get_word_reg(context,reg_aux_x);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* ldl rrd,@rs */
int bfop_215(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,address_src */
int bfop_216(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,address_src(rs) */
int bfop_217(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,imm32 */
int bfop_218(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_src = imm_src;
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rrs */
int bfop_219(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rs(imm16) */
int bfop_220(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_src = get_ptr_long_reg(context,reg_src) + (short)(imm_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldl rrd,rs(rx) */
int bfop_221(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int reg_aux_x=((ibytes_2) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src)
		  + get_word_reg(context,reg_aux_x);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldm @rd,rs,n */
int bfop_222(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm address_dst(rd),rs,n */
int bfop_223(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_dst=fail(context,124);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm address_dst,rs,n */
int bfop_224(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_dst=fail(context,124);
		register  int oplval_dst=base_dst;
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,@rs,n */
int bfop_225(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,address_src(rs),n */
int bfop_226(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 15;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_src=fail(context,124);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		tmp = fail(context,74);
	}
	return pc;
}
/* ldm rd,address_src,n */
int bfop_227(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 8 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	register unsigned int iwords3 = get_word_mem_da(context,pc+6);
	pc += 8;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register unsigned int imm_src=(((ibytes_3) & 0xf) + 1);
		register unsigned base_src=fail(context,124);
		register  int oplval_src=base_src;
		tmp = fail(context,74);
	}
	return pc;
}
/* ldps @rs */
int bfop_228(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldps address_src */
int bfop_229(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldps address_src(rs) */
int bfop_230(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = fail(context,75);
	}
	return pc;
}
/* ldr disp16,rs */
int bfop_231(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,76);
	}
	return pc;
}
/* ldr rd,disp16 */
int bfop_232(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,76);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldrb disp16,rbs */
int bfop_233(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,77);
	}
	return pc;
}
/* ldrb rbd,disp16 */
int bfop_234(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,77);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* ldrl disp16,rrs */
int bfop_235(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_src = get_long_reg(context,reg_src);
		tmp = fail(context,78);
	}
	return pc;
}
/* ldrl rrd,disp16 */
int bfop_236(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int FAIL4=fail(context,2);
		register int op_dst = get_long_reg(context,reg_dst);
		tmp = fail(context,78);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* mbit */
int bfop_237(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		tmp = fail(context,79);
	}
	return pc;
}
/* mreq rd */
int bfop_238(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,80);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* mres */
int bfop_239(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		tmp = fail(context,81);
	}
	return pc;
}
/* mset */
int bfop_240(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		tmp = fail(context,82);
	}
	return pc;
}
/* mult rrd,@rs */
int bfop_241(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,address_src */
int bfop_242(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 70;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,address_src(rs) */
int bfop_243(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,imm16 */
int bfop_244(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 70;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* mult rrd,rs */
int bfop_245(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 70;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_dst =  get_word_reg(context,reg_dst+1);
		tmp = op_dst * op_src;
		put_long_reg(context,reg_dst, tmp);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffff0000) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,@rs */
int bfop_246(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,address_src */
int bfop_247(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 282;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,address_src(rs) */
int bfop_248(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		UDItype op_dst ;
		register int op_src= get_long_mem_da(context,oplval_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,imm32 */
int bfop_249(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 282;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		UDItype op_dst ;
		register int op_src = imm_src;
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* multl rqd,rrs */
int bfop_250(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 282;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		UDItype op_dst ;
		register int op_src = get_long_reg(context,reg_src);
		op_dst.low =  get_long_reg(context,reg_dst+2);
		tmp = op_dst.low * op_src;
		put_long_reg(context,reg_dst+2, tmp);
		put_long_reg(context,reg_dst, 0);
		context->sign = (int)tmp < 0;
		context->overflow =0;
		context->carry = (tmp & 0xffffffff) != 0;
		context->zero = tmp == 0;
	}
	return pc;
}
/* neg @rd */
int bfop_251(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg address_dst */
int bfop_252(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg address_dst(rd) */
int bfop_253(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* neg rd */
int bfop_254(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		}		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* negb @rd */
int bfop_255(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb address_dst */
int bfop_256(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb address_dst(rd) */
int bfop_257(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* negb rbd */
int bfop_258(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		{
			int op_src = -op_dst;
			op_dst = 0;
			 tmp = op_dst + op_src;
;
			NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		}		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* nop */
int bfop_259(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
	}
	return pc;
}
/* or rd,@rs */
int bfop_260(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,address_src */
int bfop_261(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,address_src(rs) */
int bfop_262(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,imm16 */
int bfop_263(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* or rd,rs */
int bfop_264(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,@rs */
int bfop_265(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,address_src */
int bfop_266(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,address_src(rs) */
int bfop_267(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,imm8 */
int bfop_268(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* orb rbd,rbs */
int bfop_269(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst | op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* otdr @ro,@rs,ra */
int bfop_270(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,90);
		abort(); 	}
	return pc;
}
/* otdrb @ro,@rs,ra */
int bfop_271(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,91);
		abort(); 	}
	return pc;
}
/* otir @ro,@rs,ra */
int bfop_272(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,92);
		abort(); 	}
	return pc;
}
/* otirb @ro,@rs,ra */
int bfop_273(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,93);
		abort(); 	}
	return pc;
}
/* out @ro,rs */
int bfop_274(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,94);
		abort(); 	}
	return pc;
}
/* out imm16,rs */
int bfop_275(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,94);
	}
	return pc;
}
/* outb @ro,rbs */
int bfop_276(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,95);
		abort(); 	}
	return pc;
}
/* outb imm16,rbs */
int bfop_277(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,95);
	}
	return pc;
}
/* outd @ro,@rs,ra */
int bfop_278(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,96);
		abort(); 	}
	return pc;
}
/* outdb @ro,@rs,ra */
int bfop_279(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,97);
		abort(); 	}
	return pc;
}
/* outi @ro,@rs,ra */
int bfop_280(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,98);
		abort(); 	}
	return pc;
}
/* outib @ro,@rs,ra */
int bfop_281(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,99);
		abort(); 	}
	return pc;
}
/* pop @rd,@rs */
int bfop_282(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop address_dst(rd),@rs */
int bfop_283(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop address_dst,@rs */
int bfop_284(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 2);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pop rd,@rs */
int bfop_285(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 2);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* popl @rd,@rs */
int bfop_286(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 19;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl address_dst(rd),@rs */
int bfop_287(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 23;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl address_dst,@rs */
int bfop_288(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 23;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 4);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* popl rrd,@rs */
int bfop_289(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		put_ptr_long_reg(context,reg_src, oplval_src + 4);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* push @rd,@rs */
int bfop_290(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,address_src */
int bfop_291(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src=base_src;
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,address_src(rs) */
int bfop_292(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_word_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,imm16 */
int bfop_293(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = op_src;
		oplval_dst -= 2;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* push @rd,rs */
int bfop_294(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = op_src;
		oplval_dst -= 2;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,@rs */
int bfop_295(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 20;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,address_src */
int bfop_296(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 21;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src=base_src;
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,address_src(rs) */
int bfop_297(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 21;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_src= get_long_mem_da(context,oplval_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* pushl @rd,rrs */
int bfop_298(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		tmp = op_src;
		oplval_dst -= 4;
		put_ptr_long_reg(context,reg_dst, oplval_dst);
		put_long_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res @rd,imm4 */
int bfop_299(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res address_dst(rd),imm4 */
int bfop_300(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res address_dst,imm4 */
int bfop_301(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* res rd,imm4 */
int bfop_302(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst & ~(1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* res rd,rs */
int bfop_303(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst & ~(1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resb @rd,imm4 */
int bfop_304(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb address_dst(rd),imm4 */
int bfop_305(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb address_dst,imm4 */
int bfop_306(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* resb rbd,imm4 */
int bfop_307(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,105);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resb rbd,rs */
int bfop_308(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,105);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* resflg flags */
int bfop_309(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		 COND (context, 0x0b);
		{ int on =0;
 			if (imm_src & 1)
			PSW_OVERFLOW = on;
			if (imm_src & 2)
			PSW_SIGN = on;
			if (imm_src & 4)
			PSW_ZERO = on;
			if (imm_src & 8)
			PSW_CARRY = on;
		}
	}
	return pc;
}
/* ret cc */
int bfop_310(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int op_cc=((ibytes_1) & 0xf);
		if(op_cc == 8 || COND(context,op_cc))
{
			pc = get_ptr_long_mem_ir(context,14);
			put_ptr_long_reg(context,14, get_ptr_long_reg(context,14) + 4);
		};
	}
	return pc;
}
/* rl rd,imm1or2 */
int bfop_311(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (15))&1;
			op_dst <<=1;
			if (rotbit) op_dst |= 1;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlb rbd,imm1or2 */
int bfop_312(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (7))&1;
			op_dst <<=1;
			if (rotbit) op_dst |= 1;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlc rd,imm1or2 */
int bfop_313(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (15))&1;
			op_dst <<=1;
			if (context->carry) op_dst |=1;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rlcb rbd,imm1or2 */
int bfop_314(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = (op_dst >> (7))&1;
			op_dst <<=1;
			if (context->carry) op_dst |=1;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rldb rbb,rba */
int bfop_315(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_b=((ibytes_1) & 0xf);
		register int op_aux_b = get_byte_reg(context,reg_aux_b);
		register int op_aux_a = get_byte_reg(context,reg_aux_a);
		tmp = fail(context,112);
	}
	return pc;
}
/* rr rd,imm1or2 */
int bfop_316(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= rotbit << 15;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrb rbd,imm1or2 */
int bfop_317(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= rotbit << 7;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrc rd,imm1or2 */
int bfop_318(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 6;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= context->carry << 15;
			context->carry = rotbit;
		}
		tmp = (short)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrcb rbd,imm1or2 */
int bfop_319(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(((ibytes_1) & 0xf)& 2)?2:1;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		while (op_src--) {
			int rotbit;
			rotbit = op_dst & 1;
			op_dst = ((unsigned)op_dst) >> 1;
			op_dst |= context->carry << 7;
			context->carry = rotbit;
		}
		tmp = (char)op_dst;
		context->zero = tmp == 0;
		context->sign = (int)tmp < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* rrdb rbb,rba */
int bfop_320(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 9;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_b=((ibytes_1) & 0xf);
		register int op_aux_b = get_byte_reg(context,reg_aux_b);
		register int op_aux_a = get_byte_reg(context,reg_aux_a);
		tmp = fail(context,117);
	}
	return pc;
}
/* rsvd36 */
int bfop_321(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd38 */
int bfop_322(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd78 */
int bfop_323(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd7e */
int bfop_324(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd9d */
int bfop_325(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvd9f */
int bfop_326(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvdb9 */
int bfop_327(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* rsvdbf */
int bfop_328(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 10;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		pc -=2; 
		context->exception = SIM_BREAKPOINT;
	}
	return pc;
}
/* sbc rd,rs */
int bfop_329(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 op_src +=  COND(context,7);tmp = op_dst - op_src ;;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sbcb rbd,rbs */
int bfop_330(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,119);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sc imm8 */
int bfop_331(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 33;
	{
		register unsigned int imm_src=(iwords_0&0xff);
		register int op_src = imm_src;
		support_call(context,imm_src);
	}
	return pc;
}
/* sda rd,rs */
int bfop_332(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( short)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdab rbd,rs */
int bfop_333(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( char)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdal rrd,rs */
int bfop_334(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( long)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdl rd,rs */
int bfop_335(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned short)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdlb rbd,rs */
int bfop_336(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned char)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sdll rrd,rs */
int bfop_337(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_src=((ibytes_2) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned long)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* set @rd,imm4 */
int bfop_338(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set address_dst(rd),imm4 */
int bfop_339(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set address_dst,imm4 */
int bfop_340(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* set rd,imm4 */
int bfop_341(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst | (1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* set rd,rs */
int bfop_342(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst | (1<< op_src);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setb @rd,imm4 */
int bfop_343(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb address_dst(rd),imm4 */
int bfop_344(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb address_dst,imm4 */
int bfop_345(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 13;
	{
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* setb rbd,imm4 */
int bfop_346(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,127);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setb rbd,rs */
int bfop_347(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1) & 0xf);
		register unsigned int reg_dst=((ibytes_2) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,127);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* setflg flags */
int bfop_348(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int imm_src=((ibytes_1 >> 4) & 0xf);
		 COND (context, 0x0b);
		{ int on =1;
 			if (imm_src & 1)
			PSW_OVERFLOW = on;
			if (imm_src & 2)
			PSW_SIGN = on;
			if (imm_src & 4)
			PSW_ZERO = on;
			if (imm_src & 8)
			PSW_CARRY = on;
		}
	}
	return pc;
}
/* sin rd,imm16 */
int bfop_349(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,129);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sinb rbd,imm16 */
int bfop_350(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 10;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,130);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sind @rd,@ri,ra */
int bfop_351(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,131);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindb @rd,@ri,ra */
int bfop_352(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,132);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindr @rd,@ri,ra */
int bfop_353(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,133);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sindrb @rd,@ri,ra */
int bfop_354(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,134);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sini @rd,@ri,ra */
int bfop_355(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,135);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinib @rd,@ri,ra */
int bfop_356(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,136);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinir @rd,@ri,ra */
int bfop_357(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,137);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sinirb @rd,@ri,ra */
int bfop_358(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,138);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* sla rd,imm8 */
int bfop_359(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( short)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slab rbd,imm4 */
int bfop_360(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( char)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slal rrd,imm8 */
int bfop_361(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = ( long)op_dst;
			tmp = ( op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sll rd,imm8 */
int bfop_362(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned short)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (16 - op_src);
		}
		context->zero = (short)tmp == 0;
		context->sign = (int)((short)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sllb rbd,imm4 */
int bfop_363(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned char)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (8 - op_src);
		}
		context->zero = (char)tmp == 0;
		context->sign = (int)((char)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* slll rrd,imm8 */
int bfop_364(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		op_src = (op_src << (sizeof (int) * 8 - 8)) >> (sizeof (int) * 8 - 8);
		if (op_src < 0) 
		{
			op_src = -op_src;
			op_dst = (unsigned long)op_dst;
			tmp = ((unsigned) op_dst) >> op_src;
			context->carry = op_dst >> (op_src-1);
		}
		else
		{
			tmp = op_dst << op_src;
			context->carry = op_dst >> (32 - op_src);
		}
		context->zero = (long)tmp == 0;
		context->sign = (int)((long)tmp) < 0;
		context->overflow = ((int)tmp < 0) != ((int)op_dst < 0);
		context->cycles += 3*op_src;
		context->broken_flags = 0;
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sotdr @ro,@rs,ra */
int bfop_365(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,145);
		abort(); 	}
	return pc;
}
/* sotdrb @ro,@rs,ra */
int bfop_366(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,146);
		abort(); 	}
	return pc;
}
/* sotir @ro,@rs,ra */
int bfop_367(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,147);
		abort(); 	}
	return pc;
}
/* sotirb @ro,@rs,ra */
int bfop_368(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 11;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,148);
		abort(); 	}
	return pc;
}
/* sout imm16,rs */
int bfop_369(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_word_reg(context,reg_src);
		tmp = fail(context,149);
	}
	return pc;
}
/* soutb imm16,rbs */
int bfop_370(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 12;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = imm_src;
		register int op_src = get_byte_reg(context,reg_src);
		tmp = fail(context,150);
	}
	return pc;
}
/* soutd @ro,@rs,ra */
int bfop_371(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,151);
		abort(); 	}
	return pc;
}
/* soutdb @ro,@rs,ra */
int bfop_372(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,152);
		abort(); 	}
	return pc;
}
/* souti @ro,@rs,ra */
int bfop_373(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_word_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,153);
		abort(); 	}
	return pc;
}
/* soutib @ro,@rs,ra */
int bfop_374(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 21;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_a=((ibytes_2) & 0xf);
		register unsigned int reg_dst=((ibytes_3 >> 4) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_a = get_word_reg(context,reg_aux_a);
		tmp = fail(context,154);
		abort(); 	}
	return pc;
}
/* sra rd,imm8 */
int bfop_375(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,155);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srab rbd,imm4 */
int bfop_376(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src = - ((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,156);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sral rrd,imm8 */
int bfop_377(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,157);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srl rd,imm8 */
int bfop_378(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,158);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srlb rbd,imm4 */
int bfop_379(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src = - ((ibytes_3) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,159);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* srll rrd,imm8 */
int bfop_380(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int imm_src=-(iwords_1&0xff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		tmp = fail(context,160);
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,@rs */
int bfop_381(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,address_src */
int bfop_382(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,address_src(rs) */
int bfop_383(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,imm16 */
int bfop_384(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* sub rd,rs */
int bfop_385(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,16, tmp,  op_dst, op_src,1); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,@rs */
int bfop_386(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,address_src */
int bfop_387(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,address_src(rs) */
int bfop_388(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,imm8 */
int bfop_389(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subb rbd,rbs */
int bfop_390(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,8, tmp,  op_dst, op_src,1); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,@rs */
int bfop_391(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 14;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,address_src */
int bfop_392(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,address_src(rs) */
int bfop_393(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src= get_long_mem_da(context,oplval_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,imm32 */
int bfop_394(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src= ((iwords_1<<16) | (iwords_2));
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* subl rrd,rrs */
int bfop_395(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		register int op_src = get_long_reg(context,reg_src);
		 tmp = op_dst - op_src;
		NORMAL_FLAGS(context,32, tmp,  op_dst, op_src,1); 
		put_long_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* tcc cc,rd */
int bfop_396(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		if(op_cc == 8 || COND(context,op_cc)) put_word_reg(context,reg_dst, 1);
	}
	return pc;
}
/* tccb cc,rbd */
int bfop_397(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 5;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int op_cc=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		if(op_cc == 8 || COND(context,op_cc)) put_word_reg(context,reg_dst, 1);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* test @rd */
int bfop_398(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* test address_dst */
int bfop_399(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* test address_dst(rd) */
int bfop_400(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* test rd */
int bfop_401(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,16, tmp); 
	}
	return pc;
}
/* testb @rd */
int bfop_402(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 8;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb address_dst */
int bfop_403(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 11;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb address_dst(rd) */
int bfop_404(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 12;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testb rbd */
int bfop_405(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,8, tmp); 
	}
	return pc;
}
/* testl @rd */
int bfop_406(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl address_dst */
int bfop_407(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 16;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl address_dst(rd) */
int bfop_408(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 17;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_long_mem_da(context,oplval_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* testl rrd */
int bfop_409(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 13;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_long_reg(context,reg_dst);
		 tmp = op_dst;
		TEST_NORMAL_FLAGS(context,32, tmp); 
	}
	return pc;
}
/* trdb @rd,@rs,rr */
int bfop_410(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,169);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trdrb @rd,@rs,rr */
int bfop_411(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,170);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trib @rd,@rs,rr */
int bfop_412(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,171);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trirb @rd,@rs,rr */
int bfop_413(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_src=((ibytes_3 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,172);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* trtdb @ra,@rb,rr */
int bfop_414(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_ptr_long_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_ptr_long_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,190);
	}
	return pc;
}
/* trtdrb @ra,@rb,rr */
int bfop_415(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_ptr_long_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_ptr_long_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,173);
	}
	return pc;
}
/* trtib @ra,@rb,rr */
int bfop_416(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_ptr_long_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_ptr_long_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,174);
	}
	return pc;
}
/* trtirb @ra,@rb,rr */
int bfop_417(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 25;
	{
		register unsigned int reg_aux_a=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_aux_r=((ibytes_2) & 0xf);
		register unsigned int reg_aux_b=((ibytes_3 >> 4) & 0xf);
		register  int oplval_aux_a = get_ptr_long_reg(context,reg_aux_a);
		register  int oplval_aux_b = get_ptr_long_reg(context,reg_aux_b);
		register int op_aux_a= get_byte_mem_da(context,oplval_aux_a);
		register int op_aux_b= get_byte_mem_da(context,oplval_aux_b);
		register int op_aux_r = get_word_reg(context,reg_aux_r);
		tmp = fail(context,175);
	}
	return pc;
}
/* tset @rd */
int bfop_418(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset address_dst */
int bfop_419(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset address_dst(rd) */
int bfop_420(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_word_mem_da(context,oplval_dst);
		tmp = fail(context,177);
		put_word_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tset rd */
int bfop_421(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		tmp = fail(context,177);
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* tsetb @rd */
int bfop_422(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 11;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register  int oplval_dst = get_ptr_long_reg(context,reg_dst);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb address_dst */
int bfop_423(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 14;
	{
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_dst=base_dst;
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb address_dst(rd) */
int bfop_424(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 15;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register unsigned base_dst=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_dst= ((base_dst + (short)get_word_reg(context,reg_dst)) & 0xffff) + (base_dst & ~0xffff);
		register int op_dst= get_byte_mem_da(context,oplval_dst);
		tmp = fail(context,178);
		put_byte_mem_da(context,oplval_dst, tmp);
	}
	return pc;
}
/* tsetb rbd */
int bfop_425(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1 >> 4) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		tmp = fail(context,178);
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,@rs */
int bfop_426(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,address_src */
int bfop_427(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,address_src(rs) */
int bfop_428(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src= get_word_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,imm16 */
int bfop_429(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned imm_src=(iwords_1);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xor rd,rs */
int bfop_430(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_word_reg(context,reg_dst);
		register int op_src = get_word_reg(context,reg_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,16, tmp); 
		put_word_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,@rs */
int bfop_431(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 7;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register  int oplval_src = get_ptr_long_reg(context,reg_src);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,address_src */
int bfop_432(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 9;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  int oplval_src=base_src;
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,address_src(rs) */
int bfop_433(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 6 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	register unsigned int iwords2 = get_word_mem_da(context,pc+4);
	pc += 6;
	context->cycles += 10;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned base_src=(((iwords_1 << 8) | (iwords_2)) & 0x7fffff);
		register  unsigned long oplval_src= ((base_src + (short)get_word_reg(context,reg_src)) & 0xffff) + (base_src & ~0xffff);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src= get_byte_mem_da(context,oplval_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,imm8 */
int bfop_434(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 4 */ 
	register unsigned int iwords1 = get_word_mem_da(context,pc+2);
	pc += 4;
	context->cycles += 7;
	{
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register unsigned int imm_src=(iwords_1>>8);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = imm_src;
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
/* xorb rbd,rbs */
int bfop_435(context,pc,iwords0)
int iwords0;
sim_state_type *context;
int pc;
{
	register unsigned int tmp;
			/* Length 2 */ 
	pc += 2
;	context->cycles += 4;
	{
		register unsigned int reg_src=((ibytes_1 >> 4) & 0xf);
		register unsigned int reg_dst=((ibytes_1) & 0xf);
		register int op_dst = get_byte_reg(context,reg_dst);
		register int op_src = get_byte_reg(context,reg_src);
		 tmp = op_dst ^ op_src;
		TEST_NORMAL_FLAGS(context,8, tmp); 
		put_byte_reg(context,reg_dst,tmp);
	}
	return pc;
}
int bfop_436(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_437(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_438(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_439(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_440(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_441(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_442(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_443(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_444(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_445(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_446(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_447(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_448(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_449(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_450(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_451(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_452(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_453(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_454(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_455(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_456(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_457(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_458(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_459(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_460(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_461(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_462(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_463(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_464(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_465(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_466(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_467(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_468(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_469(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_470(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_471(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_472(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_473(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_474(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_475(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_476(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_477(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_478(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_479(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_480(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_481(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_482(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_483(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_484(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_485(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_486(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_487(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_488(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_489(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_490(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_491(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_492(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_493(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_494(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_495(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_496(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_497(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_498(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_499(context,pc)
sim_state_type *context;
int pc;
{ bfop_bad1();return pc; }
int bfop_bad() ;
int (*(bfop_table[]))() = {	bfop_0
,	bfop_1
,	bfop_2
,	bfop_3
,	bfop_4
,	bfop_5
,	bfop_6
,	bfop_7
,	bfop_8
,	bfop_9
,	bfop_10
,	bfop_11
,	bfop_12
,	bfop_13
,	bfop_14
,	bfop_15
,	bfop_16
,	bfop_17
,	bfop_18
,	bfop_19
,	bfop_20
,	bfop_21
,	bfop_22
,	bfop_23
,	bfop_24
,	bfop_25
,	bfop_26
,	bfop_27
,	bfop_28
,	bfop_29
,	bfop_30
,	bfop_31
,	bfop_32
,	bfop_33
,	bfop_34
,	bfop_35
,	bfop_36
,	bfop_37
,	bfop_38
,	bfop_39
,	bfop_40
,	bfop_41
,	bfop_42
,	bfop_43
,	bfop_44
,	bfop_45
,	bfop_46
,	bfop_47
,	bfop_48
,	bfop_49
,	bfop_50
,	bfop_51
,	bfop_52
,	bfop_53
,	bfop_54
,	bfop_55
,	bfop_56
,	bfop_57
,	bfop_58
,	bfop_59
,	bfop_60
,	bfop_61
,	bfop_62
,	bfop_63
,	bfop_64
,	bfop_65
,	bfop_66
,	bfop_67
,	bfop_68
,	bfop_69
,	bfop_70
,	bfop_71
,	bfop_72
,	bfop_73
,	bfop_74
,	bfop_75
,	bfop_76
,	bfop_77
,	bfop_78
,	bfop_79
,	bfop_80
,	bfop_81
,	bfop_82
,	bfop_83
,	bfop_84
,	bfop_85
,	bfop_86
,	bfop_87
,	bfop_88
,	bfop_89
,	bfop_90
,	bfop_91
,	bfop_92
,	bfop_93
,	bfop_94
,	bfop_95
,	bfop_96
,	bfop_97
,	bfop_98
,	bfop_99
,	bfop_100
,	bfop_101
,	bfop_102
,	bfop_103
,	bfop_104
,	bfop_105
,	bfop_106
,	bfop_107
,	bfop_108
,	bfop_109
,	bfop_110
,	bfop_111
,	bfop_112
,	bfop_113
,	bfop_114
,	bfop_115
,	bfop_116
,	bfop_117
,	bfop_118
,	bfop_119
,	bfop_120
,	bfop_121
,	bfop_122
,	bfop_123
,	bfop_124
,	bfop_125
,	bfop_126
,	bfop_127
,	bfop_128
,	bfop_129
,	bfop_130
,	bfop_131
,	bfop_132
,	bfop_133
,	bfop_134
,	bfop_135
,	bfop_136
,	bfop_137
,	bfop_138
,	bfop_139
,	bfop_140
,	bfop_141
,	bfop_142
,	bfop_143
,	bfop_144
,	bfop_145
,	bfop_146
,	bfop_147
,	bfop_148
,	bfop_149
,	bfop_150
,	bfop_151
,	bfop_152
,	bfop_153
,	bfop_154
,	bfop_155
,	bfop_156
,	bfop_157
,	bfop_158
,	bfop_159
,	bfop_160
,	bfop_161
,	bfop_162
,	bfop_163
,	bfop_164
,	bfop_165
,	bfop_166
,	bfop_167
,	bfop_168
,	bfop_169
,	bfop_170
,	bfop_171
,	bfop_172
,	bfop_173
,	bfop_174
,	bfop_175
,	bfop_176
,	bfop_177
,	bfop_178
,	bfop_179
,	bfop_180
,	bfop_181
,	bfop_182
,	bfop_183
,	bfop_184
,	bfop_185
,	bfop_186
,	bfop_187
,	bfop_188
,	bfop_189
,	bfop_190
,	bfop_191
,	bfop_192
,	bfop_193
,	bfop_194
,	bfop_195
,	bfop_196
,	bfop_197
,	bfop_198
,	bfop_199
,	bfop_200
,	bfop_201
,	bfop_202
,	bfop_203
,	bfop_204
,	bfop_205
,	bfop_206
,	bfop_207
,	bfop_208
,	bfop_209
,	bfop_210
,	bfop_211
,	bfop_212
,	bfop_213
,	bfop_214
,	bfop_215
,	bfop_216
,	bfop_217
,	bfop_218
,	bfop_219
,	bfop_220
,	bfop_221
,	bfop_222
,	bfop_223
,	bfop_224
,	bfop_225
,	bfop_226
,	bfop_227
,	bfop_228
,	bfop_229
,	bfop_230
,	bfop_231
,	bfop_232
,	bfop_233
,	bfop_234
,	bfop_235
,	bfop_236
,	bfop_237
,	bfop_238
,	bfop_239
,	bfop_240
,	bfop_241
,	bfop_242
,	bfop_243
,	bfop_244
,	bfop_245
,	bfop_246
,	bfop_247
,	bfop_248
,	bfop_249
,	bfop_250
,	bfop_251
,	bfop_252
,	bfop_253
,	bfop_254
,	bfop_255
,	bfop_256
,	bfop_257
,	bfop_258
,	bfop_259
,	bfop_260
,	bfop_261
,	bfop_262
,	bfop_263
,	bfop_264
,	bfop_265
,	bfop_266
,	bfop_267
,	bfop_268
,	bfop_269
,	bfop_270
,	bfop_271
,	bfop_272
,	bfop_273
,	bfop_274
,	bfop_275
,	bfop_276
,	bfop_277
,	bfop_278
,	bfop_279
,	bfop_280
,	bfop_281
,	bfop_282
,	bfop_283
,	bfop_284
,	bfop_285
,	bfop_286
,	bfop_287
,	bfop_288
,	bfop_289
,	bfop_290
,	bfop_291
,	bfop_292
,	bfop_293
,	bfop_294
,	bfop_295
,	bfop_296
,	bfop_297
,	bfop_298
,	bfop_299
,	bfop_300
,	bfop_301
,	bfop_302
,	bfop_303
,	bfop_304
,	bfop_305
,	bfop_306
,	bfop_307
,	bfop_308
,	bfop_309
,	bfop_310
,	bfop_311
,	bfop_312
,	bfop_313
,	bfop_314
,	bfop_315
,	bfop_316
,	bfop_317
,	bfop_318
,	bfop_319
,	bfop_320
,	bfop_321
,	bfop_322
,	bfop_323
,	bfop_324
,	bfop_325
,	bfop_326
,	bfop_327
,	bfop_328
,	bfop_329
,	bfop_330
,	bfop_331
,	bfop_332
,	bfop_333
,	bfop_334
,	bfop_335
,	bfop_336
,	bfop_337
,	bfop_338
,	bfop_339
,	bfop_340
,	bfop_341
,	bfop_342
,	bfop_343
,	bfop_344
,	bfop_345
,	bfop_346
,	bfop_347
,	bfop_348
,	bfop_349
,	bfop_350
,	bfop_351
,	bfop_352
,	bfop_353
,	bfop_354
,	bfop_355
,	bfop_356
,	bfop_357
,	bfop_358
,	bfop_359
,	bfop_360
,	bfop_361
,	bfop_362
,	bfop_363
,	bfop_364
,	bfop_365
,	bfop_366
,	bfop_367
,	bfop_368
,	bfop_369
,	bfop_370
,	bfop_371
,	bfop_372
,	bfop_373
,	bfop_374
,	bfop_375
,	bfop_376
,	bfop_377
,	bfop_378
,	bfop_379
,	bfop_380
,	bfop_381
,	bfop_382
,	bfop_383
,	bfop_384
,	bfop_385
,	bfop_386
,	bfop_387
,	bfop_388
,	bfop_389
,	bfop_390
,	bfop_391
,	bfop_392
,	bfop_393
,	bfop_394
,	bfop_395
,	bfop_396
,	bfop_397
,	bfop_398
,	bfop_399
,	bfop_400
,	bfop_401
,	bfop_402
,	bfop_403
,	bfop_404
,	bfop_405
,	bfop_406
,	bfop_407
,	bfop_408
,	bfop_409
,	bfop_410
,	bfop_411
,	bfop_412
,	bfop_413
,	bfop_414
,	bfop_415
,	bfop_416
,	bfop_417
,	bfop_418
,	bfop_419
,	bfop_420
,	bfop_421
,	bfop_422
,	bfop_423
,	bfop_424
,	bfop_425
,	bfop_426
,	bfop_427
,	bfop_428
,	bfop_429
,	bfop_430
,	bfop_431
,	bfop_432
,	bfop_433
,	bfop_434
,	bfop_435
,	bfop_436
,	bfop_437
,	bfop_438
,	bfop_439
,	bfop_440
,	bfop_441
,	bfop_442
,	bfop_443
,	bfop_444
,	bfop_445
,	bfop_446
,	bfop_447
,	bfop_448
,	bfop_449
,	bfop_450
,	bfop_451
,	bfop_452
,	bfop_453
,	bfop_454
,	bfop_455
,	bfop_456
,	bfop_457
,	bfop_458
,	bfop_459
,	bfop_460
,	bfop_461
,	bfop_462
,	bfop_463
,	bfop_464
,	bfop_465
,	bfop_466
,	bfop_467
,	bfop_468
,	bfop_469
,	bfop_470
,	bfop_471
,	bfop_472
,	bfop_473
,	bfop_474
,	bfop_475
,	bfop_476
,	bfop_477
,	bfop_478
,	bfop_479
,	bfop_480
,	bfop_481
,	bfop_482
,	bfop_483
,	bfop_484
,	bfop_485
,	bfop_486
,	bfop_487
,	bfop_488
,	bfop_489
,	bfop_490
,	bfop_491
,	bfop_492
,	bfop_493
,	bfop_494
,	bfop_495
,	bfop_496
,	bfop_497
,	bfop_498
,	bfop_499
};



