#include <set>

std::set<void*> done;

extern "C" void mark(void* p)
{
  done.insert(p);
}

extern "C" int marked(void* p)
{
  return done.find(p) != end(done);
}
