#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx aarch64_function_value(const_tree ret_type, const_tree, bool)
{
  return gen_rtx_REG(TYPE_MODE(ret_type), W0_REGNUM);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE aarch64_function_value

bool aarch64_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum, tree fntype, rtx,
			  tree fndecl, int)
{
  (void)fntype;
  (void)fndecl;
  cum.nregs = cum.offset = 0;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P aarch64_legitimate_address_p


void aarch64_function_arg_advance(cumulative_args_t pcum_v,
				   const function_arg_info &arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 8) {
    ++cum->nregs;
    return;
  }
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE aarch64_function_arg_advance

rtx aarch64_function_incoming_arg(cumulative_args_t pcum_v,
				  const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 8)
    return gen_rtx_REG(arg.mode, cum->nregs);
  (void)arg;
  abort();
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG aarch64_function_incoming_arg

rtx aarch64_function_arg(cumulative_args_t pcum_v,
			 const function_arg_info& arg)
{
  return aarch64_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG aarch64_function_arg

HOST_WIDE_INT aarch64_starting_frame_offset()
{
  return 16;
}

#undef  TARGET_STARTING_FRAME_OFFSET
#define TARGET_STARTING_FRAME_OFFSET aarch64_starting_frame_offset

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  switch (regno) {
  case W0_REGNUM: case W1_REGNUM: return true;
  default: return false;
  }
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case W0_REGNUM: return W0_REGS;
  case W1_REGNUM: return W1_REGS;
  case W2_REGNUM: return W2_REGS;
  case W3_REGNUM: return W3_REGS;
  case W4_REGNUM: return W4_REGS;
  case W5_REGNUM: return W5_REGS;
  case W6_REGNUM: return W6_REGS;
  case W7_REGNUM: return W7_REGS;
  case W8_REGNUM: return W8_REGS;
  case W9_REGNUM: return W9_REGS;
  case W10_REGNUM: return W10_REGS;
  case W11_REGNUM: return W11_REGS;
  case W12_REGNUM: return W12_REGS;
  case W13_REGNUM: return W13_REGS;
  case W14_REGNUM: return W14_REGS;
  case W15_REGNUM: return W15_REGS;
  case W16_REGNUM: return W16_REGS;
  case W17_REGNUM: return W17_REGS;
  case W18_REGNUM: return W18_REGS;
  case W19_REGNUM: return W19_REGS;
  case W20_REGNUM: return W20_REGS;
  case W21_REGNUM: return W21_REGS;
  case W22_REGNUM: return W22_REGS;
  case W23_REGNUM: return W23_REGS;
  case W24_REGNUM: return W24_REGS;
  case W25_REGNUM: return W25_REGS;
  case W26_REGNUM: return W26_REGS;
  case W27_REGNUM: return W27_REGS;
  case W28_REGNUM: return W28_REGS;
  case FRAME_POINTER_REGNUM: return X29_REGS;
  case X30_REGNUM: return X30_REGS;
  case STACK_POINTER_REGNUM: return SP_REGS;
  case PC_REGNUM: return PC_REGS;
  default: abort();
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree)
{
  return 0;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  assert(from == FRAME_POINTER_REGNUM);
  assert(to == STACK_POINTER_REGNUM);
  offset = 0;
}

void aarch64_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    int regno = REGNO(x);
    switch (regno) {
    case STACK_POINTER_REGNUM: return (void)fprintf(fp, "sp");
    case FRAME_POINTER_REGNUM: return (void)fprintf(fp, "x29");
    case X30_REGNUM: return (void)fprintf(fp, "x30");
    default: return (void)fprintf(fp, "w%d", regno);
    }
  }

  if (CONST_INT_P(x)) {
    auto v = INTVAL(x);
    return (void)fprintf(fp, "%lld", v);
  }

  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void aarch64_expand_prologue()
{
  auto sp = stack_pointer_rtx;
  auto fp = frame_pointer_rtx;
  auto x30 = gen_rtx_REG(DImode, X30_REGNUM);
  auto size = get_frame_size();
  auto off1 = GEN_INT(-size-16);
  auto off2 = GEN_INT(-size-8);
  auto insn = emit_insn(gen_storewb_pairdi_di(sp, sp, fp, x30, off1, off2));
  RTX_FRAME_RELATED_P(insn) = true;
  auto ins1 = XVECEXP(PATTERN(insn), 0, 1);
  RTX_FRAME_RELATED_P(ins1) = true;
  auto ins2 = XVECEXP(PATTERN(insn), 0, 2);
  RTX_FRAME_RELATED_P(ins2) = true;

  emit_insn(gen_rtx_SET(fp, sp));
}

void aarch64_expand_epilogue()
{
  auto sp = stack_pointer_rtx;
  auto fp = frame_pointer_rtx;
  auto x30 = gen_rtx_REG(DImode, X30_REGNUM);
  auto size = get_frame_size();
  auto off1 = GEN_INT(size+16);
  auto off2 = GEN_INT(8);
  auto insn = emit_insn(gen_loadwb_pairdi_di(sp, sp, fp, x30, off1, off2));

  auto note = alloc_reg_note(REG_CFA_RESTORE, fp, nullptr);
  note = alloc_reg_note(REG_CFA_RESTORE, x30, note);
  REG_NOTES(insn) = alloc_reg_note(REG_CFA_DEF_CFA, sp, note);
  RTX_FRAME_RELATED_P(insn) = true;

  emit_jump_insn(ret_rtx);
}

const char* aarch64_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == FRAME_POINTER_REGNUM;
}

const char* aarch64_movsi(rtx x, rtx y)
{
  int offset;
  if (fp_rel(x, &offset) && REG_P(y)) {
    int regno = REGNO(y);
    fprintf(asm_out_file, "	str	w%d, [x29, %d]\n", regno, offset);
    return "";
  }
  if (REG_P(x) && CONST_INT_P(y)) {
    int regno = REGNO(x);
    int v = INTVAL(y);
    fprintf(asm_out_file, "	mov	w%d, %d\n", regno, v);
    return "";
  }
  if (REG_P(x) && REG_P(y)) {
    int rx = REGNO(x);
    int ry = REGNO(y);
    fprintf(asm_out_file, "	mov	w%d, w%d\n", rx, ry);
    return "";
  }

  return "%0 := %1";
}

const char* aarch64_movdi(rtx x, rtx y)
{
  if (REG_P(x) && REG_P(y))
    return "mov\t%0, %1";
  if (REG_P(x) && SYMBOL_REF_P(y)) {
    auto decl = SYMBOL_REF_DECL(y);
    assert(decl);
    auto name = DECL_NAME(decl);
    auto id = IDENTIFIER_POINTER(name);
    assert(*id == '*');
    int n = REGNO(x);
    switch (n) {
    case W0_REGNUM: case W1_REGNUM:
      fprintf(asm_out_file, "	adrp	x%d, %s\n", n, id+1);
      fprintf(asm_out_file, "	add	x%d, x%d, :lo12:%s\n", n, n, id+1);
      return "";
    default:
      abort();
    }
  }

  return "%0 := %1";
}

inline void load(rtx r, int offset)
{
  assert(GET_MODE(r) == SImode);
  assert(REG_P(r));
  int regno = REGNO(r);
  fprintf(asm_out_file, "	ldr	w%d, [x29, %d]\n", regno, offset);
}

const char* aarch64_addsi3(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    load(x, offy);
    auto w2 = gen_rtx_REG(SImode, W2_REGNUM);
    load(w2, offz);
    int n = REGNO(x);
    fprintf(asm_out_file, "	add	w%d, w%d, w%d\n", n, n, W2_REGNUM);
    return "";
  }

  return "%0 := %1 + %2";
}

const char* aarch64_call_value(rtx x, rtx fun)
{
  if (MEM_P(fun)) {
    auto y = XEXP(fun, 0);
    assert(SYMBOL_REF_P(y));
    auto z = XSTR(y, 0);
    fprintf(asm_out_file, "	bl	%s\n", z);
    assert(REG_P(x) && REGNO(x) == W0_REGNUM);
    return "";
  }

  return "%0 := call %1";
}
