#ifndef AARCH64_PROTOS_H
#define AARCH64_PROTOS_H

void aarch64_expand_prologue();
void aarch64_expand_epilogue();
const char* aarch64_cbranch(rtx op);
const char* aarch64_movsi(rtx x, rtx y);
const char* aarch64_movdi(rtx x, rtx y);
const char* aarch64_addsi3(rtx x, rtx y, rtx z);
const char* aarch64_call_value(rtx x, rtx fun);

#endif //  AARCH64_PROTOS_H
