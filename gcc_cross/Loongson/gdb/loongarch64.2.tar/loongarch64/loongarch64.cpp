#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia loongarch64_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void loongarch64_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint64_t loongarch64_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 32)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int loongarch64_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u = { loongarch64_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void loongarch64_reg_set_1(sim_cpu* cpu, int rn, uint64_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 32) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int loongarch64_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }

  loongarch64_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void andi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->r[rj] & I12;
  cpu->pc += 4;
}

static void
op0x0_3(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 22) & 3;
  switch (key) {
  case 1: return andi(sd, cpu, insn, cia);
  default: asm("int3");
  }
}

static int64_t sign_extend(int64_t x, int sb)
{
  int n = 64 - sb;
  return (x << n) >> n;
}

static void
addi_d(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->r[rj] + sign_extend(I12, 11);
  cpu->pc += 4;
}

static void move(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->r[rj];
  cpu->pc += 4;
}

static void add_w(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rk = (insn >> 10) & 0x1f;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->r[rj] + cpu->r[rk];
  cpu->pc += 4;
}

static void
slli_w(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto ui5 = (insn >> 10) & 0x1f;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->r[rj] << ui5;
  cpu->pc += 4;
}

static void
op0x0_0(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 15) & 0x3ff;
  switch (key) {
  case 0x20: return add_w(sd, cpu, insn, cia);
  case 0x2a: return move(sd, cpu, insn, cia);
  case 0x81: return slli_w(sd, cpu, insn, cia);
  default: asm("int3");
  }
}

static void op0x0(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 24) & 3;
  switch (key) {
  case 0: return op0x0_0(sd, cpu, insn, cia);
  case 1: asm("int3");
  case 2: return addi_d(sd, cpu, insn, cia);
  case 3: return op0x0_3(sd, cpu, insn, cia);
  }
}

static void
pcaddu12i(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I21 = (insn >> 5) & 0x1fffff;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->pc + sign_extend(I21, 20);
  cpu->pc += 4;
}

static uint64_t address_translation(uint64_t vaddr){ return vaddr; }

static void ld_x(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  auto vaddr = cpu->r[rj] + sign_extend(I12, 11);
  auto paddr = address_translation(vaddr);
  auto log2_sz = (insn >> 22) & 3;
  switch (log2_sz) {
  case 0:
    cpu->r[rd] = sim_core_read_aligned_1(cpu, cia, read_map, paddr);
    break;
  case 1:
    cpu->r[rd] = sim_core_read_aligned_2(cpu, cia, read_map, paddr);
    break;
  case 2:
    cpu->r[rd] = sim_core_read_aligned_4(cpu, cia, read_map, paddr);
    break;
  case 3:
    {
      uint64_t lo = sim_core_read_aligned_4(cpu, cia, read_map, paddr);
      uint64_t hi = sim_core_read_aligned_4(cpu, cia, read_map, paddr+4);
      cpu->r[rd] = (hi << 32) | lo;
    }
    break;
  }
  cpu->pc += 4;
}

static void
st_x(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  auto vaddr = cpu->r[rj] + sign_extend(I12, 11);
  auto paddr = address_translation(vaddr);
  auto log2_sz = (insn >> 22) & 3;
  switch (log2_sz) {
  case 0:
    {
      uint8_t v = cpu->r[rd];
      sim_core_write_aligned_1(cpu, cia, write_map, paddr, v);
    }
    break;
  case 1:
    {
      uint16_t v = cpu->r[rd];
      sim_core_write_aligned_2(cpu, cia, write_map, paddr, v);
    }
    break;
  case 2:
    {
      uint32_t v = cpu->r[rd];
      sim_core_write_aligned_4(cpu, cia, write_map, paddr, v);
    }
    break;
  case 3:
    {
      uint32_t lo = cpu->r[rd];
      uint32_t hi = cpu->r[rd] >> 32;
      sim_core_write_aligned_4(cpu, cia, write_map, paddr, lo);
      sim_core_write_aligned_4(cpu, cia, write_map, paddr+4, hi);
    }
    break;
  }
  cpu->pc += 4;
}

static void
op0xa(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 24) & 3;
  switch (key) {
  case 0: return ld_x(sd, cpu, insn, cia);
  case 1: return st_x(sd, cpu, insn, cia);
  default: asm("int3");
  }
}

static void bl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->r[1] = cpu->pc + 4;
  auto a = insn & 0x3ff;
  auto b = (insn >> 10) & 0xffff;
  auto off26 = (a << 18) | (b << 2);
  cpu->pc = cpu->pc + sign_extend(off26, 25);
}

static void
ldptr_d(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto I14 = I12 << 2;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  auto vaddr = cpu->r[rj] + sign_extend(I14, 13);
  auto paddr = address_translation(vaddr);
  uint64_t lo = sim_core_read_aligned_4(cpu, cia, write_map, paddr);
  uint64_t hi = sim_core_read_aligned_4(cpu, cia, write_map, paddr+4);
  cpu->r[rd] = (hi << 32) | lo;
  cpu->pc += 4;
}

static void
stptr_d(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I12 = (insn >> 10) & 0xfff;
  auto I14 = I12 << 2;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  auto vaddr = cpu->r[rj] + sign_extend(I14, 13);
  auto paddr = address_translation(vaddr);
  uint32_t lo = cpu->r[rd];
  uint32_t hi = cpu->r[rd] >> 32;
  sim_core_write_aligned_4(cpu, cia, write_map, paddr, lo);
  sim_core_write_aligned_4(cpu, cia, write_map, paddr+4, hi);
  cpu->pc += 4;
}

static void
op0x9(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 24) & 3;
  switch (key) {
  case 2: return ldptr_d(sd, cpu, insn, cia);
  case 3: return stptr_d(sd, cpu, insn, cia);
  default: asm("int3");
  }
}

static void jirl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto I14 = (insn >> 10) & 0x3fff;
  auto off16 = I14 << 2;
  auto rj = (insn >> 5) & 0x1f;
  auto rd = insn & 0x1f;
  cpu->r[rd] = cpu->pc + 4;
  cpu->pc = cpu->r[rj] + sign_extend(off16, 15);
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x0] = op0x0;
    (*this)[0x7] = pcaddu12i;
    (*this)[0x9] = op0x9;
    (*this)[0xa] = op0xa;
    (*this)[0x13] = jirl;
    (*this)[0x15] = bl;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  if (cia == 0x10c)
    asm("int3");
  uint8_t key = insn >> 26;
  auto p = table.find(key);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
  cpu->r[0] = 0;
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
