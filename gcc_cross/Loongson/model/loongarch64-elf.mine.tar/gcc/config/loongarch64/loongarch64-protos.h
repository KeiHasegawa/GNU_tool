#ifndef LOONGARCH64_PROTOS_H
#define LOONGARCH64_PROTOS_H

namespace loongarch64 {
  void expand_prologue();
  void expand_epilogue();
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  namespace di {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
} // end of namespace loongarch64

#endif //  LOONGARCH64_PROTOS_H
