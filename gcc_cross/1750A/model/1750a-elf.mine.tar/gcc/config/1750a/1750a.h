#ifndef M1750A_H
#define M1750A_H

#define REGISTER_NAMES      { \
  "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", \
  "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15", \
  "ap" }

#define ARG_POINTER_REGNUM	16
#define FIRST_PSEUDO_REGISTER	17

#define FIXED_REGISTERS     {  \
    0,   0,   0,   0,   1,   1,   1,   1, \
    1,   1,   1,   1,   1,   1,   1,   1, \
    1 }

#define CALL_USED_REGISTERS {  \
    1,   1,   1,   1,   1,   1,   1,   1, \
    1,   1,   1,   1,   1,   1,   1,   1, \
    1 }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000 },	\
/* SPECIAL_REGS */	 { 0xe001e000 },	\
/* GENERAL_REGS */	 { 0x00001fff },	\
/* ALL_REGS */           { 0x0001ffff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD		2
#define Pmode HImode
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           16
#define LONG_TYPE_SIZE		32
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64
#define POINTER_SIZE            16

typedef int CUMULATIVE_ARGS;
extern void m1750a_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  m1750a_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 4

#define STRICT_ALIGNMENT 1

#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 1
#define WORDS_BIG_ENDIAN 1

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("m1750a")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { \
    {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}, \
    {ARG_POINTER_REGNUM, STACK_POINTER_REGNUM},   \
    {ARG_POINTER_REGNUM, FRAME_POINTER_REGNUM} }

extern int m1750a_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET) \
  (OFFSET) = m1750a_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY  8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   ".section\t.bss"

#define STACK_GROWS_DOWNWARD 1

#define PUSH_ROUNDING(X)	(X)

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, LINK_REGNUM)

#endif // M1750A_H
