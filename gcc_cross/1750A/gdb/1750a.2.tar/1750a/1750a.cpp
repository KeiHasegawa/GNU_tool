#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia m1750a_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void m1750a_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint16_t m1750a_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 16)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int m1750a_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 2);
  union {
    uint16_t i;
    char c[2];
  } u = { m1750a_reg_get_1(cpu, rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[1]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void m1750a_reg_set_1(sim_cpu* cpu, int rn, uint16_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 16) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int m1750a_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 2);
  union {
    uint16_t i;
    char c[2];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[1]);
  }
  m1750a_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 2;
}

static void update_cs(sim_cpu* cpu, int16_t r)
{
  cpu->cs &= 0x8fff;
  if (r < 0)
    cpu->cs |= 0x1000;
  else if (!r)
    cpu->cs |= 0x2000;
  else
    cpu->cs |= 0x4000;
}

static void li(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] = addr;
  update_cs(cpu, cpu->r[ra]); 
  cpu->pc += 4;
}

static void js(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] = cpu->pc + 4;
  cpu->pc = addr;
}

static void sisp(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto ra = (insn >> 4) & 15;
  auto n = insn & 15;
  cpu->r[ra] -= n+1;
  update_cs(cpu, cpu->r[ra]);
  cpu->pc += 2;
}

static void pshm(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 4) & 15;
  int m = insn & 15;
  if (n <= m) {
    for (int i = n ; i != m+1; ++i)
      sim_core_write_aligned_2(cpu, cia, write_map, cpu->r[15] -= 2, cpu->r[i]);
  }
  else {
    for (int i = n ; i != m-1; --i)
      sim_core_write_aligned_2(cpu, cia, write_map, cpu->r[15] -= 2, cpu->r[i]);
  }
  cpu->pc += 2; 
}

static void lr(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 4) & 15;
  int m = insn & 15;
  cpu->r[n] = cpu->r[m];
  update_cs(cpu, cpu->r[n]);
  cpu->pc += 2;
}

static void st(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  sim_core_write_aligned_2(cpu, cia, write_map, addr, cpu->r[ra]);
  cpu->pc += 4;
}

static void l(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] = sim_core_read_aligned_2(cpu, cia, read_map, addr);
  cpu->pc += 4;
}

static void a(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] += sim_core_read_aligned_2(cpu, cia, read_map, addr);
  update_cs(cpu, cpu->r[ra]);
  cpu->pc += 4;
}

static void popm(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 4) & 15;
  int m = insn & 15;
  if (n <= m) {
    for (int i = n ; i != m+1; ++i) {
      cpu->r[i] = sim_core_read_aligned_2(cpu, cia, write_map, cpu->r[15]);
      cpu->r[15] += 2;
    }
  }
  else {
    for (int i = n ; i != m; --i) {
      cpu->r[i] = sim_core_read_aligned_2(cpu, cia, write_map, cpu->r[15]);
      cpu->r[15] += 2;
    }
  }
  cpu->pc += 2; 
}

static void aisp(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto ra = (insn >> 4) & 15;
  auto n = insn & 15;
  cpu->r[ra] += n+1;
  update_cs(cpu, cpu->r[ra]);
  cpu->pc += 2;
}

static void urs(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (insn & 15)
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  auto ra = (insn >> 4) & 15;
  cpu->pc = sim_core_read_aligned_2(cpu, cia, read_map, cpu->r[ra]);
  cpu->r[ra] += 2;
}

inline bool taken(int C)
{
  switch (C) {
  case 7:
    return true;
  default:
    abort();
  }
}

static void jci(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto C = (insn >> 4) & 15;
  if (taken(C))
    cpu->pc = addr;
  else
    cpu->pc += 4;
}

static void dst(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  sim_core_write_aligned_2(cpu, cia, write_map, addr, cpu->r[ra]);
  sim_core_write_aligned_2(cpu, cia, write_map, addr+2, cpu->r[ra+1]);
  cpu->pc += 4;
}

static void dl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] = sim_core_read_aligned_2(cpu, cia, read_map, addr);
  cpu->r[ra+1] = sim_core_read_aligned_2(cpu, cia, read_map, addr+2);
  cpu->pc += 4;
}

static void stub(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  assert(!(addr & 1));
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  sim_core_write_aligned_1(cpu, cia, write_map, addr, cpu->r[ra]);
  cpu->pc += 4;
}

static void stlb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto addr = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  assert(!(addr & 1));
  auto rx = insn & 15;
  if (rx)
    addr += cpu->r[rx];
  auto ra = (insn >> 4) & 15;
  sim_core_write_aligned_1(cpu, cia, write_map, addr+1, cpu->r[ra]);
  cpu->pc += 4;
}

static void aim(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto imm = sim_core_read_aligned_2(cpu, cia, read_map, cia+2);
  auto m = insn & 15;
  if (m != 1)
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  auto ra = (insn >> 4) & 15;
  cpu->r[ra] += imm;
  cpu->pc += 4;
}

static void cr(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int n = (insn >> 4) & 15;
  int m = insn & 15;
  update_cs(cpu, cpu->r[n] - cpu->r[m]);
  cpu->pc += 2;
}

static void bez(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (cpu->cs & 0x2000) {
    int8_t tmp = insn;
    cpu->pc += tmp + 2;
  }
  else
    cpu->pc += 2;
}

static void br(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  int8_t tmp = insn;
  cpu->pc += tmp + 2;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x84] = li;
    (*this)[0x72] = js;
    (*this)[0xff] = nop;
    (*this)[0x82] = sisp;
    (*this)[0x9f] = pshm;
    (*this)[0x81] = lr;
    (*this)[0x90] = st;
    (*this)[0x80] = l;
    (*this)[0xa0] = a;
    (*this)[0x8f] = popm;
    (*this)[0xa2] = aisp;
    (*this)[0x7f] = urs;
    (*this)[0x71] = jci;
    (*this)[0x96] = dst;
    (*this)[0x86] = dl;
    (*this)[0x9b] = stub;
    (*this)[0x9c] = stlb;
    (*this)[0x4a] = aim;
    (*this)[0xf1] = cr;
    (*this)[0x75] = bez;
    (*this)[0x74] = br;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  auto p = table.find(insn >> 8);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
