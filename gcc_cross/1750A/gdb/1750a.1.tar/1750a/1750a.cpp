#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia m1750a_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void m1750a_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint16_t m1750a_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 16)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int m1750a_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 2);
  union {
    uint16_t i;
    char c[2];
  } u = { m1750a_reg_get_1(cpu, rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[1]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void m1750a_reg_set_1(sim_cpu* cpu, int rn, uint16_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 16) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int m1750a_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 2);
  union {
    uint16_t i;
    char c[2];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[1]);
  }
  m1750a_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 2;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0xff] = nop;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  auto p = table.find(insn >> 8);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
