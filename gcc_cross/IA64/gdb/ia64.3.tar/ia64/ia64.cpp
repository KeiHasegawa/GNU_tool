#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <algorithm>
#include <vector>

extern "C" uint64_t ia64_reg_get_1(sim_cpu* cpu, int rn);

extern "C"
int ia64_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u = { ia64_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void ia64_reg_set_1(sim_cpu* cpu, int rn, uint64_t v);
  
extern "C"
int ia64_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }

  ia64_reg_set_1(cpu, rn, u.i);
  return length;
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
