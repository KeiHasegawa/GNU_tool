#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <algorithm>
#include <vector>

extern "C" sim_cia ia64_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void ia64_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint64_t ia64_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 331)
    return cpu->pc;
  if (rn == 332)
    return cpu->psr;
  if (rn == 333)
    return cpu->cfm;
  if (rn == 351) {  // bsp
#if 1
    if (auto bsp = cpu->ar[17])
      return bsp;
    return cpu->r[12];
#endif
#if 0    
    return cpu->r[12];
#endif
#if 0
    return cpu->ar[17];
#endif
#if 1
    return 0xfc0;
#endif    
  }
  if (rn == 398)  // pfs
    return cpu->ar[64];
  if (320 <= rn && rn < 320 + 8)
    return cpu->b[rn-320];
  asm("int3");
  return 0;
}

extern "C"
int ia64_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u = { ia64_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void ia64_reg_set_1(sim_cpu* cpu, int rn, uint64_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 331) {
    cpu->pc = v;
    return;
  }
  if (rn == 332) {
    cpu->psr = v;
    return;
  }
  if (rn == 333) {
    cpu->cfm = v;
    return;
  }
  if (rn == 351) {  // bsp
    cpu->ar[17] = v;
    return;
  }
  if (rn == 398) {  // pfs
    cpu->ar[64] = v;
    return;
  }
  asm("int3");
}

extern "C"
int ia64_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }

  ia64_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia);

struct sweeper {
  sim_cpu* cpu;
  enum type_t { NORMAL, LX, JUMP };
  type_t type;
  sweeper(sim_cpu* c, type_t t) : cpu{c}, type{t} {}
  ~sweeper()
  {
    cpu->r[0] = 0;
    switch (type) {
    case NORMAL:
      cpu->pc += 1;
      break;
    case LX:
      cpu->pc += 2;
      break;
    }

    switch (type) {
    case NORMAL:
    case LX:
      if ((cpu->pc & 3) == 3)
	cpu->pc += 13;
      break;
    }
    cpu->psr &= ~(3LL << 41);
    cpu->psr |= (cpu->pc & 3) << 41;
  }
};


static void nop(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
}

typedef void
(*FUNC_LX)(SIM_DESC sd, sim_cpu* cpu, uint64_t lo, uint64_t hi, sim_cia cia);


static void
mov_imm64(SIM_DESC sd, sim_cpu* cpu, uint64_t lo, uint64_t hi, sim_cia cia)
{
  sweeper obj(cpu, sweeper::LX);
  int r1 = (hi >> 6) & 0x7f;
  uint64_t imm7b = (hi >> 13) & 0x7f;
  uint64_t imm5c = (hi >> 22) & 0x1f;
  uint64_t imm9d = (hi >> 27) & 0x1ff;
  uint64_t ic = (hi >> 21) & 1;
  uint64_t imm41 = lo;
  uint64_t i = (hi >> 36) & 1;
  uint64_t imm64 = (i << 63) | (imm41 << 22) | (ic << 21) | (imm5c << 16) | (imm9d << 7) | imm7b;
  cpu->r[r1] = imm64;
}

struct table_lx_t : std::map<uint8_t, FUNC_LX> {
  table_lx_t()
  {
    (*this)[6] = mov_imm64;
  }
} table_lx;


static void add_imm22(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r1 = (insn >> 6) & 0x7f;
  int r3 = (insn >> 20) & 3;
  uint32_t s = (insn >> 36) & 1;
  uint32_t imm5c = (insn >> 22) & 0x1f;
  uint32_t imm9d = (insn >> 27) & 0x1ff;
  uint32_t imm7b = (insn >> 13) & 0x7f;
  int32_t imm22 = (s << 21) | (imm5c << 16) | (imm9d << 7) | imm7b;
  imm22 <<= 10;
  imm22 >>= 10;
  cpu->r[r1] = cpu->r[r3]+imm22;
}

static void alat_frame_update(sim_cpu*, int, int)
{
}

static void rse_preserve_frame(sim_cpu*, int)
{
}

static void br_call(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::JUMP);
  int b1 = (insn >> 6) & 7;
  uint32_t imm20b = (insn >> 13) & 0xfffff;
  uint32_t s = (insn >> 36) & 1;
  int32_t imm21 = (s << 20) | imm20b;
  imm21 <<= 11;
  imm21 >>= 7;
  uint64_t target25 = cia + imm21;
  target25 &= ~15;
  cpu->pc = target25;
  cpu->b[b1] = (cia+16) & ~15;
#if 0  
  auto ppl = (cpu->psr >> 32) & 3;
  auto ec = cpu->ar[66];
  auto& pfs = cpu->ar[64];
  pfs = (ppl << 62) | (ec << 52) | cpu->cfm;
  auto cfm_sol = (cpu->cfm >> 7) & 0x7f;
  alat_frame_update(cpu, cfm_sol, 0);
  rse_preserve_frame(cpu, cfm_sol);
  auto cfm_sof = cpu->cfm & 0x7f;
  cpu->cfm = cfm_sof - cfm_sol;
#endif  
}

static void check_target_register_sof(int r1, int sof)
{
}

static void illegal_operation_fault()
{
  abort();
}

static void reserved_register_field_fault()
{
  abort();
}

static void rse_new_frame(sim_cpu*, int, int)
{
}

static void alloc(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r1 = (insn >> 6) & 0x7f;
  int sof = (insn >> 13) & 0x7f;
  int sol = (insn >> 20) & 0x7f;
  int sor = (insn >> 27) & 0xf;
  int qp = insn & 0x1f;
  int r = sor << 3;
  check_target_register_sof(r1, sof);
  if (sof > 96 || r > sof || sol > sof || qp)
    illegal_operation_fault();
  auto cfm_sor = (cpu->cfm >> 14) & 0xf;
  auto cfm_rrb_gr = (cpu->cfm >> 18) & 0x7f;
  auto cfm_rrb_fr = (cpu->cfm >> 25) & 0x7f;
  auto cfm_rrb_pr = (cpu->cfm >> 32) & 0x3f;
  if (sor != cfm_sor && (cfm_rrb_gr || cfm_rrb_fr || cfm_rrb_pr))
    reserved_register_field_fault();
  auto cfm_sof = cpu->cfm & 0x7f;
  alat_frame_update(cpu, 0, sof-cfm_sof);
  rse_new_frame(cpu, cfm_sof, sof);
  auto new_value = cpu->cfm;
  new_value >>= 18;
  new_value <<= 18;
  new_value |= (sor << 14) | (sol << 7) | sof;
  cpu->cfm = new_value;
  auto pfs = cpu->ar[64];
  cpu->r[r1] = pfs;
  cpu->nat[r1] = 0;
}

static void add_imm14(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r1 = (insn >> 6) & 0x7f;
  int imm7b = (insn >> 13) & 0x7f;
  int imm6d = (insn >> 27) & 0x3f;
  int s = (insn >> 36) & 1;
  int imm14 = (s << 13) | (imm6d << 7) | imm7b;
  imm14 <<= 8;
  imm14 >>= 8;
  int r3 = (insn >> 20) & 0x7f;
  auto new_value = imm14 + cpu->r[r3];
  cpu->r[r1] = new_value;
}

static void add_r(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r1 = (insn >> 6) & 0x7f;
  int r2 = (insn >> 13) & 0x7f;
  int r3 = (insn >> 20) & 0x7f;
  auto new_value = cpu->r[r2] + cpu->r[r3];
  cpu->r[r1] = new_value;
}

static void add(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  int x2a = (insn >> 34) & 3;
  if (x2a == 2)
    return add_imm14(sd, cpu, insn, cia);
  if (x2a == 0)
    return add_r(sd, cpu, insn, cia);
  asm("int3");
}

static uint64_t ref_reg(sim_cpu* cpu, int regno)
{
  if (regno < 32)
    return cpu->r[regno];
  auto cfm_sol = (cpu->cfm >> 7) & 0x7f;
  return cpu->r[regno + cfm_sol];
}

static void ld_st(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  auto x = (insn >> 32) & 0xf;
  auto y = (insn >> 30) & 3;
  if (x == 0xc && y == 2) {
    int r2 = (insn >> 13) & 0x7f;
    int r3 = (insn >> 20) & 0x7f;
    auto addr = cpu->r[r3];
    auto data = ref_reg(cpu, r2);
    sim_core_write_aligned_4(cpu, cia, write_map, addr, data);
    if (r2 == 32) {
      cpu->ar[17] = addr;  // bsp
    }
    return;
  }
  if (x == 0x0 && y == 2) {
    int r1 = (insn >> 6) & 0x7f;
    int r3 = (insn >> 20) & 0x7f;
    auto addr = cpu->r[r3];
    uint64_t data = sim_core_read_aligned_4(cpu, cia, read_map, addr);
    cpu->r[r1] = data;
    return;
  }
  asm("int3");
}

static bool rse_restore_frame(sim_cpu* cpu, int, int)
{
  return false;
}

static void rse_enable_current_frame_load(sim_cpu*)
{
}

static int lower_priv_transition;

static void br_ret(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::JUMP);
  int b2 = (insn >> 13) & 7;
  cpu->pc = cpu->b[b2];
#if 0  
  auto pfs = cpu->ar[64];
  auto pfs_pfm = pfs & 0x3fffffffffLL;
  auto pfs_pfm_sof = pfs_pfm & 0x7f;
  auto pfs_pfm_sol = (pfs_pfm >> 7) & 0x7f;
  auto cfm_sof = cpu->cfm & 0x7f;
  auto tmp_growth = pfs_pfm_sof - pfs_pfm_sol - cfm_sof;
  alat_frame_update(cpu, -pfs_pfm_sol, 0);
  auto res_fatal = rse_restore_frame(cpu, pfs_pfm_sol, tmp_growth);
  if (res_fatal)
    cpu->cfm = 0;
  else
    cpu->cfm = pfs_pfm;
  rse_enable_current_frame_load(cpu);
  auto& ec = cpu->ar[66];
  auto pfs_pec = (pfs << 2) >> 54;
  ec = pfs_pec;
  auto psr_cpl = (cpu->psr >> 32) & 3;
  auto pfs_ppl = pfs >> 62;
  if (psr_cpl < pfs_ppl) {
    cpu->psr &= ~(3LL << 32);
    cpu->psr |= pfs_ppl << 32;
    lower_priv_transition = 1;
  }
#endif  
}

static void movi_to_ar(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r2 = (insn >> 13) & 0x7f;
  int ar3 = (insn >> 20) & 0x7f;
  cpu->ar[ar3] = cpu->r[r2];  
}

static void mov_from_br(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int r1 = (insn >> 6) & 0x7f;
  int b2 = (insn >> 13) & 7;
  cpu->r[r1] = cpu->b[b2];
}

static void mov_to_br(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  sweeper obj(cpu, sweeper::NORMAL);
  int b1 = (insn >> 6) & 7;
  int r2 = (insn >> 13) & 0x7f;
  cpu->b[b1] = cpu->r[r2];
}

static void op0x0(SIM_DESC sd, sim_cpu* cpu, uint64_t insn, sim_cia cia)
{
  int x6 = (insn >> 27) & 0x3f;
  int btype = (insn >> 6) & 7;
  if (x6 == 0x21 && btype == 4)
    return br_ret(sd, cpu, insn, cia);
  if (x6 == 0x2a)
    return movi_to_ar(sd, cpu, insn, cia);
  int x3 = (insn >> 33) & 7;
  if (x6 == 0x31 && x3 == 0)
    return mov_from_br(sd, cpu, insn, cia);
  if (x3 == 7)
    return mov_to_br(sd, cpu, insn, cia);
  nop(sd, cpu, insn, cia);
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0] = op0x0;
    (*this)[1] = alloc;
    (*this)[4] = ld_st;
    (*this)[5] = br_call;
    (*this)[8] = add;
    (*this)[9] = add_imm22;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, uint32_t tmp, sim_cia cia)
{
  auto b1_0 = cia & 3;;
  assert(b1_0 != 3);
  auto base = cia & ~3;
  uint64_t next[] = {
    sim_core_read_aligned_4(cpu, cia, read_map, base+0x4),
    sim_core_read_aligned_4(cpu, cia, read_map, base+0x8),
    sim_core_read_aligned_4(cpu, cia, read_map, base+0xc),
  };
  auto templ = tmp & 0x1f;
  uint64_t insn[] = {
    ((next[0] & 0x3fff) << 27) | (tmp >> 5),
    ((next[1] & 0x7fffff) << 18) | (next[0] >> 14),
    (next[2] << 9) | (next[1] >> 23),
  };

  if (insn[b1_0] == 0x3333300) {
    cpu->psr &= ~(3LL << 41);
    cpu->psr |= b1_0 << 41;
    sim_engine_halt(sd, cpu, 0, cia, sim_stopped, SIM_SIGTRAP);
  }

  if ((templ == 4 || templ == 5) && b1_0 == 1) {
    uint64_t opc = insn[2] >> 37;
    auto p = table_lx.find(opc);
    if (p == end(table_lx)) {
      asm("int3");
      sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
    }
    auto fn = p->second;
    fn(sd, cpu, insn[1], insn[2], cia);
    return;
  }

  if ((templ == 4 || templ == 5) && b1_0 == 2)
    return;

  uint64_t opc = insn[b1_0] >> 37;
  auto p = table.find(opc);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }
  auto fn = p->second;
  fn(sd, cpu, insn[b1_0], cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
