#include "sim-main.h"
#include "sim-options.h"
#include "sim-signal.h"
#include <assert.h>

sim_cia ia64_pc_get(sim_cpu* cpu);

void ia64_pc_set(sim_cpu* cpu, sim_cia pc);

int ia64_reg_get(sim_cpu* cpu, int rn, unsigned char *buf, int length);

int ia64_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length);

SIM_DESC sim_open(SIM_OPEN_KIND kind, struct host_callback_struct *callback,
		  struct bfd* abfd, char* const* argv)
{
  SIM_DESC sd = sim_state_alloc (kind, callback);
  assert(sd);

  if (sim_cpu_alloc_all(sd, 1) != SIM_RC_OK)
    return 0;

  if (sim_pre_argv_init(sd, argv[0]) != SIM_RC_OK)
    return 0;

  if (sim_parse_args(sd, argv) != SIM_RC_OK)
    return 0;

  if (sim_analyze_program(sd,
			  (STATE_PROG_ARGV (sd) != NULL
			   ? *STATE_PROG_ARGV(sd)
			   : NULL), abfd) != SIM_RC_OK)
    return 0;

  if (sim_config(sd) != SIM_RC_OK)
    return 0;

  if (sim_post_argv_init(sd) != SIM_RC_OK)
    return 0;

  sim_cpu* cpu = STATE_CPU(sd, 0);
  CPU_PC_FETCH(cpu) = ia64_pc_get;
  CPU_PC_STORE(cpu) = ia64_pc_set;

  CPU_REG_FETCH(cpu) = ia64_reg_get;
  CPU_REG_STORE(cpu) = ia64_reg_set;

  return sd;
}

SIM_RC sim_create_inferior (SIM_DESC sd, struct bfd *abfd,
			    char * const *argv, char * const *env)
{
  if (abfd) {
    sim_cpu* cpu = STATE_CPU(sd, 0);
    ia64_pc_set(cpu, bfd_get_start_address (abfd));
  }
  return SIM_RC_OK;
}

char* simulator_sysroot = "";

instruction_word ia64_fetch(SIM_DESC sd, sim_cia cia)
{
  sim_cpu* cpu =  STATE_CPU(sd, 0);
  cia &= ~3LL;
  return sim_core_read_aligned_4(cpu, cia, read_map, cia);
}

uint32_t ia64_reg_get_1(sim_cpu* cpu, int rn);

static uint32_t get_addr(sim_cpu* cpu, sim_cia cia, _Bool ref_stack)
{
  if (ref_stack) {
    uint32_t sp = ia64_reg_get_1(cpu, 31);
    return sim_core_read_aligned_4(cpu, cia, read_map, sp+4);
  }
  return ia64_reg_get_1(cpu, 4);
}

const char* first_string(sim_cpu* cpu, sim_cia cia, _Bool ref_stack)
{
  uint32_t addr = get_addr(cpu, cia, ref_stack);
  static char buff[1024];
  for (int i = 0 ; i != sizeof buff/sizeof buff[0] ; ++i) {
    char c = sim_core_read_aligned_1(cpu, cia, read_map, addr + i);
    buff[i] = c;
    if (c == '\0')
      return &buff[0];  // ok
  }

  // not enough buffer
  abort();
}

enum arg_class { NONE, WORD, DWORD, DFLT, LDFLT, STR };

const char* get_part(const char* fmt, enum arg_class* how)
{
  for ( ; *fmt ; ++fmt) {
    char c = *fmt;
    if (c == 'd' || c == 'i' || c == 'x' || c == 'u') {
      if (*how == NONE)
	*how = WORD;
      else
	assert(*how == WORD || *how == DWORD);
      return ++fmt;
    }
    if (c == 'c') {
      *how = WORD;
      return ++fmt;
    }
    if (c == 'f') {
      char prev = *(fmt-1);
      *how = prev == 'L' ? LDFLT : DFLT;
      return ++fmt;
    }
    if (c == 's') {
      *how = STR;
      return ++fmt;
    }
    if (c == 'l') {
      if (*how == NONE)
	*how = WORD;
      else {
	assert(*how == WORD);
	*how = DWORD;
      }
    }
  }
  abort(); // unexpected format
}

uint32_t arg32(sim_cpu* cpu, sim_cia cia, int n)
{
#if 0  
  if (n == 1)
    return ia64_reg_get_1(cpu, 4);
  if (n == 2)
    return ia64_reg_get_1(cpu, 16+4);
#endif  
  uint32_t sp = ia64_reg_get_1(cpu, 31);
  uint32_t addr = sp + 4 * (n+1);
  return sim_core_read_aligned_4(cpu, cia, read_map, addr);
}

uint64_t arg64(sim_cpu* cpu, sim_cia cia, int n)
{
  uint32_t sp = ia64_reg_get_1(cpu, 31);
  uint32_t addr = sp + 4 * (n+1);
  uint64_t lo = sim_core_read_aligned_4(cpu, cia, read_map, addr);
  uint64_t hi = sim_core_read_aligned_4(cpu, cia, read_map, addr+4);
  return (hi << 32) | lo;
}

const char*
handle(sim_cpu* cpu, sim_cia cia, const char* fmt, int* nth, int* ret)
{
  char c = *fmt;
  if (c != '%') {
    putchar(c);
    ++*ret;
    return fmt+1;
  }
  const char* beg = fmt;
  c = *++fmt;
  if (c == '%') {
    putchar(c);
    ++*ret;
    return fmt+1;
  }
  enum arg_class how = NONE;
  const char* end = get_part(fmt, &how);
  char part_fmt[256];
  int n = end - beg;
  assert(n + 1 < sizeof part_fmt/sizeof part_fmt[0]);
  strncpy(&part_fmt[0], beg, n);
  part_fmt[n] = '\0';
  if (how == WORD) {
    uint32_t arg = arg32(cpu, cia, (*nth)++);
    *ret += printf(part_fmt, arg);
    return end;
  }
  if (how == DWORD) {
    uint64_t arg = arg64(cpu, cia, *nth);
    *nth += 2;
    *ret += printf(part_fmt, arg);
    return end;
  }
  if (how == DFLT || how == LDFLT) {
    union {
      uint64_t i;
      double d;
    } u = { arg64(cpu, cia, *nth) };
    *nth += 2;
    if (how == DFLT)
      *ret += printf(part_fmt, u.d);
    else
      *ret += printf(part_fmt, (long double)u.d);
    return end;
  }
  assert(how == STR);
  uint32_t addr = arg32(cpu, cia, (*nth)++);
  char buf[256];
  for (int i = 0 ; i != sizeof buf/sizeof buf[0] ; ++i) {
    char c = sim_core_read_aligned_1(cpu, cia, read_map, addr+i);
    buf[i] = c;
    if (c == '\0') {
      *ret += printf(part_fmt, &buf[0]);  // ok
      return end;
    }
  }
  abort(); // not enough buffer
}

void ia64_reg_set_1(sim_cpu* cpu, int rn, uint32_t v);

void do_printf(sim_cpu* cpu, sim_cia cia)
{
  const char* fmt = first_string(cpu, cia, TRUE);
  int nargc = 1;
  int ret = 0;
  while (*fmt)
    fmt = handle(cpu, cia, fmt, &nargc, &ret);
  ia64_reg_set_1(cpu, 4, ret);
}

void do_puts(sim_cpu* cpu, sim_cia cia)
{
  const char* arg = first_string(cpu, cia, FALSE);
  int ret = puts(arg);  
  ia64_reg_set_1(cpu, 4, ret);
}

void do_putchar(sim_cpu* cpu, sim_cia cia)
{
  int arg = ia64_reg_get_1(cpu, 4);
  int ret = putchar(arg);
  ia64_reg_set_1(cpu, 4, ret);
}

void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia);

sim_cia idecode_issue(SIM_DESC sd, instruction_word insn, sim_cia cia)
{
  sim_cpu* cpu = STATE_CPU(sd, 0);
#if 0  
  switch (insn) {
  case 0xcccd:
    exit(0);
    break;
  case 0xccce:
    do_printf(cpu, cia);
    ia64_pc_set(cpu, cia+4);
    return cia+4;
  case 0xcccf:
    do_puts(cpu, cia);
    ia64_pc_set(cpu, cia+4);
    return cia+4;
  case 0xcccb:
    do_putchar(cpu, cia);
    ia64_pc_set(cpu, cia+4);
    return cia+4;
  }
#endif  
  execute_for_me(sd, cpu, insn, cia);
  return ia64_pc_get(cpu);
}
