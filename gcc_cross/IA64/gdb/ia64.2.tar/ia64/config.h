#ifndef CONFIG_H
#define CONFIG_H

#define HAVE_STDLIB_H 1

#define HAVE_STRING_H 1

#define HAVE_LIMITS_H 1

#define HAVE_UNISTD_H 1

#define PACKAGE "sim"

#define WITH_STDIO 0

#define WITH_ENVIRONMENT ALL_ENVIRONMENT

#define WITH_TRACE ~TRACE_debug

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <sys/stat.h>
#include <sys/mman.h>
#include <errno.h>
#include <fcntl.h>

#define WITH_DEBUG 0

#define PKGVERSION "(SIM) "

typedef void RETSIGTYPE;

#endif // CONFIG_H
