#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia ia64_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void ia64_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint64_t ia64_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 331)
    return cpu->pc;
  if (rn == 332)
    return cpu->psr;
  if (rn == 333)
    return cpu->cfm;
  if (rn == 351)
    return cpu->bsp;
  asm("int3");
  return 0;
}

extern "C"
int ia64_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u = { ia64_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void ia64_reg_set_1(sim_cpu* cpu, int rn, uint64_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 331) {
    cpu->pc = v;
    return;
  }
  if (rn == 332) {
    cpu->psr = v;
    return;
  }
  if (rn == 333) {
    cpu->cfm = v;
    return;
  }
  if (rn == 351) {
    cpu->bsp = v;
    return;
  }
  asm("int3");
}

extern "C"
int ia64_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }

  ia64_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void
nop_i2(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 4;
}

struct tablei2_t : std::map<uint8_t, FUNC> {
  tablei2_t()
  {
    (*this)[0x00] = nop_i2;
  }
} tablei2;


static void
nop_i(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 6;
  auto next = sim_core_read_aligned_4(cpu, cpu->pc, read_map, cpu->pc);
  uint8_t key = next;
  auto p = tablei2.find(key);
  if (p == end(tablei2)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cpu->pc, sim_stopped, SIM_SIGILL);
  }
  auto fn = p->second;
  fn(sd, cpu, next, cia);
}

struct tablei_t : std::map<uint8_t, FUNC> {
  tablei_t()
  {
    (*this)[0x00] = nop_i;
  }
} tablei;

static void
nop_m(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 6;
  instruction_word lo =
    sim_core_read_aligned_2(cpu, cpu->pc, read_map, cpu->pc);
  instruction_word hi =
    sim_core_read_aligned_2(cpu, cpu->pc, read_map, cpu->pc+2);
  instruction_word next = (hi << 16) | lo;
  uint8_t key = next;
  auto p = tablei.find(key);
  if (p == end(tablei)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cpu->pc, sim_stopped, SIM_SIGILL);
  }
  auto fn = p->second;
  fn(sd, cpu, next, cia);
}

struct tablem_t : std::map<uint8_t, FUNC> {
  tablem_t()
  {
    (*this)[0x00] = nop_m;
  }
} tablem;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  uint8_t key = insn;
  auto p = tablem.find(key);
  if (p == end(tablem)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
