#ifndef SIM_MAIN_H
#define SIM_MAIN_H

#include "sim-basics.h"

#include "sim-base.h"

struct _sim_cpu {
  sim_cpu_base base;
  uint64_t r[128];
  uint64_t pc;
  uint64_t psr;
  uint64_t cfm;
  uint64_t bsp;
};

typedef struct _sim_cpu sim_cpu;

typedef uint32_t instruction_word;

instruction_word ia64_fetch(SIM_DESC sd, sim_cia cia);

#define IMEM32(CIA) ia64_fetch(sd, CIA)

sim_cia idecode_issue(SIM_DESC sd, instruction_word insn, sim_cia cia);
  
#endif // SIM_MAIN_H
