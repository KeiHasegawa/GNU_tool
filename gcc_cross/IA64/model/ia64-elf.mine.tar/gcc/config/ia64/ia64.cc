#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <set>

rtx ia64_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return gen_rtx_REG(mode, 8);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE ia64_function_value

bool ia64_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P ia64_legitimate_address_p


void
ia64_init_cumulative_args(CUMULATIVE_ARGS* nregs, tree, rtx, tree, int)
{
  *nregs = 0;
}

void ia64_function_arg_advance(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  (void)arg;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 8)
    ++*nregs;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE ia64_function_arg_advance

rtx ia64_function_incoming_arg(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  auto mode = arg.mode;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 8)
    return gen_rtx_REG(mode, FIRST_ARG_REGNUM + *nregs);
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG ia64_function_incoming_arg

namespace ia64 {
  int outgoing_args_num;
} // end of namespace ia64

rtx ia64_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  auto mode = arg.mode;
  auto nregs = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (*nregs < 8) {
    ia64::outgoing_args_num = *nregs;
    return gen_rtx_REG(mode, FIRST_ARG_REGNUM + 4 + *nregs);
  }
  return nullptr;
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG ia64_function_arg

void ia64_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    if (SYMBOL_REF_P(e0)) {
      auto s = XSTR(e0, 0);
      fprintf(fp, "%s", s);
      return;
    }
  }
  if (SYMBOL_REF_P(x)) {
    auto s = XSTR(x, 0);
    assert(*s == '*');
    fprintf(fp, "%s", s);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

#undef TARGET_PRINT_OPERAND
#define TARGET_PRINT_OPERAND ia64_print_operand

int ia64_incoming_args_num()
{
  auto func = TREE_TYPE(current_function_decl);
  auto chain = TYPE_ARG_TYPES(func);

  int s = 0;
  for ( ; chain ; chain = TREE_CHAIN(chain)) {
    auto arg = TREE_VALUE(chain);
    auto mode = TYPE_MODE(arg);
    int size = GET_MODE_SIZE(mode);
    if (size)
      ++s;
  }
  return s;
}

void ia64_function_prologue(FILE* fp)
{
  int i = ia64_incoming_args_num();
  int o = ia64::outgoing_args_num;
  ia64::outgoing_args_num = 0;
  fprintf(fp, "	.prologue\n");
  int n = 33+i;
  fprintf(fp, "	.save	ar.pfs, r%d\n", n);
  fprintf(fp, "	alloc	r%d = ar.pfs, %d, 4, %d, 0\n", n, i, o);
}

#undef TARGET_ASM_FUNCTION_PROLOGUE
#define TARGET_ASM_FUNCTION_PROLOGUE ia64_function_prologue

void ia64_function_begin_epilogue(FILE* fp)
{
  int i = ia64_incoming_args_num();
  fprintf(fp, "	mov	ar.pfs = r%d\n", 33+i);
}

#undef TARGET_ASM_FUNCTION_BEGIN_EPILOGUE
#define TARGET_ASM_FUNCTION_BEGIN_EPILOGUE ia64_function_begin_epilogue

void ia64_function_epilogue(FILE* fp)
{
  auto s = DECL_NAME(current_function_decl);
  auto t = IDENTIFIER_POINTER(s);
  fprintf(fp, "	.endp	%s#\n", t);
}

#undef TARGET_ASM_FUNCTION_EPILOGUE
#define TARGET_ASM_FUNCTION_EPILOGUE ia64_function_epilogue

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('#', fp);
  putc('\n', fp);
}

int FUNCTION_ARG_REGNO_P(int regno)
{
  return 8 <= regno && regno < FIRST_ARG_REGNUM + 8;
}

int REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case ZERO_REGNUM:
  case GLOBAL_POINTER_REGNUM:
  case STACK_POINTER_REGNUM:
  case DUMMY_REGNUM:
    return SPECIAL_REGS;
  default:
    return regno < 128 ? GENERAL_REGS : SPECIAL_REGS;
  }
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 16;
}

int REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}


int ia64_initial_elimination_offset(int from, int to)
{
  assert(from == STACK_POINTER_REGNUM && to == STACK_POINTER_REGNUM);
  return 0;
}

bool ia64_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}

namespace ia64 {
  using namespace std;
  set<rtx> vframe;
  set<rtx> save_rp;
  set<rtx> body;
} // end of namespace ia64

void ia64::expand_prologue()
{
  int i = ia64_incoming_args_num();

  auto sp = stack_pointer_rtx;
  auto r34 = gen_rtx_REG(Pmode, 34+i);
  emit_move_insn(r34, sp);
  vframe.insert(r34);

  if (auto size = get_frame_size()) {
    auto minus = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
    emit_move_insn(sp, minus);
  }

  auto r32 = gen_rtx_REG(Pmode, 32+i);
  auto b0 = gen_rtx_REG(Pmode, B0_REGNUM);  
  emit_move_insn(r32, b0);
  save_rp.insert(r32);
  
  auto r35 = gen_rtx_REG(Pmode, 35+i);
  auto gp = gen_rtx_REG(Pmode, GLOBAL_POINTER_REGNUM);
  emit_move_insn(r35, gp);
  body.insert(r35);
}

namespace ia64 {
  set<rtx> restore_sp;
} // end of namespace ia64

void ia64::expand_epilogue()
{
  int i = ia64_incoming_args_num();
  
  auto b0 = gen_rtx_REG(Pmode, B0_REGNUM);
  auto r32 = gen_rtx_REG(Pmode, 32+i);
  emit_move_insn(b0, r32);
  
  auto sp = stack_pointer_rtx;
  auto r34 = gen_rtx_REG(Pmode, 34+i);
  emit_move_insn(sp, r34);
  restore_sp.insert(r34);
  
  emit_jump_insn(ret_rtx);
}

const char* ia64::cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

namespace ia64 {
  namespace si {
    void store_sp(int regno, int offx)
    {
      auto rn = reg_names[regno];
      auto sp = reg_names[STACK_POINTER_REGNUM];
      if (!offx) {
	fprintf(asm_out_file, "	st4	[%s] = %s\n", sp, rn);
	return;
      }
      int scratch = 2;
      auto scr = reg_names[scratch];
      fprintf(asm_out_file, "	adds	%s = %d, %s\n", scr, offx, sp);
      fprintf(asm_out_file, "	st4	[%s] = %s\n", scr, rn);
    }
    void load_sp(int regno, int offy)
    {
      auto rn = reg_names[regno];
      auto sp = reg_names[STACK_POINTER_REGNUM];
      if (!offy) {
	fprintf(asm_out_file, "	ld4	%s = [%s]\n", rn, sp);
	return;
      }
      int scratch = 2;
      auto scr = reg_names[scratch];
      fprintf(asm_out_file, "	adds	%s = %d, %s\n", scr, offy, sp);
      fprintf(asm_out_file, "	ld4	%s = [%s]\n", rn, scr);
    }
  } // end of namespace si
} // end of namespace ia64

inline bool sp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code != PLUS) {
    if (!REG_P(y))
      return false;
    int regno = REGNO(y);
    if (regno != STACK_POINTER_REGNUM)
      return false;
    *offset = 0;
    return true;
  }
  auto z = XEXP(y, 0);
  if (!REG_P(z))
    return false;
  int regno = REGNO(z);
  if (regno != STACK_POINTER_REGNUM)
    return false;
  auto u = XEXP(y, 1);
  if (!CONST_INT_P(u))
    return false;
  *offset = INTVAL(u);
  return true;
}

const char* ia64::si::mov(rtx x, rtx y)
{
  int offx;
  if (sp_rel(x, &offx) && REG_P(y)) {
    store_sp(REGNO(y), offx);
    return "";
  }
  int offy;
  if (REG_P(x) && sp_rel(y, &offy)) {
    load_sp(REGNO(x), offy);
    return "";
  }
  if (REG_P(x) && CONST_INT_P(y))
    return "addl	%0 = %1, r0";
  if (REG_P(x) && REG_P(y))
    return "mov	%0 = %1";
  return "%0 := %1";
}

const char* ia64::si::add(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && sp_rel(y, &offy) && sp_rel(z, &offz)) {
    int regno REGNO(x);
    load_sp(regno, offy);
    int scratch = 14;
    load_sp(scratch, offz);
    auto rn = reg_names[regno];
    auto scr = reg_names[scratch];
    fprintf(asm_out_file, "	add	%s = %s, %s\n", rn, rn, scr);
    return "";
  }
  return "%0 := %1 + %2";
}

const char* ia64::si::sub(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  return "%0 := %1 - %2";
}

namespace ia64 {
  namespace di {
    void load_sym(int regno, const char* s)
    {
      auto rn = reg_names[regno];
      fprintf(asm_out_file, "	movl	%s = @gprel(%s)\n", rn, s);
      fprintf(asm_out_file, "	add	%s = r1, %s\n", rn, rn);
    }
  } // end of namespace di
} // end of namespace ia64

const char* ia64::di::mov(rtx x, rtx y)
{
  if (REG_P(x) && REG_P(y)) {
    auto p = vframe.find(x);
    if (p != end(vframe)) {
      vframe.erase(p);
      return ".vframe	%0\n\tmov	%0 = %1";
    }
    auto q = save_rp.find(x);
    if (q != end(save_rp)) {
      save_rp.erase(q);
      return ".save	rp, %0\n\tmov	%0 = %1";
    }
    auto r = restore_sp.find(y);
    if (r != end(restore_sp)) {
      restore_sp.erase(r);
      return ".restore	sp\n\tmov	%0 = %1";
    }
    auto s = body.find(x);
    if (s != end(body)) {
      body.erase(s);
      return "mov	%0 = %1\n\t.body";
    }
    return "mov	%0 = %1";
  }
  if (REG_P(x) && SYMBOL_REF_P(y)) {
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    load_sym(REGNO(x), s);
    return "";
  }
  return "%0 := %1";
}

const char* ia64::di::add(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  return "%0 := %1 + %2";
}

const char* ia64::di::sub(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y) && CONST_INT_P(z))
    return "adds	%0 = -%2, %1";
  return "%0 := %1 - %2";
}

const char* ia64::call(rtx fun)
{
  (void)fun;
  return "call %0";
}

const char* ia64::call_value(rtx x, rtx fun)
{
  if (REG_P(x) && MEM_P(fun)) {
    int regno = REGNO(x);
    assert(regno == 8);
    auto e0 = XEXP(fun, 0);
    assert(SYMBOL_REF_P(e0));
    auto s = XSTR(e0, 0);
    fprintf(asm_out_file, "	br.call.sptk.many b0 = %s\n", s);
    fprintf(asm_out_file, "	mov	r1 = r35\n");
    return "";
  }
  return "%0 := call %1";
}
