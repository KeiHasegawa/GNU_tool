#ifndef IA64_H
#define IA64_H

#define REGISTER_NAMES      { \
  "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", \
  "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15", \
  "r16", "r17", "r18", "r19", "r20", "r21", "r22", "r23", \
  "r24", "r25", "r26", "r27", "r28", "r29", "r30", "r31", \
  "r32", "r33", "r34", "r35", "r36", "r37", "r38", "r39", \
  "r40", "r41", "r42", "r43", "r44", "r45", "r46", "r47", \
  "r48", "r49", "r50", "r51", "r52", "r53", "r54", "r55", \
  "r56", "r57", "r58", "r59", "r60", "r61", "r62", "r63", \
  "r64", "r65", "r66", "r67", "r68", "r69", "r70", "r71", \
  "r72", "r73", "r74", "r75", "r76", "r77", "r78", "r79", \
  "r80", "r81", "r82", "r83", "r84", "r85", "r86", "r87", \
  "r88", "r89", "r90", "r91", "r92", "r93", "r94", "r95", \
  "r96", "r97", "r98", "r99", "r100", "r101", "r102", "r103", \
  "r104", "r105", "r106", "r107", "r108", "r109", "r110", "r111", \
  "r112", "r113", "r114", "r115", "r116", "r117", "r118", "r119", \
  "r120", "r121", "r122", "r123", "r124", "r125", "r126", "r127", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "", "", "", "", "", "", "", "", \
  "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", \
  "dummy" }

#define ZERO_REGNUM           0
#define GLOBAL_POINTER_REGNUM 1
#define STACK_POINTER_REGNUM  12
#define FRAME_POINTER_REGNUM  12
#define ARG_POINTER_REGNUM    FRAME_POINTER_REGNUM
#define FIRST_ARG_REGNUM      32
#define B0_REGNUM             320
#define DUMMY_REGNUM          328
#define FIRST_PSEUDO_REGISTER 329

#define FIXED_REGISTERS     { \
  1, 1, 1, 1, 1, 1, 1, 1, \
  0, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1 }

#define CALL_USED_REGISTERS     { \
  0, 0, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1, 1, 1, 1, 1, 1, 1, 1, \
  1 }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */      {{ 0x00000000, 0x00000000, 0x00000000, 0x00000000, \
	              0x00000000, 0x00000000, 0x00000000, 0x00000000, \
	              0x00000000, 0x00000000, 0x0 }, \
/* SPECIAL_REGS */  { 0x00001003, 0x00000000, 0x00000000, 0x00000000, \
	              0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, \
	              0xffffffff, 0xffffffff, 0x1 }, \
/* GENERAL_REGS */  { 0xffffeffc, 0xffffffff, 0xffffffff, 0xffffffff, \
	              0x00000000, 0x00000000, 0x00000000, 0x00000000, \
	              0x00000000, 0x00000000, 0x0 }, \
/* ALL_REGS */      { 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, \
	              0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, \
                      0xffffffff, 0xffffffff, 0x1 }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 8
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           32
#define LONG_TYPE_SIZE		32
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

typedef int CUMULATIVE_ARGS;
extern void ia64_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  ia64_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 8

#define STRICT_ALIGNMENT 1
#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 0
#define WORDS_BIG_ENDIAN 0

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("ia64")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode DImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {STACK_POINTER_REGNUM, STACK_POINTER_REGNUM} }

extern int ia64_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET) \
  (OFFSET) = ia64_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY  8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N ? 1 << N : 0)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.sdata"
#define BSS_SECTION_ASM_OP   "\t.sbss"

#define STACK_GROWS_DOWNWARD 1

#define ASM_OUTPUT_TYPE_DIRECTIVE(STREAM, NAME, TYPE)	\
  do							\
    {							\
      fputs (TYPE_ASM_OP, STREAM);			\
      assemble_name (STREAM, NAME);			\
      putc ('#', STREAM);				\
      fputs (", ", STREAM);				\
      fprintf (STREAM, TYPE_OPERAND_FMT, TYPE);		\
      putc ('\n', STREAM);				\
      fprintf (STREAM, "	.proc	%s#\n", NAME);	\
    }							\
  while (0)

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, B0_REGNUM)

#endif // IA64_H
