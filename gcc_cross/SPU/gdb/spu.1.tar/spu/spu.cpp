#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia spu_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void spu_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

uint32_t spu_reg_get_1(sim_cpu* cpu, int rn)
{
  if (rn == 16)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int spu_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { spu_reg_get_1(cpu, rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C"
int spu_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  asm("int3");
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 4;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x40] = nop;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  if (insn == 0xcccccccc)
    sim_engine_halt(sd, cpu, 0, cia, sim_stopped, SIM_SIGTRAP);

  auto p = table.find(insn >> 24);
  if (p == end(table))
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
