#include "sim-main.h"
#include <cassert>
#include <map>

extern "C" sim_cia spu_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void spu_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t spu_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < 128)
    return cpu->r[rn].i32[0];
  if (rn == 128)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C" uint64_t spu_reg_get_64(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < 128) {
    uint64_t hi = cpu->r[rn].i32[0];
    uint64_t lo = cpu->r[rn].i32[1];
    return (hi << 32) | lo;
  }
  asm("int3");
  return 0;
}

#if 0
int spu_reg_get_1(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 16);
  assert(rn < 128);  
  for (int i = 0 ; i != 4 ; ++i) {
    union {
      uint32_t i;
      char c[4];
    } u = { cpu->r[rn].i32[i] };
    int n = 1;
    if (*(char*)&n) {
      // simulator runs at little endian processor
      std::swap(u.c[0], u.c[3]);
      std::swap(u.c[1], u.c[2]);
    }
    memcpy(buf+4*i, &u.c[0], 4);
  }
  return length;
}
#endif

extern "C"
int spu_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
#if 0  
  if (length == 16)
    return spu_reg_get_1(cpu, rn, buf, length);
#endif  
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { spu_reg_get_1(cpu, rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void spu_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < 128) {
    cpu->r[rn].i32[0] = v;
    return;
  }
  if (rn == 128) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int spu_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  spu_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 4;
}

static void il(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = I16;
  cpu->pc += 4;
}

static void
op0x40(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto fn = (insn & (1 << 23)) ? il : nop;
  fn(sd, cpu, insn, cia);
}

static void brsl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  cpu->r[rt].i32[0] = (cia + 4) & ~3;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  cpu->pc += I16 << 2;
}

static int32_t sign_ext(int32_t v, int sc)
{
  return (v << sc) >> sc;
}

static void stqd(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto base = cpu->r[ra].i32[0] + sign_ext(I10 << 4, 18);
  for (int i = 0 ; i != 4 ; ++i) {
    auto addr = base + 4 * i;    
    auto val = cpu->r[rt].i32[i];
    sim_core_write_aligned_4(cpu, cia, write_map, addr, val);
  }
  cpu->pc += 4;
}

static void stqr(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  auto base = (cpu->pc + (I16 << 2)) & ~15;
  for (int i = 0 ; i != 4 ; ++i) {
    auto addr = base + 4 * i;    
    auto val = cpu->r[rt].i32[i];
    sim_core_write_aligned_4(cpu, cia, write_map, addr, val);
  }
  cpu->pc += 4;
}

static void ai(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto t = sign_ext(I10, 22);
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] + t;
  cpu->pc += 4;
}

static void lqd(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto base = cpu->r[ra].i32[0] + sign_ext(I10 << 4, 18);
  for (int i = 0 ; i != 4 ; ++i) {
    auto addr = base + 4 * i;    
    auto val = sim_core_read_aligned_4(cpu, cia, write_map, addr);
    cpu->r[rt].i32[i] = val;
  }
  cpu->pc += 4;
}

static void setb_1(uint32_t* p, int n, uint8_t v)
{
  switch (n) {
  case 0:
    *p &= 0x00ffffff;
    *p |= v << 24;
    return;
  case 1:
    *p &= 0xff00ffff;
    *p |= v << 16;
    return;
  case 2:
    *p &= 0xffff00ff;
    *p |= v << 8;
    return;
  default:
    assert(n == 3);
    *p &= 0xffffff00;
    *p |= v;
    return;
  }
}
 
static void setb(uint32_t* p, int n, uint8_t v)
{
  if (n < 4)
    return setb_1(&p[0], n, v);
  if (n < 8)
    return setb_1(&p[1], n-4, v);
  if (n < 12)
    return setb_1(&p[2], n-8, v);
  assert(n < 16);
  setb_1(&p[3], n-12, v);
}

static void cbd(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I7 = (insn >> 14) & 0x7f;
  auto t = ((cpu->r[ra].i32[0] + sign_ext(I7, 25)) & 0xf);
  cpu->r[rt].i32[0] = 0x10111213;
  cpu->r[rt].i32[1] = 0x14151617;
  cpu->r[rt].i32[2] = 0x18191a1b;
  cpu->r[rt].i32[3] = 0x1c1d1e1f;
  setb(&cpu->r[rt].i32[0], t, 0x03);
  cpu->pc += 4;
}

static void cwd(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I7 = (insn >> 14) & 0x7f;
  auto t = ((cpu->r[ra].i32[0] + sign_ext(I7, 25)) & 0xc) >> 2;
  cpu->r[rt].i32[0] = 0x10111213;
  cpu->r[rt].i32[1] = 0x14151617;
  cpu->r[rt].i32[2] = 0x18191a1b;
  cpu->r[rt].i32[3] = 0x1c1d1e1f;
  cpu->r[rt].i32[t] = 0x00010203;
  cpu->pc += 4;
}

static void cdd(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I7 = (insn >> 14) & 0x7f;
  auto t = ((cpu->r[ra].i32[0] + sign_ext(I7, 25)) & 0x8) >> 3;
  cpu->r[rt].i32[0] = 0x10111213;
  cpu->r[rt].i32[1] = 0x14151617;
  cpu->r[rt].i32[2] = 0x18191a1b;
  cpu->r[rt].i32[3] = 0x1c1d1e1f;
  assert(t == 0 || t == 1);
  if (t == 0) {
    cpu->r[rt].i32[0] = 0x00010203;
    cpu->r[rt].i32[1] = 0x04050607;
  }
  else {
    cpu->r[rt].i32[2] = 0x00010203;
    cpu->r[rt].i32[3] = 0x04050607;    
  }
  cpu->pc += 4;
}

static uint8_t getb(uint32_t x, int n)
{
  switch (n) {
  case 0: return x >> 24;
  case 1: return x >> 16;
  case 2: return x >> 8;
  default: assert(n == 3); return x;
  }
}

static uint8_t getb(const uint32_t* p, int n)
{
  if (n < 4)
    return getb(p[0], n);
  if (n < 8)
    return getb(p[1], n-4);
  if (n < 12)
    return getb(p[2], n-8);
  assert(n < 16);
  return   getb(p[3], n-12);
}

static uint8_t Rconcat(sim_cpu* cpu, uint32_t ra, uint32_t rb, int n)
{
  assert(0 <= n);
  if (n < 16)
    return getb(&cpu->r[ra].i32[0], n);
  int m = n - 16;
  assert(0 <= m && m < 16);
  return getb(&cpu->r[rb].i32[0], m);
}

static void
shufb_1(sim_cpu* cpu, uint32_t rt, uint32_t ra, uint32_t rb, uint32_t rc, int j)
{
  auto b = getb(&cpu->r[rc].i32[0], j);
  if ((b & 0xc0) == 0xc0)
    return setb(&cpu->r[rt].i32[0], j, 0x00);
  if ((b & 0xe0) == 0xc0)
    return setb(&cpu->r[rt].i32[0], j, 0xff);
  if ((b & 0xe0) == 0xe0)
    return setb(&cpu->r[rt].i32[0], j, 0x80);
  b &= 0x1f;
  setb(&cpu->r[rt].i32[0], j, Rconcat(cpu, ra, rb, b));
}

static void shufb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rc =  insn        & 0x7f;
  auto ra = (insn >> 7)  & 0x7f;
  auto rb = (insn >> 14) & 0x7f;
  auto rt = (insn >> 21) & 0x7f;
  for (int j = 0 ; j != 16 ; ++j)
    shufb_1(cpu, rt, ra, rb, rc, j);
  cpu->pc += 4;
}

static void ori(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt =  insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto t = sign_ext(I10, 22);
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] | t;
  cpu->pc += 4;
}

static void a(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (((insn >> 21) & 7) != 0)
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  auto rt =  insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto rb = (insn >> 14) & 0x7f;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] + cpu->r[rb].i32[i];
  cpu->pc += 4;
}

static void ila(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt =  insn & 0x7f;
  auto I18 = (insn >> 7) & 0x3ffff;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = I18;
  cpu->pc += 4;  
}

static void bi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto ra = (insn >> 7) & 0x7f;
  cpu->pc = cpu->r[ra].i32[0] & ~3;
}

static void hbrp(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rol = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto roh = (insn >> 14) & 0x3;
  auto P = (insn >> 20) & 1;
  (void)roh; (void)rol; (void)P;
#if 0  
  cpu->pc = cpu->r[ra].i32[0] & ~3;
#else
  (void)ra;
  cpu->pc += 4;
#endif  
}

static void
op0x35(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto n = (insn >> 21) & 7;
  switch (n) {
  case 0: return bi(sd, cpu, insn ,cia);
  case 4: return hbrp(sd, cpu, insn ,cia);
  default:
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }
}

static void lnop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc += 4;  
}

static void
op0x00(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  if (((insn >> 21) & 0xf) == 1)
    return lnop(sd, cpu, insn, cia);
  sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
}

static void lqr(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  auto base = (cpu->pc + (I16 << 2)) & ~15;
  for (int i = 0 ; i != 4 ; ++i) {
    auto addr = base + 4 * i;
    auto val = sim_core_read_aligned_4(cpu, cia, read_map, addr);
    cpu->r[rt].i32[i] = val;
  }
  cpu->pc += 4;  
}

static void
op0x33(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto fn = (insn & (1 << 23)) ? lqr : brsl;
  fn(sd, cpu, insn, cia);
}

static void
op0x3e(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto n = (insn >> 21) & 7;
  switch (n) {
  case 4: return cbd(sd, cpu, insn, cia);
  case 6: return cwd(sd, cpu, insn, cia);
  case 7: return cdd(sd, cpu, insn, cia);
  default:
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);    
  }
}

static void fsmbi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  for (int j = 0 ; j != 16 ; ++j) {
    auto v = (I16 & (1 << (15 - j))) ? 0xff : 0x00;
    setb(&cpu->r[rt].i32[0], j, v);
  }
  cpu->pc += 4;  
}

static void andbi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto b = I10 & 0xff;
  auto bbbb = (b << 24) | (b << 16) | (b << 8) | b;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] & bbbb;
  cpu->pc += 4;  
}

static void andhi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto I10 = (insn >> 14) & 0x3ff;
  auto bbbb = (I10 << 16) | I10;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] & bbbb;
  cpu->pc += 4;  
}

static void ilhu(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = I16 << 16;
  cpu->pc += 4;
}

static void or_(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt =  insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto rb = (insn >> 14) & 0x7f;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = cpu->r[ra].i32[i] | cpu->r[rb].i32[i] ;
  cpu->pc += 4;
}

static void ceq(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt =  insn & 0x7f;
  auto ra = (insn >> 7) & 0x7f;
  auto rb = (insn >> 14) & 0x7f;
  for (int i = 0 ; i != 4 ; ++i)
    cpu->r[rt].i32[i] = (cpu->r[ra].i32[i] == cpu->r[rb].i32[i]) ? -1 : 0;
  cpu->pc += 4;
}

static void brnz(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto rt = insn & 0x7f;
  auto I16 =  int16_t((insn >> 7) & 0xffff);  
  if (cpu->r[rt].i32[0])
    cpu->pc += I16 << 2;
  else
    cpu->pc += 4;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x40] = op0x40;
    (*this)[0x33] = op0x33;
    (*this)[0x24] = stqd;
    (*this)[0x1c] = ai;
    (*this)[0x34] = lqd;
    (*this)[0x3e] = op0x3e;
    (*this)[0x04] = ori;
    (*this)[0x18] = a;
    (*this)[0x35] = op0x35;
    (*this)[0x00] = op0x00;
    (*this)[0x32] = fsmbi;
    (*this)[0x16] = andbi;
    (*this)[0x41] = ilhu;
    (*this)[0x08] = or_;
    (*this)[0x15] = andhi;
    (*this)[0x23] = stqr;
    (*this)[0x78] = ceq;
    (*this)[0x21] = brnz;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  if ((insn >> 28) == 0xb)
    return shufb(sd, cpu, insn, cia);
  if ((insn >> 25) == 0x21)
    return ila(sd, cpu, insn, cia);

  auto p = table.find(insn >> 24);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
