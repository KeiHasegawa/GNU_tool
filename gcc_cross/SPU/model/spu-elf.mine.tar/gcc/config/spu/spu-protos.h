#ifndef SPU_PROTOS_H
#define SPU_PROTOS_H

namespace spu {
  void expand_prologue();
  void expand_epilogue();
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  namespace v4si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace v4si
} // end of namespace spu

#endif //  SPU_PROTOS_H
