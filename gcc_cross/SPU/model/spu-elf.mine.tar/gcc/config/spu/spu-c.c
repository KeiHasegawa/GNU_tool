#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "target.h"
#include "c-family/c-common.h"
#include "stringpool.h"
#include "langhooks.h"

static tree __vector_keyword;

static cpp_hashnode* spu_categorize_keyword(const cpp_token *tok)
{
  if (tok->type != CPP_NAME)
    return nullptr;
  cpp_hashnode* ident = tok->val.node.node;
  if (ident == C_CPP_HASHNODE(__vector_keyword))
    return C_CPP_HASHNODE(__vector_keyword);
  return ident;
}

inline rid
get_rid(cpp_reader* pfile, cpp_hashnode* ident, const cpp_token** tok)
{
  if (!cpp_macro_p(ident))
    return rid(ident->rid_code);
  cpp_get_token(pfile);
  *tok = cpp_peek_token(pfile, 0);
  cpp_hashnode* next = spu_categorize_keyword(*tok);
  if (!next)
    return rid(ident->rid_code);
  return rid(next->rid_code);
}

static cpp_hashnode*
spu_macro_to_expand(cpp_reader* pfile, const cpp_token* tok)
{
  cpp_hashnode* ident = spu_categorize_keyword(tok);
  if (ident != C_CPP_HASHNODE(__vector_keyword))
    return tok->val.node.node;
  
  tok = cpp_peek_token(pfile, 0);
  ident = spu_categorize_keyword(tok);
  if (!ident)
    return tok->val.node.node;
  
  auto rid_code = get_rid(pfile, ident, &tok);
  switch (rid_code) {
  case RID_SHORT: case RID_LONG: case RID_SIGNED: case RID_UNSIGNED:
  case RID_INT: case RID_CHAR: case RID_FLOAT: case RID_DOUBLE:
    return C_CPP_HASHNODE(__vector_keyword);
  default:
    return tok->val.node.node;    
  }
}

void spu_cpu_cpp_builtins(cpp_reader* pfile)
{
  cpp_define(pfile, "__SPU__");
  cpp_define(pfile, "__vector=__attribute__((__spu_vector__))");
  __vector_keyword = get_identifier("__vector");
  C_CPP_HASHNODE(__vector_keyword)->flags |= NODE_CONDITIONAL;
  cpp_get_callbacks(pfile)->macro_to_expand = spu_macro_to_expand;
}

tree
spu_resolve_overloaded_builtin (location_t loc, tree fndecl, void *passed_args)
{
#if 0  
#define SCALAR_TYPE_P(t) (INTEGRAL_TYPE_P (t) \
			  || SCALAR_FLOAT_TYPE_P (t) \
			  || POINTER_TYPE_P (t))
  vec<tree, va_gc> *fnargs = static_cast <vec<tree, va_gc> *> (passed_args);
  unsigned int nargs = vec_safe_length (fnargs);
  int new_fcode, fcode = DECL_FUNCTION_CODE (fndecl);
  struct spu_builtin_description *desc;
  tree match = NULL_TREE;

  /* The vector types are not available if the backend is not initialized.  */
  gcc_assert (!flag_preprocess_only);

  desc = &spu_builtins[fcode];
  if (desc->type != B_OVERLOAD)
    return NULL_TREE;

  /* Compare the signature of each internal builtin function with the
     function arguments until a match is found. */

  for (new_fcode = fcode + 1; spu_builtins[new_fcode].type == B_INTERNAL;
       new_fcode++)
    {
      tree decl = targetm.builtin_decl (new_fcode, true);
      tree params = TYPE_ARG_TYPES (TREE_TYPE (decl));
      tree param;
      bool all_scalar;
      unsigned int p;

      /* Check whether all parameters are scalar.  */
      all_scalar = true;
      for (param = params; param != void_list_node; param = TREE_CHAIN (param))
      if (!SCALAR_TYPE_P (TREE_VALUE (param)))
	all_scalar = false;

      for (param = params, p = 0;
	   param != void_list_node;
	   param = TREE_CHAIN (param), p++)
	{
	  tree var, arg_type, param_type = TREE_VALUE (param);

	  if (p >= nargs)
	    {
	      error ("insufficient arguments to overloaded function %s",
		     desc->name);
	      return error_mark_node;
	    }

	  var = (*fnargs)[p];

	  if (TREE_CODE (var) == NON_LVALUE_EXPR)
	    var = TREE_OPERAND (var, 0);

	  if (TREE_CODE (var) == ERROR_MARK)
	    return NULL_TREE;	/* Let somebody else deal with the problem. */

	  arg_type = TREE_TYPE (var);

	  /* The intrinsics spec does not specify precisely how to
	     resolve generic intrinsics.  We require an exact match
	     for vector types and let C do it's usual parameter type
	     checking/promotions for scalar arguments, except for the
	     first argument of intrinsics which don't have a vector
	     parameter. */
	  if ((!SCALAR_TYPE_P (param_type)
	       || !SCALAR_TYPE_P (arg_type)
	       || (all_scalar && p == 0))
	      && !lang_hooks.types_compatible_p (param_type, arg_type))
	    break;
	}
      if (param == void_list_node)
	{
	  if (p != nargs)
	    {
	      error ("too many arguments to overloaded function %s",
		     desc->name);
	      return error_mark_node;
	    }

	  match = decl;
	  break;
	}
    }

  if (match == NULL_TREE)
    {
      error ("parameter list does not match a valid signature for %s()",
	     desc->name);
      return error_mark_node;
    }

  return build_function_call_vec (loc, vNULL, match, fnargs, NULL);
#undef SCALAR_TYPE_P
#else
  (void)loc; (void)fndecl; (void)passed_args;
  asm("int3");
  return nullptr;
#endif  
}
