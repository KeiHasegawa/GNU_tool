#ifndef RISCV_PROTOS_H
#define RISCV_PROTOS_H

namespace riscv {
  void expand_prologue();
  void expand_epilogue();
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
} // end of namespace riscv

#endif //  RISCV_PROTOS_H
