#ifndef MN10300_PROTOS_H
#define MN10300_PROTOS_H

void mn10300_expand_prologue();
void mn10300_expand_epilogue();

const char* mn10300_movsi(rtx x, rtx y);
const char* mn10300_addsi3(rtx x, rtx y, rtx z);
const char* mn10300_subsi3(rtx x, rtx y, rtx z);
const char* mn10300_call_value(rtx x, rtx fun);

const char* mn10300_cbranch(rtx op);

#endif //  MN10300_PROTOS_H
