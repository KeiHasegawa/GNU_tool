/* Do not modify this file.  */
/* It is created automatically by the Makefile.  */
#include "libiberty.h"
#include "sim-module.h"
extern MODULE_INIT_FN sim_install_dv_sockser;
extern MODULE_INIT_FN sim_install_engine;
extern MODULE_INIT_FN sim_install_hw;
extern MODULE_INIT_FN sim_install_profile;
extern MODULE_INIT_FN sim_install_trace;
MODULE_INSTALL_FN * const sim_modules_detected[] = {
#if 0  
  sim_install_dv_sockser,
#endif  
  sim_install_engine,
#if 0  
  sim_install_hw,
#endif  
  sim_install_profile,
  sim_install_trace,
};
const int sim_modules_detected_len = ARRAY_SIZE (sim_modules_detected);
