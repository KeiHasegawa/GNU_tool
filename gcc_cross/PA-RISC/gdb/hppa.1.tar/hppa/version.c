#include "version.h"
const char version[] = "12.1";
const char host_name[] = "i686-pc-linux-gnu";
const char target_name[] = "hppa-elf";
