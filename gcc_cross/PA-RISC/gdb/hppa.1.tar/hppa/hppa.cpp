#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia hppa_pc_get(sim_cpu* cpu)
{
  return cpu->pcoq_head;
}

extern "C" void hppa_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pcoq_head = pc;
}

extern "C" uint32_t hppa_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 33)
    return cpu->pcoq_head;
  if (rn == 41)
    return cpu->ipsw;
  return 0;
}

extern "C"
int hppa_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u = { hppa_reg_get_1(cpu, rn) };
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void hppa_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 35) {
    cpu->pcoq_tail = v;
    return;
  }
  asm("int3");
}

extern "C"
int hppa_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (*(char*)&n) {
    // simulator runs at little endian processor
    std::swap(u.c[0], u.c[3]);
    std::swap(u.c[1], u.c[2]);
  }

  hppa_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void nop(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pcoq_head += 4;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x08] = nop;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  uint8_t key = insn >> 24;
  auto p = table.find(key);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
