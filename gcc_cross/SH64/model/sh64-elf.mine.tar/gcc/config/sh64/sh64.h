#ifndef SH64_H
#define SH64_H

#define REGISTER_NAMES      { \
    "r0",   "r1",   "r2",  "r3",    "r4",  "r5",  "r6",  "r7",   \
    "r8",   "r9",   "r10", "r11",   "r12", "r13", "r14", "r15",  \
    "r16",  "r17",  "r18", "r19",   "r20", "r21", "r22", "r23",  \
    "r24",  "r25",  "r26", "r27",   "r28", "r29", "r30", "r31",  \
    "r32",  "r33",  "r34", "r35",   "r36", "r37", "r38", "r39",  \
    "r40",  "r41",  "r42", "r43",   "r44", "r45", "r46", "r47",  \
    "r48",  "r49",  "r50", "r51",   "r52", "r53", "r54", "r55",  \
    "r56",  "r57",  "r58", "r59",   "r60", "r61", "r62", "r63",  \
    "pc",   "sr",   "ssr",  "spc",  "tr0",   "tr1",  "tr2",  "tr3",  \
    "tr4",  "tr5",  "tr6",  "tr7",  "fpcsr", "fr0",  "fr1",  "fr2",  \
    "fr3",  "fr4",  "fr5",  "fr7",  "fr8",   "fr9",  "fr10", "fr11", \
    "fr12", "fr13", "fr14", "fr15", "fr16",  "fr17", "fr18", "fr19", \
    "fr20", "fr21", "fr22", "fr23", "fr24",  "fr25", "fr26", "fr27", \
    "fr28", "fr29", "fr30", "fr31", "fr32",  "fr33", "fr34", "fr35", \
    "fr36", "fr37", "fr38", "fr39", "fr40",  "fr41", "fr42", "fr43", \
    "fr44", "fr45", "fr46", "fr47", "fr48",  "fr49", "fr50", "fr51", \
    "fr52", "fr53", "fr54", "fr55", "fr56",  "fr57", "fr58", "fr59", \
    "fr60", "fr61", "fr62", "fr63", "ap" }

#define FRAME_POINTER_REGNUM  14
#define STACK_POINTER_REGNUM  15
#define PR_REGNUM             17
#define FR0_REGNUM            77
#define ARG_POINTER_REGNUM    140
#define FIRST_PSEUDO_REGISTER 141

#define FIXED_REGISTERS  { \
      0,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1  }

#define CALL_USED_REGISTERS  { \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1,     1,     1,     1,    \
      1,     1,     1,     1,     1  }


enum reg_class {
  NO_REGS, SPECIAL_REGS, FLOAT_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};
  
#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS", "FLOAT_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */     {{ 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x0000 }, \
/* SPECIAL_REGS */ { 0x0002c000, 0x00000000, 0x00001fff, 0xffffe000, 0x3fff }, \
/* FLOAT_REGS */   { 0x00000000, 0x00000000, 0xffffe000, 0x00001fff, 0x0000 }, \
/* GENERAL_REGS */ { 0xfffd2fff, 0xffffffff, 0x00000000, 0x00000000, 0x0000 }, \
/* ALL_REGS */     { 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0x3fff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 8
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           32
#define LONG_TYPE_SIZE		32
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

struct cumulative_args {
  int gpr;
  int fpr;
};

typedef struct cumulative_args CUMULATIVE_ARGS;

void sh64_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  sh64_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 8

#define STRICT_ALIGNMENT 0

#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 1
#define WORDS_BIG_ENDIAN 1

#define FUNCTION_BOUNDARY 8

#define TRAMPOLINE_SIZE   8

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("sh64")

#define BIGGEST_ALIGNMENT 64

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode DImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS				\
{{ ARG_POINTER_REGNUM, STACK_POINTER_REGNUM},	\
 { ARG_POINTER_REGNUM, FRAME_POINTER_REGNUM},	\
 { FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}}	\

extern int sh64_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)	\
  (OFFSET) = sh64_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 64

#define PARM_BOUNDARY  64

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.section\t.bss"

#define STACK_GROWS_DOWNWARD 1

extern rtx sh64_incoming_return_addr_rtx();
#define INCOMING_RETURN_ADDR_RTX sh64_incoming_return_addr_rtx()

#endif // SH64_H
