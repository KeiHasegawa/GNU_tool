#ifndef SH64_PROTOS_H
#define SH64_PROTOS_H

namespace sh64 {
  void expand_prologue();
  void expand_epilogue();
  namespace qi {
    const char* mov(rtx x, rtx y);
  } // end of namespace qi
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
  } // end of namespace si
  namespace di {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace di
  namespace sf {
    const char* mov(rtx x, rtx y);
  } // end of namespace sf
  namespace df {
    const char* mov(rtx x, rtx y);
  } // end of namespace df
  const char* cbranch(rtx op);
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  const char* do_return();
} // end of namespace sh64

#endif //  SH64_PROTOS_H
