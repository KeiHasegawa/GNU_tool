#ifndef VAX_H
#define VAX_H

#define REGISTER_NAMES  \
  { "%r0", "%r1", "%r2",  "%r3",  "%r4", "%r5", "%r6",  "%r7", \
    "%r8", "%r9", "%r10", "%r11", "%ap", "%fp", "%sp",  "dummy" }

#define ARG_POINTER_REGNUM      12
#define FRAME_POINTER_REGNUM	13
#define STACK_POINTER_REGNUM	14
#define DUMMY_REGNUM		15
#define FIRST_PSEUDO_REGISTER	16

#define FIXED_REGISTERS  \
  {    0,     1,     1,      1,     1,      1,     1,      1,  \
       1,     1,     1,      1,     1,      1,     1,      1  }

#define CALL_USED_REGISTERS  \
  {    1,     1,     1,      1,     1,      1,     1,      1,  \
       1,     1,     1,      1,     1,      1,     1,      1  }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SP_REGS", "FP_REGS", "A_REGS", "B_REGS", "PC_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000 }, \
/* SPECIAL_REGS */	 { 0x0000e000 }, \
/* GENERAL_REGS */	 { 0x00001fff }, \
/* ALL_REGS */           { 0x0000ffff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 4

typedef int CUMULATIVE_ARGS;
extern void vax_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  vax_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 4

#define STRICT_ALIGNMENT 0

#define BITS_BIG_ENDIAN 0
#define BYTES_BIG_ENDIAN 1
#define WORDS_BIG_ENDIAN 1

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("vax")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode SImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

extern int vax_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)	\
  (OFFSET) = vax_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY 8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1
#define FRAME_GROWS_DOWNWARD 1

#define PUSH_ROUNDING(X)	(X)

extern rtx vax_incoming_return_addr_rtx();
#define INCOMING_RETURN_ADDR_RTX vax_incoming_return_addr_rtx()

#endif // VAX_H
