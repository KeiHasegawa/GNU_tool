#ifndef VAX_PROTOS_H
#define VAX_PROTOS_H

namespace vax {
  void expand_prologue();
  void expand_epilogue();
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  const char* call_value(rtx x, rtx fun, rtx narg);
  const char* cbranch(rtx op);  
} // end of namespace vax

#endif //  VAX_PROTOS_H
