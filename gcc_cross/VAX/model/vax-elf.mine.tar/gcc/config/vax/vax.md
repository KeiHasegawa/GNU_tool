(include "constraints.md")
(include "predicates.md")

(define_insn "movsi"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
	(match_operand:SI 1 "general_operand" ""))]
  ""
  "*
  return vax::si::mov(operands[0], operands[1]);")

(define_mode_iterator ALLI [BLK BI QI HI DI TI SF DF])

(define_insn "mov<mode>"
  [(set (match_operand:ALLI 0 "nonimmediate_operand" "")
	(match_operand:ALLI 1 "general_operand" ""))]
  ""
  "%0 := %1")

(define_insn "jump"
  [(set (pc) (label_ref (match_operand 0 "" "")))]
  "1"
  "goto %l0")

(define_expand "prologue"
  [(clobber (const_int 0))]
  ""
  "vax::expand_prologue(); DONE;")

(define_expand "epilogue"
  [(clobber (const_int 0))]
  ""
  "vax::expand_epilogue(); DONE;")

(define_insn "do_return"
  [(return)]
  ""
  "ret")

(define_insn "addsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (plus:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "*
  return vax::si::add(operands[0], operands[1], operands[2]);")

(define_insn "adddi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (plus:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 + %2")

(define_insn "addsf3"
  [(set
    (match_operand:SF 0 "nonimmediate_operand" "")
    (plus:SF
     (match_operand:SF 1 "general_operand" "")
     (match_operand:SF 2 "general_operand" "")))]
  ""
  "%0 := %1 + %2")

(define_insn "adddf3"
  [(set
    (match_operand:DF 0 "nonimmediate_operand" "")
    (plus:DF
     (match_operand:DF 1 "general_operand" "")
     (match_operand:DF 2 "general_operand" "")))]
  ""
  "%0 := %1 + %2")

(define_insn "subsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (minus:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "*
  return vax::si::sub(operands[0], operands[1], operands[2]);")

(define_insn "subdi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (minus:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 - %2")

(define_insn "subsf3"
  [(set
    (match_operand:SF 0 "nonimmediate_operand" "")
    (minus:SF
     (match_operand:SF 1 "general_operand" "")
     (match_operand:SF 2 "general_operand" "")))]
  ""
  "%0 := %1 - %2")

(define_insn "subdf3"
  [(set
    (match_operand:DF 0 "nonimmediate_operand" "")
    (minus:DF
     (match_operand:DF 1 "general_operand" "")
     (match_operand:DF 2 "general_operand" "")))]
  ""
  "%0 := %1 - %2")

(define_insn "mulsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (mult:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 * %2")

(define_insn "muldi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (mult:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 * %2")

(define_insn "mulsf3"
  [(set
    (match_operand:SF 0 "nonimmediate_operand" "")
    (mult:SF
     (match_operand:SF 1 "general_operand" "")
     (match_operand:SF 2 "general_operand" "")))]
  ""
  "%0 := %1 * %2")

(define_insn "muldf3"
  [(set
    (match_operand:DF 0 "nonimmediate_operand" "")
    (mult:DF
     (match_operand:DF 1 "general_operand" "")
     (match_operand:DF 2 "general_operand" "")))]
  ""
  "%0 := %1 * %2")

(define_insn "divsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (div:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "udivsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (udiv:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "divdi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (div:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "udivdi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (udiv:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "divsf3"
  [(set
    (match_operand:SF 0 "nonimmediate_operand" "")
    (div:SF
     (match_operand:SF 1 "general_operand" "")
     (match_operand:SF 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "divdf3"
  [(set
    (match_operand:DF 0 "nonimmediate_operand" "")
    (div:DF
     (match_operand:DF 1 "general_operand" "")
     (match_operand:DF 2 "general_operand" "")))]
  ""
  "%0 := %1 / %2")

(define_insn "modsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (mod:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 %% %2")

(define_insn "moddi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (mod:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 %% %2")

(define_insn "ashlsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (ashift:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 << %2")

(define_insn "ashldi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (ashift:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 << %2")

(define_insn "ashrsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (ashiftrt:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 >> %2")

(define_insn "ashrdi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (ashiftrt:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 >> %2")

(define_insn "andsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (and:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 & %2")

(define_insn "anddi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (and:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 & %2")

(define_insn "xorsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (xor:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 ^ %2")

(define_insn "xordi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (xor:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 ^ %2")

(define_insn "iorsi3"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (ior:SI
     (match_operand:SI 1 "general_operand" "")
     (match_operand:SI 2 "general_operand" "")))]
  ""
  "%0 := %1 | %2")

(define_insn "iordi3"
  [(set
    (match_operand:DI 0 "nonimmediate_operand" "")
    (ior:DI
     (match_operand:DI 1 "general_operand" "")
     (match_operand:DI 2 "general_operand" "")))]
  ""
  "%0 := %1 | %2")

; not absolutely necessary
; If not, compiler generates %0 := 0 - %1
(define_insn "negsi2"
  [(set
    (match_operand:SI 0 "nonimmediate_operand" "")
    (neg:SI
     (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := -%1")

(define_insn "negsf2"
  [(set
    (match_operand:SF 0 "nonimmediate_operand" "")
    (neg:SF
     (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := -%1")

(define_insn "negdf2"
  [(set
    (match_operand:DF 0 "nonimmediate_operand" "")
    (neg:DF
     (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := -%1")

; not absolutely necessary
; If not, compiler generates %0 := 0xffffffff ^ %1
(define_insn "one_cmplsi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
	(not:SI (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := ~%1")

(define_insn "one_cmpldi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
	(not:DI (match_operand:DI 1 "general_operand" "")))]
  ""
  "%0 := ~%1")

(define_insn "call"
  [(call (match_operand:QI 0 "indirect_operand" "")
	 (match_operand:SI 1 "general_operand" ""))]
  ""
  "call %0")

(define_insn "call_value"
  [(set (match_operand 0 "" "")
	(call (match_operand:QI 1 "indirect_operand" "")
	      (match_operand:SI 2 "general_operand" "")))]
  ""
  "*
  return vax::call_value(operands[0], operands[1], operands[2]);")

(define_insn "nop"
  [(const_int 0)]
  ""
  "nop")

(define_insn "cbranchsi4"
  [(set (pc) (if_then_else
	      (match_operator 0 "ordered_comparison_operator"
	       [(match_operand:SI 1 "general_operand")
	        (match_operand:SI 2 "general_operand")])
	      (label_ref (match_operand 3 "" ""))
	      (pc)))]
  ""
  "*
  return vax::cbranch(operands[0]);")

(define_insn "cbranchdi4"
  [(set (pc) (if_then_else
	      (match_operator 0 "ordered_comparison_operator"
	       [(match_operand:DI 1 "general_operand")
	        (match_operand:DI 2 "general_operand")])
	      (label_ref (match_operand 3 "" ""))
	      (pc)))]
  ""
  "*
  return vax::cbranch(operands[0]);")

(define_insn "cbranchsf4"
  [(set (pc) (if_then_else
	      (match_operator 0 "ordered_comparison_operator"
	       [(match_operand:SF 1 "general_operand")
	        (match_operand:SF 2 "general_operand")])
	      (label_ref (match_operand 3 "" ""))
	      (pc)))]
  ""
  "*
  return vax::cbranch(operands[0]);")

(define_insn "cbranchdf4"
  [(set (pc) (if_then_else
	      (match_operator 0 "ordered_comparison_operator"
	       [(match_operand:DF 1 "general_operand")
	        (match_operand:DF 2 "general_operand")])
	      (label_ref (match_operand 3 "" ""))
	      (pc)))]
  ""
  "*
  return vax::cbranch(operands[0]);")

; int16 <- int8
; not absolutely necessary
; If not, compiler generates like below:
; 
; t := y
; t := t << 8
; t := t << 16
; t := t >> 16
; t := t >> 8
; t := x
;
(define_insn "extendqihi2"
  [(set (match_operand:HI 0 "nonimmediate_operand")
        (sign_extend:HI (match_operand:QI 1 "general_operand")))]
  ""
  "%0 := (sign)%1")

; int32 <- int8
; not absolutely necessary
; If not, compiler generates like below:
;
; t := y
; t := t << 24
; t := t >> 24
; x := t
;
(define_insn "extendqisi2"
  [(set (match_operand:SI 0 "nonimmediate_operand")
        (sign_extend:SI (match_operand:QI 1 "general_operand")))]
  ""
  "%0 := (sign)%1")

; int64 <- int8
; not absolutely necessary
(define_insn "extendqidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (sign_extend:DI (match_operand:QI 1 "general_operand" "")))]
  ""
  "%0 := (sign)%1")

; int16 <- uint8
; not absolutely necessary
(define_insn "zero_extendqihi2"
  [(set (match_operand:HI 0 "nonimmediate_operand")
        (zero_extend:HI (match_operand:QI 1 "general_operand")))]
  ""
  "%0 := (zero)%1")

; int32 <- uint8
(define_insn "zero_extendqisi2"
  [(set (match_operand:SI 0 "nonimmediate_operand")
        (zero_extend:SI (match_operand:QI 1 "general_operand")))]
  ""
  "%0 := (zero)%1")

; int64 <- uint8
(define_insn "zero_extendqidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand")
        (zero_extend:DI (match_operand:QI 1 "general_operand")))]
  ""
  "%0 := (zero)%1")

; int8 <- int16
; not absolutely necessary
(define_insn "trunchiqi2"
  [(set (match_operand:QI 0 "nonimmediate_operand" "")
        (truncate:QI (match_operand:HI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; int32 <- int16
; not absolutely necessary
(define_insn "extendhisi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (sign_extend:SI (match_operand:HI 1 "general_operand" "")))]
  ""
  "%0 := (sign)%1")

; int64 <- int16
; not absolutely necessary
(define_insn "extendhidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (sign_extend:DI (match_operand:HI 1 "general_operand" "")))]
  ""
  "%0 := (sign)%1")

; int32 <- uint16
; not absolutely necessary
(define_insn "zero_extendhisi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (zero_extend:SI (match_operand:HI 1 "general_operand" "")))]
  ""
  "%0 := (zero)%1")

; int64 <- uint16
; not absolutely necessary
(define_insn "zero_extendhidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (zero_extend:DI (match_operand:HI 1 "general_operand" "")))]
  ""
  "%0 := (zero)%1")

; int8 <- int32
; not absolutely necessary
(define_insn "truncsiqi2"
  [(set (match_operand:QI 0 "nonimmediate_operand" "")
        (truncate:QI (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; int16 <- int32
; not absolutely necessary
(define_insn "truncsihi2"
  [(set (match_operand:HI 0 "nonimmediate_operand" "")
        (truncate:HI (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; int64 <- int32
; not absolutely necessary
(define_insn "extendsidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (sign_extend:DI (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := (sign)%1")

; int64 <- uint32
; not absolutely necessary
(define_insn "zero_extendsidi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (zero_extend:DI (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := (zero)%1")

; int8 <- int64
; not absolutely necessary
(define_insn "truncdiqi2"
  [(set (match_operand:QI 0 "nonimmediate_operand" "")
        (truncate:QI (match_operand:DI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; int16 <- int64
; not absolutely necessary
(define_insn "truncdihi2"
  [(set (match_operand:HI 0 "nonimmediate_operand" "")
        (truncate:HI (match_operand:DI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; int32 <- int64
; not absolutely necessary
(define_insn "truncdisi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (truncate:SI (match_operand:DI 1 "general_operand" "")))]
  ""
  "%0 := (trunc)%1")

; float <- int8, uint8  or float <- int16, uint16
; not absolutely necessary
; If not, compiler generates like below:
;
; t := (sign)y  or (zero)y
; x := (float)t 

; float <- int32, uint32
(define_insn "floatsisf2"
  [(set (match_operand:SF 0 "nonimmediate_operand" "")
        (float:SF (match_operand:SI 1 "general_operand" "")))]
  ""
  "%0 := (float)%1")

; float <- int64, uint64
(define_insn "floatdisf2"
  [(set (match_operand:SF 0 "nonimmediate_operand" "")
        (float:SF (match_operand:DI 1 "general_operand" "")))]
  ""
  "%0 := (float)%1")

; int8 <- float, uint8 <- float, int16 <- float, uint16 <- float
; not absolutely necessary
; If not, compiler generates like below:
;
; t := (int32)y
; x := (trunc)t

; int32 <- float
(define_insn "fix_truncsfsi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (fix:SI (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := (int32)%1")

; uint32 <- float
; not abusolutely necessary
(define_insn "fixuns_truncsfsi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (unsigned_fix:SI (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := (uint32)%1")
  
; int64 <- float
(define_insn "fix_truncsfdi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (fix:DI (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := (int64)%1")

; uint64 <- float
; not abusolutely necessary
(define_insn "fixuns_truncsfdi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (unsigned_fix:DI (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := (uint64)%1")

; double <- float
(define_insn "extendsfdf2"
  [(set (match_operand:DF 0 "nonimmediate_operand" "")
        (float_extend:DF (match_operand:SF 1 "general_operand" "")))]
  ""
  "%0 := (double)%1")

; int32 <- double
(define_insn "fix_truncdfsi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (fix:SI (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := (int32)%1")

; uint32 <- double
; not abusolutely necessary
(define_insn "fixuns_truncdfsi2"
  [(set (match_operand:SI 0 "nonimmediate_operand" "")
        (unsigned_fix:SI (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := (uint32)%1")

; int64 <- double
(define_insn "fix_truncdfdi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (fix:DI (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := (int64)%1")

; uint64 <- double
; not abusolutely necessary
(define_insn "fixuns_truncdfdi2"
  [(set (match_operand:DI 0 "nonimmediate_operand" "")
        (unsigned_fix:DI (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := (uint64)%1")

; float <- double
(define_insn "truncdfsf2"
  [(set (match_operand:SF 0 "nonimmediate_operand" "")
        (float_truncate:SF (match_operand:DF 1 "general_operand" "")))]
  ""
  "%0 := (float)%1")
