#ifndef SIM_MAIN_H
#define SIM_MAIN_H

#include "sim-basics.h"

#include "sim-base.h"

struct _sim_cpu {
  sim_cpu_base base;
};

typedef struct _sim_cpu sim_cpu;

struct sim_state {
  sim_cpu* cpu[MAX_NR_PROCESSORS];
  sim_state_base base;
};

typedef uint8_t instruction_word;

instruction_word vax_fetch(SIM_DESC sd, sim_cia cia);

#define IMEM32(CIA) vax_fetch(sd, CIA)

sim_cia idecode_issue(SIM_DESC sd, instruction_word insn, sim_cia cia);
  
#endif // SIM_MAIN_H
