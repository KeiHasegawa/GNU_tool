(define_register_constraint "d" "D_REGS" "@internal")
