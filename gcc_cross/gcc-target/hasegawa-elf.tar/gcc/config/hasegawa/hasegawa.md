(include "predicates.md")
(include "constraints.md")

(define_insn "bitcmphi"
  [(set (cc0)
	(compare (and:HI (match_operand:HI 0 "tst_operand" "d")
		         (match_operand:HI 1 "const_int_operand" "i"))
		 (const_int 0)))]
  "(INTVAL (operands[1]) & 0x0ff) == 0
   || (INTVAL (operands[1]) & 0x0ff00) == 0"
  "*
{
  return nullptr;
}")
