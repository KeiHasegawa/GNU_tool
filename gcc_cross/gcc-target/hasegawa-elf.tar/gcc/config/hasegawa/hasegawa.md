(define_expand "movsi"
  [(set (match_operand:SI 0 "general_operand")
        (match_operand:SI 1 "general_operand"))]
  ""
  "
  emit_insn(gen_rtx_SET(operands[0], operands[1]));
  DONE;
  "
)

(define_insn "jump"
   [(set (pc) (label_ref (match_operand 0 "" "")))]
   "1"
   "jump	%l0")
