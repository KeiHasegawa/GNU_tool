#ifndef HASEGAWA_H
#define HASEGAWA_H

// This constant matches to the number of initializer defined by:
// `FIXED_REGISTERS'
// `REGISTER_NAMES'
constexpr int FIRST_PSEUDO_REGISTER = 9;

constexpr int N_REG_CLASSES = 2;

enum reg_class { NO_REGS, D_REGS, GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES };

constexpr int UNITS_PER_WORD = 4;
constexpr int BITS_PER_WORD = 32;

struct CUMULATIVE_ARGS {};

constexpr int MOVE_MAX = 2;

constexpr bool STRICT_ALIGNMENT = true;

constexpr bool BYTES_BIG_ENDIAN = true;

constexpr int FUNCTION_BOUNDARY = 4;

constexpr int TRAMPOLINE_SIZE = 4;

constexpr int STACK_POINTER_REGNUM = 2;

inline void TARGET_CPU_CPP_BUILTINS()
{
}

constexpr bool WORDS_BIG_ENDIAN = true;

constexpr int BIGGEST_ALIGNMENT = 8;

constexpr int ATTRIBUTE_ALIGNED_VALUE = 16;

constexpr scalar_int_mode Pmode = HImode;

constexpr int MAX_REGS_PER_ADDRESS = 2;

constexpr int FRAME_POINTER_REGNUM = 3;

constexpr int ARG_POINTER_REGNUM = 4;

inline bool FUNCTION_ARG_REGNO_P(int regno)
{
  return regno == 3;
}

#define ELIMINABLE_REGS { {1, 2} }

constexpr int STACK_BOUNDARY = 8;

constexpr int PARM_BOUNDARY = 8;

constexpr scalar_int_mode FUNCTION_MODE = QImode;

constexpr reg_class BASE_REG_CLASS = D_REGS;

inline bool REGNO_OK_FOR_BASE_P(int regno)
{
  return regno == 3;
}

inline reg_class REGNO_REG_CLASS(int regno)
{
  (void)regno;
  return D_REGS;
}

inline void INIT_CUMULATIVE_ARGS(const CUMULATIVE_ARGS&, tree, rtx, tree, int)
{
}

inline rtx gen_nop()
{
  return nullptr;
}

constexpr bool BITS_BIG_ENDIAN = true;

constexpr bool SLOW_BYTE_ACCESS = false;

inline void ASM_OUTPUT_ALIGN(FILE*, int)
{
}

inline int FIRST_PARM_OFFSET(tree)
{
  return 0;
}

constexpr scalar_int_mode CASE_VECTOR_MODE = Pmode;

constexpr const char* ASM_APP_ON = "; Begin inline assembler code\n#APP\n";

constexpr const char* ASM_APP_OFF = "; End of inline assembler code\n#NO_APP\n";

inline void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

inline bool REGNO_OK_FOR_INDEX_P(int regno)
{
  return regno == 3;
}

constexpr reg_class INDEX_REG_CLASS = D_REGS;

inline void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  long long int tmp = to - from;
  offset = tmp;
}

// The number of this initializer matches to `FIRST_PSEUDO_REGISTER'
#define FIXED_REGISTERS {0, 0, 0, 1, 1, 1, 1, 1,   0}
//                       X, D, Y, SP,PC,A, B, CCR, Z

#define CALL_USED_REGISTERS {1, 1, 1, 1, 1, 1, 1, 1,   1}
//                           X, D, Y, SP,PC,A, B, CCR, Z


#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000 },			\
/* D_REGS  */		 { 0x00000002 }, /* D */            \
      }

// The number of this initializer matches to `FIRST_PSEUDO_REGISTER'
#define REGISTER_NAMES { "x", "d", "y", "sp", "pc", "a", "b", "ccr", "z" }

#define REG_CLASS_NAMES { "NO_REGS", "D_REGS" }

/* Define this as 1 if `char' should by default be signed; else as 0.  */
constexpr int DEFAULT_SIGNED_CHAR = 0;

#endif // HASEGAWA_H
