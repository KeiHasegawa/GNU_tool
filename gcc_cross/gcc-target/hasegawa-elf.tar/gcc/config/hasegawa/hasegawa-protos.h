#ifndef HASEGAWA_PROTOS_H
#define HASEGAWA_PROTOS_H

void hasegawa_expand_prologue();
void hasegawa_expand_epilogue();
const char* hasegawa_cbranch(rtx op);
const char* hasegawa_mov(rtx, rtx);

bool hasegawa_addsi3_expand(rtx, rtx, rtx);



#endif //  HASEGAWA_PROTOS_H
