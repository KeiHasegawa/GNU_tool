#ifndef HASEGAWA_PROTOS_H
#define HASEGAWA_PROTOS_H

void hasegawa_expand_prologue();
void hasegawa_expand_epilogue();
const char* hasegawa_cbranch(rtx op);

#endif //  HASEGAWA_PROTOS_H
