(define_predicate "tst_operand"
  (match_code "subreg,reg,mem")
{
  return 0;
})
