#ifndef FRV_PROTOS_H
#define FRV_PROTOS_H

void frv_expand_prologue();
void frv_expand_epilogue();
const char* frv_subsi3(rtx x, rtx y, rtx z);
const char* frv_movsi(rtx x, rtx y);
const char* frv_addsi3(rtx x, rtx y, rtx z);
const char* frv_call_value(rtx x, rtx fun);

const char* frv_cbranch(rtx op);

#endif //  FRV_PROTOS_H
