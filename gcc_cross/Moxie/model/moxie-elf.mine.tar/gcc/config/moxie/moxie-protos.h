#ifndef MOXIE_PROTOS_H
#define MOXIE_PROTOS_H

void moxie_expand_prologue();
void moxie_expand_epilogue();
const char* moxie_subsi3(rtx x, rtx y, rtx z);
const char* moxie_movsi(rtx x, rtx y);
const char* moxie_addsi3(rtx x, rtx y, rtx z);
const char* moxie_call_value(rtx x, rtx fun);

const char* moxie_cbranch(rtx op);
#endif //  MOXIE_PROTOS_H
