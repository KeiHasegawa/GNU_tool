#ifndef MIPS_PROTOS_H
#define MIPS_PROTOS_H

void mips_expand_prologue();
void mips_expand_epilogue();

const char* mips_movsi(rtx x, rtx y);
const char* mips_addsi3(rtx x, rtx y, rtx z);
const char* mips_subsi3(rtx x, rtx y, rtx z);
const char* mips_call_value(rtx x, rtx fun);

const char* mips_cbranch(rtx op);

#endif //  MIPS_PROTOS_H
