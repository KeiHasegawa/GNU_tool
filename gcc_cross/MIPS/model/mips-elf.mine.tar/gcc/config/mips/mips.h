#ifndef MIPS_H
#define MIPS_H

#define REGISTER_NAMES							\
{ "$0",   "$1",   "$2",   "$3",   "$4",   "$5",   "$6",   "$7",		\
  "$8",   "$9",   "$10",  "$11",  "$12",  "$13",  "$14",  "$15",	\
  "$16",  "$17",  "$18",  "$19",  "$20",  "$21",  "$22",  "$23",	\
  "$24",  "$25",  "$26",  "$27",  "$28",  "$sp",  "$fp",  "$31",	\
  "$f0",  "$f1",  "$f2",  "$f3",  "$f4",  "$f5",  "$f6",  "$f7",	\
  "$f8",  "$f9",  "$f10", "$f11", "$f12", "$f13", "$f14", "$f15",	\
  "$f16", "$f17", "$f18", "$f19", "$f20", "$f21", "$f22", "$f23",	\
  "$f24", "$f25", "$f26", "$f27", "$f28", "$f29", "$f30", "$f31",	\
  "dummy" }

constexpr int STACK_POINTER_REGNUM  = 29;
#define       FRAME_POINTER_REGNUM    30
#define       ARG_POINTER_REGNUM      FRAME_POINTER_REGNUM
constexpr int LR_REGNUM             = 31;
constexpr int DUMMY_REGNUM          = 64;
constexpr int FIRST_PSEUDO_REGISTER = 65;

#define FIXED_REGISTERS							\
  { 1,      1,      1,      1,      0,      0,    0,      0,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1 }
#define CALL_USED_REGISTERS						\
  { 1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1,      1,      1,      1,      1,      1,    1,      1,		\
    1 }

enum reg_class {
  NO_REGS, SPECIAL_REGS, FLOATING_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS", "FLOATING_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000, 0x00000000, 0x00000000 }, \
/* SPECIAL_REGS */	 { 0xe0000000, 0x00000000, 0x00000001 }, \
/* FLOATING_REGS */	 { 0x00000000, 0xffffffff, 0x00000000 }, \
/* GENERAL_REGS */	 { 0x1fffffff, 0x00000000, 0x00000000 }, \
/* ALL_REGS */		 { 0xffffffff, 0xffffffff, 0x00000001 }}

constexpr int N_REG_CLASSES = (int)LIM_REG_CLASSES;

constexpr int UNITS_PER_WORD = 4;

typedef int CUMULATIVE_ARGS;
extern void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS&, tree, rtx, tree, int);

constexpr int MOVE_MAX = 4;

constexpr bool STRICT_ALIGNMENT = true;

constexpr bool BITS_BIG_ENDIAN  = false;
constexpr bool BYTES_BIG_ENDIAN = true;
constexpr bool WORDS_BIG_ENDIAN = true;

constexpr int FUNCTION_BOUNDARY = 4;

constexpr int TRAMPOLINE_SIZE = 4;

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("MIPSEB")

constexpr int BIGGEST_ALIGNMENT = 8;

constexpr int ATTRIBUTE_ALIGNED_VALUE = 16;

constexpr auto Pmode = SImode;

constexpr int MAX_REGS_PER_ADDRESS = 1;

extern bool FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

constexpr int STACK_BOUNDARY = 8;

constexpr int PARM_BOUNDARY  = 8;

constexpr auto FUNCTION_MODE = QImode;

constexpr reg_class BASE_REG_CLASS = SPECIAL_REGS;

extern bool REGNO_OK_FOR_BASE_P(int);

extern reg_class REGNO_REG_CLASS(int);

constexpr bool SLOW_BYTE_ACCESS = false;

extern void ASM_OUTPUT_ALIGN(FILE*, int);

extern int FIRST_PARM_OFFSET(tree);

constexpr auto CASE_VECTOR_MODE = Pmode;

constexpr const char* ASM_APP_ON = "; Begin inline assembler code\n#APP\n";

constexpr const char* ASM_APP_OFF = "; End of inline assembler code\n#NO_APP\n";

extern void FUNCTION_PROFILER(FILE*, int);

extern bool REGNO_OK_FOR_INDEX_P(int);

constexpr auto INDEX_REG_CLASS = SPECIAL_REGS;

extern void INITIAL_ELIMINATION_OFFSET(int, int, poly_int64_pod&);

constexpr bool DEFAULT_SIGNED_CHAR = false;

extern void mips_print_operand(FILE*, rtx, int);
#define PRINT_OPERAND mips_print_operand

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD	1

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, LR_REGNUM)

#endif // MIPS_H
