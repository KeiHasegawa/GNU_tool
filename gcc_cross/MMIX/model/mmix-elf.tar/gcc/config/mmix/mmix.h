#ifndef MMIX_H
#define MMIX_H

#define REGISTER_NAMES							\
 {"$0", "$1", "$2", "$3", "$4", "$5", "$6", "$7",			\
  "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15",			\
  "$16", "$17", "$18", "$19", "$20", "$21", "$22", "$23",		\
  "$24", "$25", "$26", "$27", "$28", "$29", "$30", "$31",		\
  "$32", "$33", "$34", "$35", "$36", "$37", "$38", "$39",		\
  "$40", "$41", "$42", "$43", "$44", "$45", "$46", "$47",		\
  "$48", "$49", "$50", "$51", "$52", "$53", "$54", "$55",		\
  "$56", "$57", "$58", "$59", "$60", "$61", "$62", "$63",		\
  "$64", "$65", "$66", "$67", "$68", "$69", "$70", "$71",		\
  "$72", "$73", "$74", "$75", "$76", "$77", "$78", "$79",		\
  "$80", "$81", "$82", "$83", "$84", "$85", "$86", "$87",		\
  "$88", "$89", "$90", "$91", "$92", "$93", "$94", "$95",		\
  "$96", "$97", "$98", "$99", "$100", "$101", "$102", "$103",		\
  "$104", "$105", "$106", "$107", "$108", "$109", "$110", "$111",	\
  "$112", "$113", "$114", "$115", "$116", "$117", "$118", "$119",	\
  "$120", "$121", "$122", "$123", "$124", "$125", "$126", "$127",	\
  "$128", "$129", "$130", "$131", "$132", "$133", "$134", "$135",	\
  "$136", "$137", "$138", "$139", "$140", "$141", "$142", "$143",	\
  "$144", "$145", "$146", "$147", "$148", "$149", "$150", "$151",	\
  "$152", "$153", "$154", "$155", "$156", "$157", "$158", "$159",	\
  "$160", "$161", "$162", "$163", "$164", "$165", "$166", "$167",	\
  "$168", "$169", "$170", "$171", "$172", "$173", "$174", "$175",	\
  "$176", "$177", "$178", "$179", "$180", "$181", "$182", "$183",	\
  "$184", "$185", "$186", "$187", "$188", "$189", "$190", "$191",	\
  "$192", "$193", "$194", "$195", "$196", "$197", "$198", "$199",	\
  "$200", "$201", "$202", "$203", "$204", "$205", "$206", "$207",	\
  "$208", "$209", "$210", "$211", "$212", "$213", "$214", "$215",	\
  "$216", "$217", "$218", "$219", "$220", "$221", "$222", "$223",	\
  "$224", "$225", "$226", "$227", "$228", "$229", "$230", "$231",	\
  "$232", "$233", "$234", "$235", "$236", "$237", "$238", "$239",	\
  "$240", "$241", "$242", "$243", "$244", "$245", "$246", "$247",	\
  "$248", "$249", "$250", "$251", "$252", "$253", "$254", "$255",	\
  "rB",   "rD",   "rE",   "rH",   "rJ",   "rM",   "rR",   "rBB",	\
  "rC",   "rN",   "rO",   "rS",   "rI",   "rT",   "rTT",  "rK",		\
  "rQ",   "rU",   "rV",   "rG",   "rL",   "rA",   "rF",   "rP",		\
  "rW",   "rX",   "rY",   "rZ",   "rWW",  "rXX",  "rYY",  "rZZ" }

#define FRAME_POINTER_REGNUM 253
#define ARG_POINTER_REGNUM   FRAME_POINTER_REGNUM
#define STACK_POINTER_REGNUM 254
#define RJ_REGNUM            260
#define FIRST_PSEUDO_REGISTER (256+32)

#define FIXED_REGISTERS							\
 { 0,      0,      0,      0,      0,      0,      0,      0,  		\
   0,      0,      0,      0,      0,      0,      0,      0,  		\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1    }

#define CALL_USED_REGISTERS						\
 { 1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,    	\
   1,      1,      1,      1,      1,      1,      1,      1,   	\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1,  		\
   1,      1,      1,      1,      1,      1,      1,      1    }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS {				\
/* NO_REGS */						\
{ 0x00000000, 0x00000000, 0x00000000, 0x00000000,	\
  0x00000000, 0x00000000, 0x00000000, 0x00000000,	\
  0x00000000 },						\
/* SPECIAL_REGS */					\
{ 0x00000000, 0x00000000, 0x00000000, 0x00000000,	\
  0x00000000, 0x00000000, 0x00000000, 0x00000007,	\
  0xffffffff },					 	\
/* GENERAL_REGS */					\
{ 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,	\
  0xffffffff, 0xffffffff, 0xffffffff, 0xfffffff8,	\
  0x00000000 },					 	\
/* ALL_REGS */						\
{ 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,	\
  0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,	\
    0xffffffff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 8
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           32
#define LONG_TYPE_SIZE		32
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

typedef int CUMULATIVE_ARGS;
extern void mmix_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  mmix_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 8

#define STRICT_ALIGNMENT 1

#define BITS_BIG_ENDIAN 0
#define BYTES_BIG_ENDIAN 1
#define WORDS_BIG_ENDIAN 1

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("MMIX")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode DImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

extern int mmix_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET) \
  (OFFSET) = mmix_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY 8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

extern void ASM_OUTPUT_ALIGN(FILE*, int);

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

extern void FUNCTION_PROFILER(FILE*, int);

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

extern void mmix_print_operand(FILE*, rtx, int);
#define PRINT_OPERAND mmix_print_operand

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1
#define FRAME_GROWS_DOWNWARD 1

#undef  ASM_GENERATE_INTERNAL_LABEL
#define ASM_GENERATE_INTERNAL_LABEL(LABEL, PREFIX, NUM) \
 sprintf(LABEL, "*%s:%ld", PREFIX, (long)(NUM))

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, RJ_REGNUM)

#endif // MMIX_H
