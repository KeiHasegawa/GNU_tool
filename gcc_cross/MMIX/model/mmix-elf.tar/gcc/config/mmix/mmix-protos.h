#ifndef MMIX_PROTOS_H
#define MMIX_PROTOS_H

void mmix_expand_prologue();
void mmix_expand_epilogue();

const char* mmix_movsi(rtx x, rtx y);
const char* mmix_addsi3(rtx x, rtx y, rtx z);
const char* mmix_subsi3(rtx x, rtx y, rtx z);

const char* mmix_movdi(rtx x, rtx y);
const char* mmix_adddi3(rtx x, rtx y, rtx z);
const char* mmix_subdi3(rtx x, rtx y, rtx z);

const char* mmix_call(rtx fun);
const char* mmix_call_value(rtx x, rtx fun);

const char* mmix_cbranch(rtx op);

#endif //  MMIX_PROTOS_H
