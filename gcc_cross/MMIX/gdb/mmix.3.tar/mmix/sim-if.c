#include "sim-main.h"
#include "sim-options.h"
#include <assert.h>

uint64_t get_pc_for_me();

sim_cia mmix_pc_get(sim_cpu* cpu)
{
  return get_pc_for_me();
}

void set_pc_for_me(uint64_t);

void mmix_pc_set(sim_cpu* cpu, sim_cia pc)
{
  set_pc_for_me(pc);
}

static void swap(char* x, char* y)
{
  char tmp = *x;
  *x = *y;
  *y = tmp;
}

uint64_t get_gpr_for_me(int);
uint64_t get_spr_for_me(int);

static uint64_t mmix_get_reg_1(sim_cpu* cpu, int rn)
{
  if (rn < 256)
    return get_gpr_for_me(rn);

  int n = rn - 256;
  if (n < 32)
    return get_spr_for_me(n);

  assert(n == 32);
  return mmix_pc_get(cpu);
}

int mmix_reg_get(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 8);
  union {
    uint64_t i;
    char c[8];
  } u = { mmix_get_reg_1(cpu, rn) };
  int n = 1;
  if ((char*)&n) {
    // simulator runs at little endian processor
    swap(&u.c[0], &u.c[7]);
    swap(&u.c[1], &u.c[6]);
    swap(&u.c[2], &u.c[5]);
    swap(&u.c[3], &u.c[4]);
  }
  memcpy(buf, &u.i, length);
  return length;
}

int mmix_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  asm("int3");
}

SIM_DESC sim_open (SIM_OPEN_KIND kind, struct host_callback_struct *callback,
		   struct bfd *abfd, char * const *argv)
{
  SIM_DESC sd = sim_state_alloc (kind, callback);
  assert(sd);

  if (sim_cpu_alloc_all (sd, 1, 0) != SIM_RC_OK)
    return 0;

  if (sim_pre_argv_init (sd, argv[0]) != SIM_RC_OK)
    return 0;

  if (sim_parse_args (sd, argv) != SIM_RC_OK)
    return 0;

  if (sim_analyze_program (sd,
			   (STATE_PROG_ARGV (sd) != NULL
			       ? *STATE_PROG_ARGV(sd)
			    : NULL), abfd) != SIM_RC_OK)
    return 0;

  if (sim_config (sd) != SIM_RC_OK)
    return 0;

  if (sim_post_argv_init (sd) != SIM_RC_OK)
    return 0;

  sim_cpu* cpu = STATE_CPU(sd, 0);
  CPU_PC_FETCH(cpu) = mmix_pc_get;
  CPU_PC_STORE(cpu) = mmix_pc_set;

  CPU_REG_FETCH(cpu) = mmix_reg_get;
  CPU_REG_STORE(cpu) = mmix_reg_set;

  return sd;
}

SIM_RC sim_create_inferior (SIM_DESC sd, struct bfd *abfd,
			    char * const *argv, char * const *env)
{
  if (abfd) {
    sim_cpu* cpu = STATE_CPU(sd, 0);
    mmix_pc_set(cpu, bfd_get_start_address (abfd));
  }
  return SIM_RC_OK;
}

char* simulator_sysroot = "";

instruction_word mmix_fetch(SIM_DESC sd, sim_cia cia)
{
  sim_cpu* cpu = STATE_CPU(sd, 0);
  return sim_core_read_aligned_4(cpu, cia, read_map, cia);
}

sim_cpu* g_cpu;
sim_cia g_cia;

void
sim_core_write_aligned_4_for_me(unsigned long long addr, unsigned long long v)
{
  sim_core_write_aligned_4(g_cpu, g_cia, write_map, addr, v);
}

uint32_t sim_core_read_aligned_4_for_me(unsigned long long addr)
{
  return sim_core_read_aligned_4(g_cpu, g_cia, read_map, addr);
}

void execute_for_me(instruction_word);

sim_cia idecode_issue(SIM_DESC sd, instruction_word insn, sim_cia cia)
{
  g_cpu = STATE_CPU(sd, 0);
  g_cia = cia;
  
  if (insn == 0xbadbeef0)
    sim_engine_halt(sd, g_cpu, 0, cia, sim_stopped, SIM_SIGTRAP);

  execute_for_me(insn);
  uint32_t ret = mmix_pc_get(g_cpu) + 4;
  mmix_pc_set(g_cpu, ret);
  return ret;
}

#include "targ-vals.h"

/* syscall mapping table */
CB_TARGET_DEFS_MAP cb_init_syscall_map[] = {
  { 0, -1, -1 }
};

/* errno mapping table */
CB_TARGET_DEFS_MAP cb_init_errno_map[] = {
#ifdef E2BIG
  { "E2BIG", E2BIG, TARGET_E2BIG },
#endif
#ifdef EACCES
  { "EACCES", EACCES, TARGET_EACCES },
#endif
#ifdef EADDRINUSE
  { "EADDRINUSE", EADDRINUSE, TARGET_EADDRINUSE },
#endif
#ifdef EADDRNOTAVAIL
  { "EADDRNOTAVAIL", EADDRNOTAVAIL, TARGET_EADDRNOTAVAIL },
#endif
#ifdef EAFNOSUPPORT
  { "EAFNOSUPPORT", EAFNOSUPPORT, TARGET_EAFNOSUPPORT },
#endif
#ifdef EAGAIN
  { "EAGAIN", EAGAIN, TARGET_EAGAIN },
#endif
#ifdef EALREADY
  { "EALREADY", EALREADY, TARGET_EALREADY },
#endif
#ifdef EBADF
  { "EBADF", EBADF, TARGET_EBADF },
#endif
#ifdef EBADMSG
  { "EBADMSG", EBADMSG, TARGET_EBADMSG },
#endif
#ifdef EBUSY
  { "EBUSY", EBUSY, TARGET_EBUSY },
#endif
#ifdef ECANCELED
  { "ECANCELED", ECANCELED, TARGET_ECANCELED },
#endif
#ifdef ECHILD
  { "ECHILD", ECHILD, TARGET_ECHILD },
#endif
#ifdef ECONNABORTED
  { "ECONNABORTED", ECONNABORTED, TARGET_ECONNABORTED },
#endif
#ifdef ECONNREFUSED
  { "ECONNREFUSED", ECONNREFUSED, TARGET_ECONNREFUSED },
#endif
#ifdef ECONNRESET
  { "ECONNRESET", ECONNRESET, TARGET_ECONNRESET },
#endif
#ifdef EDEADLK
  { "EDEADLK", EDEADLK, TARGET_EDEADLK },
#endif
#ifdef EDESTADDRREQ
  { "EDESTADDRREQ", EDESTADDRREQ, TARGET_EDESTADDRREQ },
#endif
#ifdef EDOM
  { "EDOM", EDOM, TARGET_EDOM },
#endif
#ifdef EDQUOT
  { "EDQUOT", EDQUOT, TARGET_EDQUOT },
#endif
#ifdef EEXIST
  { "EEXIST", EEXIST, TARGET_EEXIST },
#endif
#ifdef EFAULT
  { "EFAULT", EFAULT, TARGET_EFAULT },
#endif
#ifdef EFBIG
  { "EFBIG", EFBIG, TARGET_EFBIG },
#endif
#ifdef EFTYPE
  { "EFTYPE", EFTYPE, TARGET_EFTYPE },
#endif
#ifdef EHOSTDOWN
  { "EHOSTDOWN", EHOSTDOWN, TARGET_EHOSTDOWN },
#endif
#ifdef EHOSTUNREACH
  { "EHOSTUNREACH", EHOSTUNREACH, TARGET_EHOSTUNREACH },
#endif
#ifdef EIDRM
  { "EIDRM", EIDRM, TARGET_EIDRM },
#endif
#ifdef EILSEQ
  { "EILSEQ", EILSEQ, TARGET_EILSEQ },
#endif
#ifdef EINPROGRESS
  { "EINPROGRESS", EINPROGRESS, TARGET_EINPROGRESS },
#endif
#ifdef EINTR
  { "EINTR", EINTR, TARGET_EINTR },
#endif
#ifdef EINVAL
  { "EINVAL", EINVAL, TARGET_EINVAL },
#endif
#ifdef EIO
  { "EIO", EIO, TARGET_EIO },
#endif
#ifdef EISCONN
  { "EISCONN", EISCONN, TARGET_EISCONN },
#endif
#ifdef EISDIR
  { "EISDIR", EISDIR, TARGET_EISDIR },
#endif
#ifdef ELOOP
  { "ELOOP", ELOOP, TARGET_ELOOP },
#endif
#ifdef EMFILE
  { "EMFILE", EMFILE, TARGET_EMFILE },
#endif
#ifdef EMLINK
  { "EMLINK", EMLINK, TARGET_EMLINK },
#endif
#ifdef EMSGSIZE
  { "EMSGSIZE", EMSGSIZE, TARGET_EMSGSIZE },
#endif
#ifdef EMULTIHOP
  { "EMULTIHOP", EMULTIHOP, TARGET_EMULTIHOP },
#endif
#ifdef ENAMETOOLONG
  { "ENAMETOOLONG", ENAMETOOLONG, TARGET_ENAMETOOLONG },
#endif
#ifdef ENETDOWN
  { "ENETDOWN", ENETDOWN, TARGET_ENETDOWN },
#endif
#ifdef ENETRESET
  { "ENETRESET", ENETRESET, TARGET_ENETRESET },
#endif
#ifdef ENETUNREACH
  { "ENETUNREACH", ENETUNREACH, TARGET_ENETUNREACH },
#endif
#ifdef ENFILE
  { "ENFILE", ENFILE, TARGET_ENFILE },
#endif
#ifdef ENOBUFS
  { "ENOBUFS", ENOBUFS, TARGET_ENOBUFS },
#endif
#ifdef ENODATA
  { "ENODATA", ENODATA, TARGET_ENODATA },
#endif
#ifdef ENODEV
  { "ENODEV", ENODEV, TARGET_ENODEV },
#endif
#ifdef ENOENT
  { "ENOENT", ENOENT, TARGET_ENOENT },
#endif
#ifdef ENOEXEC
  { "ENOEXEC", ENOEXEC, TARGET_ENOEXEC },
#endif
#ifdef ENOLCK
  { "ENOLCK", ENOLCK, TARGET_ENOLCK },
#endif
#ifdef ENOLINK
  { "ENOLINK", ENOLINK, TARGET_ENOLINK },
#endif
#ifdef ENOMEM
  { "ENOMEM", ENOMEM, TARGET_ENOMEM },
#endif
#ifdef ENOMSG
  { "ENOMSG", ENOMSG, TARGET_ENOMSG },
#endif
#ifdef ENOPROTOOPT
  { "ENOPROTOOPT", ENOPROTOOPT, TARGET_ENOPROTOOPT },
#endif
#ifdef ENOSPC
  { "ENOSPC", ENOSPC, TARGET_ENOSPC },
#endif
#ifdef ENOSR
  { "ENOSR", ENOSR, TARGET_ENOSR },
#endif
#ifdef ENOSTR
  { "ENOSTR", ENOSTR, TARGET_ENOSTR },
#endif
#ifdef ENOSYS
  { "ENOSYS", ENOSYS, TARGET_ENOSYS },
#endif
#ifdef ENOTCONN
  { "ENOTCONN", ENOTCONN, TARGET_ENOTCONN },
#endif
#ifdef ENOTDIR
  { "ENOTDIR", ENOTDIR, TARGET_ENOTDIR },
#endif
#ifdef ENOTEMPTY
  { "ENOTEMPTY", ENOTEMPTY, TARGET_ENOTEMPTY },
#endif
#ifdef ENOTRECOVERABLE
  { "ENOTRECOVERABLE", ENOTRECOVERABLE, TARGET_ENOTRECOVERABLE },
#endif
#ifdef ENOTSOCK
  { "ENOTSOCK", ENOTSOCK, TARGET_ENOTSOCK },
#endif
#ifdef ENOTSUP
  { "ENOTSUP", ENOTSUP, TARGET_ENOTSUP },
#endif
#ifdef ENOTTY
  { "ENOTTY", ENOTTY, TARGET_ENOTTY },
#endif
#ifdef ENXIO
  { "ENXIO", ENXIO, TARGET_ENXIO },
#endif
#ifdef EOPNOTSUPP
  { "EOPNOTSUPP", EOPNOTSUPP, TARGET_EOPNOTSUPP },
#endif
#ifdef EOVERFLOW
  { "EOVERFLOW", EOVERFLOW, TARGET_EOVERFLOW },
#endif
#ifdef EOWNERDEAD
  { "EOWNERDEAD", EOWNERDEAD, TARGET_EOWNERDEAD },
#endif
#ifdef EPERM
  { "EPERM", EPERM, TARGET_EPERM },
#endif
#ifdef EPFNOSUPPORT
  { "EPFNOSUPPORT", EPFNOSUPPORT, TARGET_EPFNOSUPPORT },
#endif
#ifdef EPIPE
  { "EPIPE", EPIPE, TARGET_EPIPE },
#endif
#ifdef EPROTO
  { "EPROTO", EPROTO, TARGET_EPROTO },
#endif
#ifdef EPROTONOSUPPORT
  { "EPROTONOSUPPORT", EPROTONOSUPPORT, TARGET_EPROTONOSUPPORT },
#endif
#ifdef EPROTOTYPE
  { "EPROTOTYPE", EPROTOTYPE, TARGET_EPROTOTYPE },
#endif
#ifdef ERANGE
  { "ERANGE", ERANGE, TARGET_ERANGE },
#endif
#ifdef EROFS
  { "EROFS", EROFS, TARGET_EROFS },
#endif
#ifdef ESPIPE
  { "ESPIPE", ESPIPE, TARGET_ESPIPE },
#endif
#ifdef ESRCH
  { "ESRCH", ESRCH, TARGET_ESRCH },
#endif
#ifdef ESTALE
  { "ESTALE", ESTALE, TARGET_ESTALE },
#endif
#ifdef ETIME
  { "ETIME", ETIME, TARGET_ETIME },
#endif
#ifdef ETIMEDOUT
  { "ETIMEDOUT", ETIMEDOUT, TARGET_ETIMEDOUT },
#endif
#ifdef ETOOMANYREFS
  { "ETOOMANYREFS", ETOOMANYREFS, TARGET_ETOOMANYREFS },
#endif
#ifdef ETXTBSY
  { "ETXTBSY", ETXTBSY, TARGET_ETXTBSY },
#endif
#ifdef EWOULDBLOCK
  { "EWOULDBLOCK", EWOULDBLOCK, TARGET_EWOULDBLOCK },
#endif
#ifdef EXDEV
  { "EXDEV", EXDEV, TARGET_EXDEV },
#endif
  { 0, 0, 0 }
};

/* open flags mapping table */
CB_TARGET_DEFS_MAP cb_init_open_map[] = {
#ifdef O_ACCMODE
  { "O_ACCMODE", O_ACCMODE, TARGET_O_ACCMODE },
#endif
#ifdef O_APPEND
  { "O_APPEND", O_APPEND, TARGET_O_APPEND },
#endif
#ifdef O_CREAT
  { "O_CREAT", O_CREAT, TARGET_O_CREAT },
#endif
#ifdef O_EXCL
  { "O_EXCL", O_EXCL, TARGET_O_EXCL },
#endif
#ifdef O_NOCTTY
  { "O_NOCTTY", O_NOCTTY, TARGET_O_NOCTTY },
#endif
#ifdef O_NONBLOCK
  { "O_NONBLOCK", O_NONBLOCK, TARGET_O_NONBLOCK },
#endif
#ifdef O_RDONLY
  { "O_RDONLY", O_RDONLY, TARGET_O_RDONLY },
#endif
#ifdef O_RDWR
  { "O_RDWR", O_RDWR, TARGET_O_RDWR },
#endif
#ifdef O_SYNC
  { "O_SYNC", O_SYNC, TARGET_O_SYNC },
#endif
#ifdef O_TRUNC
  { "O_TRUNC", O_TRUNC, TARGET_O_TRUNC },
#endif
#ifdef O_WRONLY
  { "O_WRONLY", O_WRONLY, TARGET_O_WRONLY },
#endif
  { 0, -1, -1 }
};

void ex_throw()
{
  abort();
}

void cfg_isTestMode()
{
  abort();
}

unsigned long long curBits;

int curEnv;

void ex_push()
{
  abort();
}

int curEx;

jmp_buf* envs[1024];

void ex_rethrow()
{
  abort();
}

void ev_fire2(int VAT, unsigned long long addr, int mode)
{
}

void mem_alloc()
{
  abort();
}

void mem_free()
{
  abort();
}
	      
void ram_init()
{
  abort();
}
void timer_init()
{
  abort();
}
void term_init()
{
  abort();
}
void disk_init()
{
  abort();
}
void output_init()
{
  abort();
}
void rom_init()
{
  abort();
}
void dspkbd_init()
{
  abort();
}
void sim_error()
{
  abort();
}
void ev_register()
{
  abort();
}
void ev_fire()
{
  abort();
}
void timer_tick()
{
  abort();
}

