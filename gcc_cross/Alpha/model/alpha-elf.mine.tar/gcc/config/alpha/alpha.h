#ifndef ALPHA_H
#define ALPHA_H

#define REGISTER_NAMES  \
  { "$0",  "$1",  "$2",  "$3",  "$4",  "$5",  "$6",  "$7",  \
    "$8",  "$9",  "$10", "$11", "$12", "$13", "$14", "$15", \
    "$16", "$17", "$18", "$19", "$20", "$21", "$22", "$23", \
    "$24", "$25", "$26", "$27", "$28", "$29", "$30", "$31" }

#define FRAME_POINTER_REGNUM	15
#define ARG_POINTER_REGNUM	FRAME_POINTER_REGNUM
#define RA_REGNUM		26
#define STACK_POINTER_REGNUM	30
#define ZERO_REGNUM		31
#define FIRST_PSEUDO_REGISTER	32

#define FIXED_REGISTERS  \
  {   0,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1 }

#define CALL_USED_REGISTERS  \
  {   1,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1,   \
      1,     1,     1,     1,     1,     1,     1,     1 }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */			{{ 0x00000000 }, \
/* SPECIAL_REGS */		 { 0xfc008000 }, \
/* GENERAL_REGS */		 { 0x03ff7fff }, \
/* ALL_REGS */			 { 0xffffffff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 8
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           32
#define LONG_TYPE_SIZE		64
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   64

typedef int CUMULATIVE_ARGS;
void alpha_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  alpha_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 8

#define STRICT_ALIGNMENT 1
#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 0
#define WORDS_BIG_ENDIAN 0

#define FUNCTION_BOUNDARY 8

#define TRAMPOLINE_SIZE 8

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("alpha")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode DImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { \
  {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}, \
  {ARG_POINTER_REGNUM, STACK_POINTER_REGNUM}}

extern int alpha_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)	\
  (OFFSET) = alpha_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY  8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, RA_REGNUM)

#endif // ALPHA_H
