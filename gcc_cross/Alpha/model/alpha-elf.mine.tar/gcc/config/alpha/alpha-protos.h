#ifndef ALPHA_PROTOS_H
#define ALPHA_PROTOS_H

namespace alpha {
  void expand_prologue();
  void expand_epilogue();
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace si
  namespace di {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namespace di
  const char* call_value(rtx x, rtx fun);
  const char* cbranch(rtx op);  
} // end of namespace alpha

#endif //  ALPHA_PROTOS_H
