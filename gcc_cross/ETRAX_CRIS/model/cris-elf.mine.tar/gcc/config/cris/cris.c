#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx cris_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return gen_rtx_REG(mode, 10);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE cris_function_value

bool cris_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P cris_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum, tree fntype, rtx,
			  tree func, int)
{
  (void)fntype;
  (void)func;
  cum.nregs = cum.offset = 0;
}


void cris_function_arg_advance(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 5) {
    ++cum->nregs;
    return;
  }
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE cris_function_arg_advance

rtx cris_function_incoming_arg(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 5)
    return gen_rtx_REG(arg.mode, cum->nregs + 10);
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG cris_function_incoming_arg

rtx cris_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  return cris_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG cris_function_arg

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  (void)regno;
  return false;
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case 0: return R0_REGS;
  case 1: return R1_REGS;
  case 2: return R2_REGS;
  case 3: return R3_REGS;
  case 4: return R4_REGS;
  case 5: return R5_REGS;
  case 6: return R6_REGS;
  case 7: return R7_REGS;
  case FRAME_POINTER_REGNUM: return FP_REGS;    
  case 9: return R9_REGS;
  case 10: return R10_REGS;
  case 11: return R11_REGS;
  case 12: return R12_REGS;
  case 13: return R13_REGS;
  case STACK_POINTER_REGNUM: return SP_REGS;
  case PC_REGNUM: return PC_REGS;
  case SRP_REGNUM: return SRP_REGS;
  default: abort();
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 8;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  long long int tmp = to - from;
  offset = tmp;
}

inline char binop(rtx x)
{
  assert(GET_CODE (x) == PLUS);
  return '+';
}

void cris_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    bool paren = !SYMBOL_REF_P(e0);
    if (paren)
      fprintf(fp, "(");
    cris_print_operand(fp, e0, 0);
    if (paren)
      fprintf(fp, ")");
    return;
  }
  if (SYMBOL_REF_P(x)) {
    auto s0 = XSTR(x, 0);
    fprintf(fp, "_%s", s0);
    return;
  }
  if (BINARY_P(x)) {
    auto e0 = XEXP(x, 0);
    cris_print_operand(fp, e0, 0);
    fprintf(fp, "%c", binop(x));
    auto e1 = XEXP(x, 1);
    cris_print_operand(fp, e1, 0);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void cris_expand_prologue()
{
  auto sp = stack_pointer_rtx;
  auto c4 = gen_rtx_CONST_INT(Pmode, 4);
  auto minus = gen_rtx_MINUS(Pmode, sp, c4);
  auto insn = emit_move_insn(sp, minus);
  RTX_FRAME_RELATED_P(insn) = true;
  
  auto srp = gen_rtx_REG(Pmode, SRP_REGNUM);
  auto mem = gen_rtx_MEM(Pmode, sp);
  insn = emit_move_insn(mem, srp);
  RTX_FRAME_RELATED_P(insn) = true;
  insn = emit_move_insn(sp, minus);
  RTX_FRAME_RELATED_P(insn) = true;
  
  auto fp = frame_pointer_rtx;
  insn = emit_move_insn(mem, fp);
  RTX_FRAME_RELATED_P(insn) = true;
  emit_move_insn(fp, sp);  
  if (auto size = get_frame_size()) {
    auto tmp = gen_rtx_CONST_INT(Pmode, size);
    auto minus = gen_rtx_MINUS(Pmode, sp, tmp);
    insn = emit_move_insn(sp, minus);
    RTX_FRAME_RELATED_P(insn) = true;
  }
}

const char* cris_subsi3(rtx x, rtx y, rtx z)
{
  if (x == stack_pointer_rtx && x == y && CONST_INT_P(z))
    return "subq	%2, %1";
  
  return "%0 := %1 - %2";
}

inline bool ptr_sp(rtx x)
{
  if (!MEM_P(x))
    return 0;
  auto y = XEXP(x, 0);
  return y == stack_pointer_rtx;
}

inline bool is_srp(rtx x)
{
  return REG_P(x) && REGNO(x) == SRP_REGNUM;
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == FRAME_POINTER_REGNUM;
}

const char* cris_movsi(rtx x, rtx y)
{
  if (ptr_sp(x)) {
    if (is_srp(y))
      return "move	%1, [$sp]";
    if (y == frame_pointer_rtx)
      return "move.d	%1, [$sp]";
  }

  if (x == frame_pointer_rtx && y == stack_pointer_rtx)
    return "move.d	%1, %0";

  if (x == stack_pointer_rtx && y == frame_pointer_rtx)
    return "move.d	%1, %0";

  int offset;
  if (fp_rel(x, &offset) && REG_P(y)) {
    int regno = REGNO(y);
    auto r = reg_names[regno];
    auto fp = reg_names[FRAME_POINTER_REGNUM];
    assert(offset < 0);
    fprintf(asm_out_file, "	move.d	%s,[%s%d]\n", r, fp, offset);
    return "";
  }

  if (REG_P(x) && SYMBOL_REF_P(y)) {
    int regno = REGNO(x);
    auto r = reg_names[regno];
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    fprintf(asm_out_file, "	move.d	%s, %s\n", s, r);
    return "";
  }

  if (REG_P(x) && CONST_INT_P(y)) {
    int v = INTVAL(y);
    if (!v)
      return "clear.d	%0";
    return "moveq	%1, %0";
  }

  if (REG_P(x) && REG_P(y))
    return "move.d	%1, %0";

  return "%0 := %1";
}

void cris_expand_epilogue()
{
  auto sp = stack_pointer_rtx;
  auto fp = frame_pointer_rtx;
  emit_move_insn(sp, fp);  
  emit_insn(gen_pop(fp));
  emit_insn(gen_pop_and_ret());
}

inline void load(int regno, int offset)
{
  auto fp = reg_names[FRAME_POINTER_REGNUM];
  assert(offset < 0);
  auto r = reg_names[regno];
  fprintf(asm_out_file, "	move.d	[%s%d], %s\n", fp, offset, r);
}

const char* cris_addsi3(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int regno = REGNO(x);
    load(regno, offy);
    auto fp = reg_names[FRAME_POINTER_REGNUM];
    auto r = reg_names[regno];
    fprintf(asm_out_file, "	add.d	[%s%d], %s\n", fp, offz, r);
    return "";
  }

  return "%0 := %1 + %2";
}

const char* cris_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && REGNO(x) == 10 && MEM_P(fun))
    return "Jsr	%1";

  return "%0 := call %1";
}

const char* cris_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

bool cris_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}
