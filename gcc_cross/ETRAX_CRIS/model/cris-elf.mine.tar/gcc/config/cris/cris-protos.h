#ifndef CRIS_PROTOS_H
#define CRIS_PROTOS_H

void cris_expand_prologue();
void cris_expand_epilogue();

const char* cris_subsi3(rtx x, rtx y, rtx z);
const char* cris_movsi(rtx x, rtx y);
const char* cris_addsi3(rtx x, rtx y, rtx z);
const char* cris_call_value(rtx x, rtx fun);

const char* cris_cbranch(rtx op);

#endif //  HASEGAWA_PROTOS_H
