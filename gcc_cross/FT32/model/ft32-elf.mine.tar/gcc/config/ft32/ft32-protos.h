#ifndef FT32_PROTOS_H
#define FT32_PROTOS_H

void ft32_expand_prologue();
void ft32_expand_epilogue();

const char* ft32_movsi(rtx x, rtx y);
const char* ft32_addsi3(rtx x, rtx y, rtx z);
const char* ft32_call_value(rtx x, rtx fun);

const char* ft32_cbranch(rtx op);

#endif //  FT32_PROTOS_H
