#ifndef x86_64_H
#define x86_64_H

#define REGISTER_NAMES  \
{ "%rax", "%rbx", "%rcx", "%rdx", "%rsi", "%rdi", "%rbp", "%rsp",	\
  "%r8", "%r9", "%r10", "%r11", "%r12", "%r13", "%r14", "%r15",		\
  "%rip", "%eflags", "%cs", "%ss", "%ds", "%es", "%fs", "%gs",		\
  "%st0", "%st1", "%st2", "%st3", "%st4", "%st5", "%st6", "%st7",	\
  "%fctrl", "%fstat", "%ftag", "%fiseg", "%fioff", "%foseg", "%fooff", "%fop",\
  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7",\
  "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15",\
  "dummy" }

#define RAX_REGNUM			0
#define RBX_REGNUM			1
#define RCX_REGNUM			2
#define RDX_REGNUM			3
#define RSI_REGNUM			4
#define RDI_REGNUM			5
#define FRAME_POINTER_REGNUM		6
#define STACK_POINTER_REGNUM		7
#define ARG_POINTER_REGNUM		FRAME_POINTER_REGNUM
#define ST0_REGNUM			24
#define XMM0_REGNUM			40
#define DUMMY_REGNUM			56
#define FIRST_PSEUDO_REGISTER		57

#define FIXED_REGISTERS  \
{  0,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1, 	\
   1 }

#define CALL_USED_REGISTERS  \
{  1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1,	\
   1,     1,     1,     1,     1,     1,     1,     1, 	\
   1 }


enum reg_class {
  NO_REGS, SPECIAL_REGS, FLOAT_REGS, XMM_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS", "FLOAT_REGS", "XMM_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */		{{ 0x00000000, 0x00000000 }, \
/* SPECIAL_REGS */	 { 0x00ff00e0, 0x010100ff }, \
/* FLOAT_REGS */	 { 0xff000000, 0x00000000 }, \
/* XMM_REGS */		 { 0x00000000, 0x00ffff00 }, \
/* GENERAL_REGS */	 { 0x0000ff3f, 0x00000000 }, \
/* ALL_REGS */           { 0xffffffff, 0x01ffffff }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 8
#define SHORT_TYPE_SIZE		16
#define INT_TYPE_SIZE           32
#define LONG_TYPE_SIZE		64
#define LONG_LONG_TYPE_SIZE     64
#define FLOAT_TYPE_SIZE         32
#define DOUBLE_TYPE_SIZE        64
#define LONG_DOUBLE_TYPE_SIZE   128

typedef int CUMULATIVE_ARGS;
void x86_64_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
  x86_64_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 8

#define STRICT_ALIGNMENT 1

#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 1
#define WORDS_BIG_ENDIAN 1

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("x86_64")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode DImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY 8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { \
    fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
    fprintf(FILE, "	jsr mcount\n");		    \
  } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

extern int x86_64_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)		\
  (OFFSET) = x86_64_initial_elimination_offset(FROM, TO)

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.data"
#define BSS_SECTION_ASM_OP   "\t.bss"

#define STACK_GROWS_DOWNWARD 1
#define FRAME_GROWS_DOWNWARD 1

#define INCOMING_RETURN_ADDR_RTX gen_rtx_MEM(Pmode, stack_pointer_rtx)
#define INCOMING_FRAME_SP_OFFSET 8

#endif // x86_64_H
