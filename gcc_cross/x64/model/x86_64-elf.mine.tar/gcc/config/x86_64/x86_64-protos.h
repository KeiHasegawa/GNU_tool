#ifndef x86_64_PROTOS_H
#define x86_64_PROTOS_H

namespace x86_64 {
  void expand_prologue();
  void expand_epilogue();
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
  } // end of namepsace si
  namespace di {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
  } // end of namepsace di
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  const char* cbranch(rtx op);
} // end of namespace x86_64

#endif //  x86_64_PROTOS_H
