#include <stdint.h>

#include <cassert>
#include <utility>
#include <cstring>

#include "memory.h"
#include "cpu.h"

Memory* my_memory;
CPU* my_cpu; 

extern "C" void my_init()
{
  my_memory = new Memory;
  my_cpu = new CPU(my_memory);
}

struct sim_cpu_;
typedef struct sim_cpu_ sim_cpu;
typedef uint16_t sim_cia;

extern "C" sim_cia pdp11_pc_get(sim_cpu* cpu)
{
  return sim_core_read_aligned_2_for_me(PC); 
}

extern "C" void pdp11_pc_set(sim_cpu* cpu, sim_cia pc)
{
  sim_core_write_aligned_2_for_me(PC, pc);
}

extern "C" int
pdp11_reg_get(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(0 <= rn && rn <= 7);
  assert(length == 2);
  union {
    uint16_t i;
    char c[2];
  } u = { sim_core_read_aligned_2_for_me(0177700+4*rn) };
  int n = 1;
  if (!*(char*)&n) {
    // processor runs at big endian
    std::swap(u.c[0], u.c[1]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" int
pdp11_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  asm("int3");
  return length;
}

typedef void* SIM_DESC;
typedef uint16_t instruction_word;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  my_cpu->FDE();
}
