#ifndef MEMORY_H
#define MEMORY_H

#include <fstream>
#include <string>
#include <vector>

// Register memory locations
#define R0 0177700U
#define R1 0177704U
#define R2 0177710U
#define R3 0177714U
#define R4 0177720U
#define R5 0177724U
#define SP 0177730U
#define PC 0177734U
#define PS 0177776U

extern "C" uint8_t sim_core_read_aligned_1_for_me(uint16_t);
extern "C" uint16_t sim_core_read_aligned_2_for_me(uint16_t);

extern "C" void sim_core_write_aligned_1_for_me(uint16_t, uint8_t);
extern "C" void sim_core_write_aligned_2_for_me(uint16_t, uint16_t);

// Debug levels
enum Verbosity
{
  off,
  minimal,
  verbose
};

// Transaction types
enum Transaction
{
  read,
  write,
  instruction
};


class Memory
{
  public:
    Memory();
    ~Memory();
    unsigned short ReadAddress(unsigned short address);
    void WriteAddress(unsigned short address, unsigned short data);
#if 0
    void DecrementPC() { RAM[PC] = RAM[PC] - 2; };
    void IncrementPC() { RAM[PC] = RAM[PC] + 2; };
#else
    void DecrementPC()
    {
      auto v = sim_core_read_aligned_2_for_me(PC);
      sim_core_write_aligned_2_for_me(PC, v-2);
    }
    void IncrementPC()
    {
      auto v = sim_core_read_aligned_2_for_me(PC);
      sim_core_write_aligned_2_for_me(PC, v+2);
    }
#endif  
    unsigned short RetrievePC();
    unsigned short EA(unsigned short encodedAddress, Transaction type = Transaction::read);
    unsigned short Read(unsigned short encodedAddress);
    unsigned short ReadInstruction();
    void Write(unsigned short encodedAddress, unsigned short data);
    void SetDebugMode(Verbosity verbosity) { debugLevel = verbosity; };
    unsigned short StackPop();
    void StackPush(unsigned short _register);
    void RegDump();
    void TraceDump(Transaction type, unsigned short address);
    void SetByteMode() { byteMode = 01; };
    void ClearByteMode() { byteMode = 02; };
    void ResetPC();
    void ResetRAM();
    unsigned short ReadPS();
    void WritePS(unsigned short status);

    int byteMode;
    int debugLevel;
    int regArray[8];
    unsigned char *initialRAM;
    unsigned char *RAM;
    unsigned short initialPC;
    std::ofstream *traceFile;
};
#endif // MEMORY_H
