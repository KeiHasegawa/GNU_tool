#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

inline rtx common_function_value(machine_mode mode)
{
  return gen_rtx_REG(mode, 0);
}

rtx pdp11_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  return common_function_value(mode);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE pdp11_function_value

bool pdp11_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

void pdp11_init_cumulative_args(CUMULATIVE_ARGS* cum, tree, rtx, tree, int)
{
  (void)cum;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P pdp11_legitimate_address_p

void pdp11_function_arg_advance(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  (void)pcum_v;
  (void)arg;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE pdp11_function_arg_advance

rtx pdp11_function_incoming_arg(cumulative_args_t pcum_v,
				const function_arg_info& arg)
{
  (void)pcum_v;
  (void)arg;
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG pdp11_function_incoming_arg

rtx pdp11_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  (void)pcum_v;
  (void)arg;
  return nullptr;
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG pdp11_function_arg

rtx pdp11_libcall_value(machine_mode mode, const_rtx fun)
{
  (void)fun;
  return common_function_value(mode);
}

#undef TARGET_LIBCALL_VALUE
#define TARGET_LIBCALL_VALUE pdp11_libcall_value

inline bool is_push(rtx x)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code != PRE_DEC)
    return false;
  auto z = XEXP(y, 0);
  return z == stack_pointer_rtx;
}

inline bool is_pop(rtx x)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code != POST_INC)
    return false;
  auto z = XEXP(y, 0);
  return z == stack_pointer_rtx;
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  auto code = GET_CODE(y);
  if (code != PLUS)
    return false;
  auto z = XEXP(y, 0);
  if (z != frame_pointer_rtx)
    return false;
  auto u = XEXP(y, 1);
  if (!CONST_INT_P(u))
    return false;
  *offset = INTVAL(u);
  return true;
}

void pdp11_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fputc('$', fp);
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  if (is_push(x)) {
    fprintf(fp, "-(sp)");
    return;
  }
  if (is_pop(x)) {
    fprintf(fp, "(sp)+");
    return;
  }
  int offset;
  if (fp_rel(x, &offset)) {
    auto rn = reg_names[FRAME_POINTER_REGNUM];
    fprintf(fp, "%d(%s)", offset, rn);
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    if (SYMBOL_REF_P(e0)) {
      auto s = XSTR(e0, 0);
      ASM_OUTPUT_LABELREF(fp, s);
      return;
    }
  }
  if (SYMBOL_REF_P(x)) {
    auto s = XSTR(x, 0);
    assert(*s == '*');
    ++s;
    fprintf(fp, "$%s", s);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

#undef TARGET_PRINT_OPERAND
#define TARGET_PRINT_OPERAND pdp11_print_operand

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.global	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

int FUNCTION_ARG_REGNO_P(int regno)
{
  (void)regno;
  return 0;
}

int REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case STACK_POINTER_REGNUM:
  case FRAME_POINTER_REGNUM:
    return SPECIAL_REGS;
  default:
    return GENERAL_REGS;
  }
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 4;
}

int REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

int pdp11_initial_elimination_offset(int from, int to)
{
  assert(from == FRAME_POINTER_REGNUM && to == STACK_POINTER_REGNUM);
  return get_frame_size();
}

void pdp11::expand_prologue()
{
  auto sp = stack_pointer_rtx;
  auto pd = gen_rtx_PRE_DEC(Pmode, sp);
  auto mem = gen_rtx_MEM(Pmode, pd);
  auto fp = frame_pointer_rtx;
  auto insn = emit_move_insn(mem, fp);
  RTX_FRAME_RELATED_P(insn) = true;
  insn = emit_move_insn(fp, sp);
  RTX_FRAME_RELATED_P(insn) = true;
  if (auto size = get_frame_size()) {
    auto minus = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
    insn = emit_move_insn(sp, minus);
    RTX_FRAME_RELATED_P(insn) = true;
  }
}

void pdp11::expand_epilogue()
{
  auto sp = stack_pointer_rtx;
  auto fp = frame_pointer_rtx;
  emit_move_insn(sp, fp);
  auto pi = gen_rtx_POST_INC(Pmode, sp);
  auto mem = gen_rtx_MEM(Pmode, pi);
  emit_move_insn(fp, mem);
  emit_jump_insn(ret_rtx);
}

bool pdp11_function_value_regno_p(int regno)
{
  (void)regno;
  return false;
}

const char* pdp11::hi::mov(rtx x, rtx y)
{
  if (is_push(x) && REG_P(y))
    return "mov	%1, %0";
  if (REG_P(x) && REG_P(y))
    return "mov	%1, %0";
  if (REG_P(x) && is_pop(y))
    return "mov	%1, %0";
  if (is_push(x) && CONST_INT_P(y))
    return "mov	%1, %0";
  if (is_push(x) && SYMBOL_REF_P(y))
    return "mov	%1, %0";
  if (REG_P(x) && CONST_INT_P(y))
    return "mov	%1, %0";
  
  asm("int3");
  return "%0 := %1";
}

namespace pdp11 {
  namespace hi {
    void ld_fp(int regno, int offy)
    {
      auto fp = reg_names[FRAME_POINTER_REGNUM];
      auto rn = reg_names[regno];
      fprintf(asm_out_file, "	mov	%d(%s), %s\n", offy, fp, rn);
    }
    const char* common1(int regno, int offy, int offz, const char* insn)
    {
      ld_fp(regno, offy);
      auto fp = reg_names[FRAME_POINTER_REGNUM];
      auto rn = reg_names[regno];
      fprintf(asm_out_file, "	%s	%d(%s), %s\n", insn, offz, fp, rn);
      return "";
    }
  } // end of namespace hi
} // end of namespace pdp11

const char* pdp11::hi::add(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz))
    return common1(REGNO(x), offy, offz, "add");

  if (REG_P(x) && REG_P(y) && REGNO(x) == REGNO(y) && CONST_INT_P(z))
    return "add	%2, %0";
  
  asm("int3");
  return "%0 := %1 + %2";
}

const char* pdp11::hi::sub(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz))
    return common1(REGNO(x), offy, offz, "sub");

  if (REG_P(x) && REG_P(y) && REGNO(x) == REGNO(y) && CONST_INT_P(z))
    return "sub	%2, %0";

  asm("int3");  
  return "%0 := %1 - %2";
}

const char* pdp11::hi::mul(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r1
	mul 06(r5), r1
	mov r1, r0
   */
  return "%0 := %1 * %2";
}

const char* pdp11::hi::div(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r1
	sxt r0
	div 06(r5),r0
   */
  return "%0 := %1 / %2";
}

const char* pdp11::hi::mod(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	mov r0, r1
	sxt r0
	div 06(r5),r0
	mov r1, r0
   */
  return "%0 := %1 %% %2";
}
  
const char* pdp11::hi::ashl(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	ash 06(r5),r0
  */
  return "%0 := %1 << %2";
}
 
 
const char* pdp11::hi::ashr(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r1
	mov 06(r5), r0
	neg r0
	ash r0,r1
	mov r1, r0
  */
  return "%0 := %1 >> %2";
}
 
const char* pdp11::hi::lshr(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	mov r0, 0177776(r5)
	clr r0
	mov r0, 0177774(r5)
	mov 0177774(r5),r0
	mov 0177776(r5),r1
	clc
	ror r0
	ror r1
	mov r1, r0
  */
  return "%0 := %1 >>l %2";
}
 
const char* pdp11::hi::and_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	bic 06(r5), r0
   */
  return "%0 := %1 & %2";
}
 
const char* pdp11::hi::xor_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 06(r5), r0
	mov 04(r5), r1
	xor r1, r0
   */
  return "%0 := %1 ^ %2";
}

const char* pdp11::hi::ior(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	bis 06(r5), r0
   */
  return "%0 := %1 | %2";
}

const char* pdp11::hi::neg(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  /*
	mov 04(r5), r0
	neg r0
   */
  return "%0 := -%1";
}

const char* pdp11::hi::not_(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  /*
	mov 04(r5), r0
	com r0
   */
  return "%0 := ~%1";
}

const char* pdp11::si::mov(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  return "%0 := %1";
}
  
const char* pdp11::si::add(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	add 012(r5), r1
	adc r0
	add 010(r5), r0
   */
  return "%0 := %1 + %2";
}

const char* pdp11::si::sub(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	sub 012(r5), r1
	sbc r0
	sub 010(r5), r0
   */
  return "%0 := %1 - %2";
}
  
const char* pdp11::si::mul(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 0177774(r5),r0
	mov 0177776(r5),r1
	mul 012(r5), r0
	mov r0,0177774(r5)
	mov r1,0177776(r5)
	mov 06(r5), r0
	mov r0, 0177772(r5)
	clr r1
	mov r1, 0177770(r5)
	mov 0177770(r5),r0
	mov 0177772(r5),r1
	clc
	ror r0
	ror r1
	mov r0,0177764(r5)
	mov r1,0177766(r5)
	mov 0177766(r5), r1
	add 04(r5), r1
	mov r1, 0177766(r5)
	mov 012(r5), r0
	mov r0, 0177762(r5)
	clr r2
	mov r2, 0177760(r5)
	mov 0177760(r5),r0
	mov 0177762(r5),r1
	clc
	ror r0
	ror r1
	add 010(r5), r1
	mov 06(r5), r2
	mul r2, r1
	mov 0177774(r5), r0
	add r1, r0
	mov 012(r5), r1
	mov 0177766(r5), r2
	mul r2, r1
	add r1, r0
	mov r0, 0177774(r5)
	mov 0177774(r5),r0
	mov 0177776(r5),r1
   */
  return "%0 := %1 * %2";
}
  
const char* pdp11::si::ashl(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	ashc 010(r5),r0
   */
  return "%0 := %1 << %2";
}
  
const char* pdp11::si::ashr(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	mov 010(r5), r2
	neg r2
	ashc r2,r0
   */
  return "%0 := %1 >> %2";
}
  
const char* pdp11::si::lshr(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	clc
	ror r0
	ror r1
   */
  return "%0 := %1 >>l %2";
}
  
const char* pdp11::si::and_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	bic 012(r5), r1
	bic 010(r5), r0
   */
  return "%0 := %1 & %2";
}
  
 
const char* pdp11::si::xor_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r2
	mov 06(r5),r3
	mov 010(r5),r0
	mov 012(r5),r1
	xor r3, r1
	xor r2, r0
   */  
  return "%0 := %1 ^ %2";
}
  
const char* pdp11::si::ior(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	bis 012(r5), r1
	bis 010(r5), r0
   */
  return "%0 := %1 | %2";
}
 
const char* pdp11::si::neg(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  /*
	mov 04(r5),r0
	mov 06(r5),r1
	com r1
	com r0
	inc r1
	adc r0
   */
  return "%0 := -%1";
}
  
const char* pdp11::si::not_(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  /*
	mov 04(r5), r0
	com r0
	mov 06(r5), r1
	com r1
   */
  return "%0 := ~%1";
}
  
const char* pdp11::di::mov(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  return "%0 := %1";
}
  
const char* pdp11::di::add(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 0177776(r5), r0
	mov 0177766(r5), r1
	add r1, r0
	mov r0, 0177756(r5)
	mov $01, r0
	mov r0, 0177746(r5)
	mov 0177756(r5), r1
	mov 0177776(r5), r0
	cmp r1,r0
	blo L_2
	clr r1
	mov r1, 0177746(r5)
L_2:
	mov 0177774(r5), r0
	mov 0177764(r5), r1
	add r1, r0
	mov r0, 0177754(r5)
	mov $01, r0
	mov r0, 0177744(r5)
	mov 0177754(r5), r1
	mov 0177774(r5), r0
	cmp r1,r0
	blo L_3
	clr r1
	mov r1, 0177744(r5)
L_3:
	mov 0177746(r5), r0
	mov 0177754(r5), r1
	add r1, r0
	mov r0, 0177742(r5)
	mov $01, r0
	mov r0, 0177740(r5)
	mov 0177742(r5), r1
	mov 0177754(r5), r0
	cmp r1,r0
	blo L_4
	clr r1
	mov r1, 0177740(r5)
L_4:
	mov 0177744(r5), r0
	mov 0177740(r5), r1
	bis r1, r0
	mov r0, 0177744(r5)
	mov 0177742(r5), r0
	mov r0, 0177754(r5)
	mov 0177772(r5), r1
	mov 0177762(r5), r0
	add r0, r1
	mov r1, 0177752(r5)
	mov $01, r1
	mov r1, 0177736(r5)
	mov 0177752(r5), r0
	mov 0177772(r5), r1
	cmp r0,r1
	blo L_5
	clr r0
	mov r0, 0177736(r5)
L_5:
	mov 0177744(r5), r1
	mov 0177752(r5), r0
	add r0, r1
	mov r1, 0177734(r5)
	mov $01, r1
	mov r1, 0177732(r5)
	mov 0177734(r5), r0
	mov 0177752(r5), r1
	cmp r0,r1
	blo L_6
	clr r0
	mov r0, 0177732(r5)
L_6:
	mov 0177736(r5), r1
	mov 0177732(r5), r0
	bis r0, r1
	mov r1, 0177736(r5)
	mov 0177734(r5), r1
	mov r1, 0177752(r5)
	mov 0177770(r5), r0
	mov 0177760(r5), r1
	add r1, r0
	mov r0, 0177750(r5)
	mov 0177736(r5), r0
	mov 0177750(r5), r1
	add r1, r0
	mov r0, 0177750(r5)
	mov 04(r5), r0
   */
  return "%0 := %1 + %2";
}
  
const char* pdp11::di::sub(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 0177776(r5), r0
	mov 0177766(r5), r1
	sub r1, r0
	mov r0, 0177756(r5)
	mov $01, r0
	mov r0, 0177746(r5)
	mov 0177756(r5), r1
	mov 0177776(r5), r0
	cmp r1,r0
	bhi L_2
	clr r1
	mov r1, 0177746(r5)
L_2:
	mov 0177774(r5), r0
	mov 0177764(r5), r1
	sub r1, r0
	mov r0, 0177754(r5)
	mov $01, r0
	mov r0, 0177744(r5)
	mov 0177754(r5), r1
	mov 0177774(r5), r0
	cmp r1,r0
	bhi L_3
	clr r1
	mov r1, 0177744(r5)
L_3:
	mov 0177754(r5), r0
	mov 0177746(r5), r1
	sub r1, r0
	mov r0, 0177742(r5)
	mov $01, r0
	mov r0, 0177740(r5)
	mov 0177742(r5), r1
	mov 0177754(r5), r0
	cmp r1,r0
	bhi L_4
	clr r1
	mov r1, 0177740(r5)
L_4:
	mov 0177744(r5), r0
	mov 0177740(r5), r1
	bis r1, r0
	mov r0, 0177744(r5)
	mov 0177742(r5), r0
	mov r0, 0177754(r5)
	mov 0177772(r5), r1
	mov 0177762(r5), r0
	sub r0, r1
	mov r1, 0177752(r5)
	mov $01, r1
	mov r1, 0177736(r5)
	mov 0177752(r5), r0
	mov 0177772(r5), r1
	cmp r0,r1
	bhi L_5
	clr r0
	mov r0, 0177736(r5)
L_5:
	mov 0177752(r5), r1
	mov 0177744(r5), r0
	sub r0, r1
	mov r1, 0177734(r5)
	mov $01, r1
	mov r1, 0177732(r5)
	mov 0177734(r5), r0
	mov 0177752(r5), r1
	cmp r0,r1
	bhi L_6
	clr r0
	mov r0, 0177732(r5)
L_6:
	mov 0177736(r5), r1
	mov 0177732(r5), r0
	bis r0, r1
	mov r1, 0177736(r5)
	mov 0177734(r5), r1
	mov r1, 0177752(r5)
	mov 0177770(r5), r0
	mov 0177760(r5), r1
	sub r1, r0
	mov r0, 0177750(r5)
	mov 0177750(r5), r0
	mov 0177736(r5), r1
	sub r1, r0
	mov r0, 0177750(r5)
	mov 04(r5), r0
   */
  return "%0 := %1 - %2";
}
  
const char* pdp11::di::and_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	mov 06(r5), r1
	bic 016(r5), r1
	mov r1, (r0)
	mov 010(r5), r1
	bic 020(r5), r1
	mov r1, 02(r0)
	mov 012(r5), r1
	bic 022(r5), r1
	mov r1, 04(r0)
	mov 014(r5), r1
	bic 024(r5), r1
	mov r1, 06(r0)
   */
  return "%0 := %1 & %2";
}
  
const char* pdp11::di::xor_(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r1
	mov 016(r5), r0
	mov 06(r5), r2
	xor r0, r2
	mov r2, (r1)
	mov 020(r5), r0
	mov 010(r5), r2
	xor r0, r2
	mov r2, 02(r1)
	mov 022(r5), r0
	mov 012(r5), r2
	xor r0, r2
	mov r2, 04(r1)
	mov 024(r5), r0
	mov 014(r5), r2
	xor r0, r2
	mov r2, 06(r1)
	mov r1, r0
   */
  return "%0 := %1 ^ %2";
}
  
const char* pdp11::di::ior(rtx x, rtx y, rtx z)
{
  (void)x; (void)y; (void)z;
  asm("int3");
  /*
	mov 04(r5), r0
	mov 06(r5), r1
	bis 016(r5), r1
	mov r1, (r0)
	mov 010(r5), r1
	bis 020(r5), r1
	mov r1, 02(r0)
	mov 012(r5), r1
	bis 022(r5), r1
	mov r1, 04(r0)
	mov 014(r5), r1
	bis 024(r5), r1
	mov r1, 06(r0)
   */
  return "%0 := %1 | %2";
}
  
const char* pdp11::di::not_(rtx x, rtx y)
{
  (void)x; (void)y;
  asm("int3");
  /*
	mov 04(r5), r0
	mov 06(r5), r1
	com r1
	mov r1, (r0)
	mov 010(r5), r1
	com r1
	mov r1, 02(r0)
	mov 012(r5), r1
	com r1
	mov r1, 04(r0)
	mov 014(r5), r1
	com r1
	mov r1, 06(r0)
   */
  return "%0 := ~%1";
}

const char* pdp11::call(rtx fun)
{
  (void)fun;
  asm("int3");
  return "call %0";
}

const char* pdp11::call_value(rtx x, rtx fun)
{
  if (REG_P(x) && MEM_P(fun)) {
    int regno = REGNO(x);
    assert(regno == 0);
    return "jsr	pc, %1";
  }
  
  asm("int3");
  return "%0 := call %1";
}

void pdp11::emit_libcall(const char* name, rtx x, rtx y, rtx z)
{
  auto fun = gen_rtx_SYMBOL_REF(Pmode, name);
  auto xmode = GET_MODE(x);
  auto ymode = GET_MODE(y);
  if (!z) {
    emit_library_call_value(fun, x, LCT_NORMAL, xmode, y, ymode);
    return;
  }
  auto zmode = GET_MODE(z);
  if (zmode == E_VOIDmode)
    asm("int3");
  emit_library_call_value(fun, x, LCT_NORMAL, xmode, y, ymode, z, zmode);  
}

const char* pdp11::cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}
