#ifndef PDP11_PROTOS_H
#define PDP11_PROTOS_H

namespace pdp11 {
  void expand_prologue();
  void expand_epilogue();
  namespace hi {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
    const char* mul(rtx x, rtx y, rtx z);
    const char* div(rtx x, rtx y, rtx z);
    const char* mod(rtx x, rtx y, rtx z);
    const char* ashl(rtx x, rtx y, rtx z);
    const char* ashr(rtx x, rtx y, rtx z);
    const char* lshr(rtx x, rtx y, rtx z);    
    const char* and_(rtx x, rtx y, rtx z);
    const char* xor_(rtx x, rtx y, rtx z);
    const char* ior(rtx x, rtx y, rtx z);
    const char* neg(rtx x, rtx y);
    const char* not_(rtx x, rtx y);
  } // end of namespace hi
  namespace si {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
    const char* mul(rtx x, rtx y, rtx z);
    const char* ashl(rtx x, rtx y, rtx z);
    const char* ashr(rtx x, rtx y, rtx z);
    const char* lshr(rtx x, rtx y, rtx z);    
    const char* and_(rtx x, rtx y, rtx z);
    const char* xor_(rtx x, rtx y, rtx z);
    const char* ior(rtx x, rtx y, rtx z);    
    const char* neg(rtx x, rtx y);
    const char* not_(rtx x, rtx y);
  } // end of namespace si
  namespace di {
    const char* mov(rtx x, rtx y);
    const char* add(rtx x, rtx y, rtx z);
    const char* sub(rtx x, rtx y, rtx z);
    const char* and_(rtx x, rtx y, rtx z);
    const char* xor_(rtx x, rtx y, rtx z);
    const char* ior(rtx x, rtx y, rtx z);    
    const char* not_(rtx x, rtx y);
  } // end of namespace di
  const char* call(rtx fun);
  const char* call_value(rtx x, rtx fun);
  void emit_libcall(const char* name, rtx x, rtx y, rtx z);
  const char* cbranch(rtx op);  
} // end of namespace pdp11

#endif //  PDP11_PROTOS_H
