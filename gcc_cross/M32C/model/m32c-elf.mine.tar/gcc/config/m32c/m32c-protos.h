#ifndef M32C_PROTOS_H
#define M32C_PROTOS_H

void m32c_expand_prologue();
void m32c_expand_epilogue();

const char* m32c_enter(rtx);
const char* m32c_movhi(rtx x, rtx y);
const char* m32c_addhi3(rtx x, rtx y, rtx z);
const char* m32c_call_value(rtx x, rtx fun);
const char* m32c_pushhi1(rtx x);

const char* m32c_cbranch(rtx op);

#endif //  M32C_PROTOS_H
