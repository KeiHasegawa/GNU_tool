#ifndef BFIN_PROTOS_H
#define BFIN_PROTOS_H

void bfin_expand_prologue();
void bfin_expand_epilogue();
const char* bfin_movsi(rtx x, rtx y);
const char* bfin_addsi3(rtx x, rtx y, rtx z);
const char* bfin_call_value(rtx x, rtx fun);

const char* bfin_cbranch(rtx op);

#endif //  BFIN_PROTOS_H
