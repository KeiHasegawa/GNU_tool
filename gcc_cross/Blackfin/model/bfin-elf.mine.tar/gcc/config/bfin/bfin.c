#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx bfin_function_value(const_tree ret_type, const_tree, bool)
{
  return gen_rtx_REG(TYPE_MODE(ret_type), 0);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE bfin_function_value

bool bfin_legitimate_address_p(machine_mode mode, rtx x, bool strict)
{
  (void)mode; (void)strict;
  if (MEM_P(x))
    return false;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P bfin_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum, tree, rtx, tree, int)
{
  cum.nregs = cum.offset = 0;
}

void bfin_function_arg_advance(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 4) {
    ++cum->nregs;
    return;
  }
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE bfin_function_arg_advance

rtx bfin_function_incoming_arg(cumulative_args_t pcum_v,
			       const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 4)
    return gen_rtx_REG(arg.mode, cum->nregs);
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG bfin_function_incoming_arg

rtx bfin_function_arg(cumulative_args_t pcum_v, const function_arg_info& arg)
{
  return bfin_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG bfin_function_arg

#undef TARGET_LRA_P
#define TARGET_LRA_P hook_bool_void_false

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.globl	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  return 0 <= regno && regno <= 2;
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  if (regno < STACK_POINTER_REGNUM)
    return R0_13;

  if (FRAME_POINTER_REGNUM < regno && regno < RETS_REGNUM)
    return UNUSED_REGS;
  
  switch (regno) {
  case STACK_POINTER_REGNUM: return SP_REGS;
  case FRAME_POINTER_REGNUM: return FP_REGS;
  case RETS_REGNUM: return RETS_REGS;
  case ARG_POINTER_REGNUM: return AP_REGS;
  default: abort();
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree)
{
  return 0;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  /*
    +----------------+ <- sp
    |                |
    |                |
    |   local area   |
    |                |
    |                |
    +----------------+ <- fp
    |    fp_{old}    |
    +----------------+ 
    |   rets_{old}   |
    +----------------+ <- ap
    |   1st argument |
    +----------------+
    |   2nd argument |
    +----------------+
    |   ...........  |
    +----------------+
  */
  offset = 0;
  if (from == ARG_POINTER_REGNUM)
    offset = 8;
  if (to == STACK_POINTER_REGNUM)
    offset += get_frame_size();
}

inline char binop(rtx x)
{
  assert(GET_CODE (x) == PLUS);
  return '+';
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == FRAME_POINTER_REGNUM;
}

inline void load(int regno, int offset)
{
  auto r = reg_names[regno];
  auto fp = reg_names[FRAME_POINTER_REGNUM];
  fprintf(asm_out_file, "	%s = [%s+%d]\n", r, fp, offset);
}

inline void store(int regno, int offset)
{
  auto r = reg_names[regno];
  auto fp = reg_names[FRAME_POINTER_REGNUM];
  fprintf(asm_out_file, "	[%s+%d] = %s\n", fp, offset, r);
}

const char* bfin_movsi(rtx x, rtx y)
{
  if (REG_P(x) && SYMBOL_REF_P(y)) {
    int no = REGNO(x);
    auto r = reg_names[no];
    auto s = XSTR(y, 0);
    assert(*s == '*');
    ++s;
    fprintf(asm_out_file, "	%s.H = %s\n", r, s);
    fprintf(asm_out_file, "	%s.L = %s\n", r, s);
    return "";
  }

  int offx, offy;
  if (fp_rel(x, &offx) && fp_rel(y, &offy)) {
    int scratch = 3;
    load(scratch, offy);
    store(scratch, offx);
    return "";
  }

  if (fp_rel(x, &offx) && CONST_INT_P(y)) {
    int scratch = 3;
    auto r = reg_names[scratch];
    auto v = INTVAL(y);
    fprintf(asm_out_file, "	%s = %lld\n", r, v);
    store(v, offx);
    return "";
  }

  return "%0 = %1";
}

void bfin_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    auto no = REGNO(x);
    fprintf(fp, "%s", reg_names[no]);
    return;
  }
  if (CONST_INT_P(x)) {
    fprintf(fp, HOST_WIDE_INT_PRINT_DEC, INTVAL(x));
    return;
  }
  if (MEM_P(x)) {
    auto e0 = XEXP(x, 0);
    bool paren = !SYMBOL_REF_P(e0);
    if (paren)
      fprintf(fp, "[");
    bfin_print_operand(fp, e0, 0);
    if (paren)
      fprintf(fp, "]");
    return;
  }
  if (SYMBOL_REF_P(x)) {
    auto s0 = XSTR(x, 0);
    fprintf(fp, "_%s", s0);
    return;
  }
  if (BINARY_P(x)) {
    auto e0 = XEXP(x, 0);
    bfin_print_operand(fp, e0, 0);
    fprintf(fp, "%c", binop(x));
    auto e1 = XEXP(x, 1);
    bfin_print_operand(fp, e1, 0);
    return;
  }
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void bfin_expand_prologue()
{
  auto size = get_frame_size();
  auto out = crtl->outgoing_args_size;
  size += out;
  auto tmp = gen_rtx_CONST_INT(Pmode, size);
  auto insn = gen_link(tmp);
  insn = emit_insn(insn);
  RTX_FRAME_RELATED_P(insn) = true;
  auto N = XVECLEN(PATTERN(insn), 0);
  assert(N == 4);
  for (int i = 0 ; i != N ; ++i) {
    auto tmp = XVECEXP(PATTERN (insn), 0, i);
    assert(GET_CODE(tmp) == SET);
    RTX_FRAME_RELATED_P(tmp) = true;
  }
}

void bfin_expand_epilogue()
{
  auto insn = gen_unlink();
  emit_insn(insn);
  emit_jump_insn(ret_rtx);
}

const char* bfin_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}

bool bfin_function_value_regno_p(int regno)
{
  (void)regno;
  abort();
}

const char* bfin_addsi3(rtx x, rtx y, rtx z)
{
  int offx, offy, offz;
  if (fp_rel(x, &offx) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int scratch0 = 3;
    load(scratch0, offy);
    int scratch1 = 4;
    load(scratch1, offz);
    auto d = reg_names[scratch0];
    auto s = reg_names[scratch1];
    fprintf(asm_out_file, "	%s = %s + %s\n", d, d, s);
    store(scratch0, offx);
    return "";
  }

  return "%0 := %1 + %2";
}

const char* bfin_call_value(rtx x, rtx fun)
{
  if (REG_P(x) && REGNO(x) == 0 && MEM_P(fun))
    return "call	%1";

  return "%0 := call %1";
}

