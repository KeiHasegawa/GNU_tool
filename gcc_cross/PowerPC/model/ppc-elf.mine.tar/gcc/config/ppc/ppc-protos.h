#ifndef PPC_PROTOS_H
#define PPC_PROTOS_H

void ppc_expand_prologue();
void ppc_expand_epilogue();

const char* ppc_movsi(rtx x, rtx y);
const char* ppc_addsi3(rtx x, rtx y, rtx z);
const char* ppc_subsi3(rtx x, rtx y, rtx z);
const char* ppc_call_value(rtx x, rtx fun);

const char* ppc_cbranch(rtx op);
#endif //  PPC_PROTOS_H
