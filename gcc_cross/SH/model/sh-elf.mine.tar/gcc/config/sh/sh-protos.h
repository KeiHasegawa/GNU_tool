#ifndef SH_PROTOS_H
#define SH_PROTOS_H

void sh_expand_prologue();
void sh_expand_epilogue();

const char* sh_movsi(rtx x, rtx y);
const char* sh_subsi3(rtx x, rtx y, rtx z);
const char* sh_addsi3(rtx x, rtx y, rtx z);
const char* sh_call_value(rtx x, rtx fun);

const char* sh_cbranch(rtx op);
#endif //  SH_PROTOS_H
