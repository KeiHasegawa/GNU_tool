#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>

rtx m68hc11_function_value(const_tree ret_type, const_tree, bool)
{
  auto mode = TYPE_MODE(ret_type);
  if (mode == BLKmode)
    return gen_rtx_REG(mode, D_REGNUM);

  auto size = GET_MODE_SIZE(mode);
  if (size <= 2)
    return gen_rtx_REG(mode, D_REGNUM);

  return gen_rtx_REG(mode, X_REGNUM);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE m68hc11_function_value

bool m68hc11_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  // (gdb) p debug_rtx(mem);
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P m68hc11_legitimate_address_p

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum,
			  tree fntype, rtx libname,
			  tree fndecl, int)
{
  (void)fndecl;
  cum.words = 0;
  cum.nregs = 0;

  if (!fntype) {
    // For library call
    if (!libname || GET_CODE(libname) != SYMBOL_REF)
      return;
    auto name = XSTR(libname, 0);
    int len = strlen(name);
    if (len < 4)
      return;
    if (name[len - 2] == 'd') {
      if (name[len - 1] == 'f' || name[len - 1] == 'i')
	cum.words = cum.nregs = 1;
      return;
    }

    if (name[len - 3] == 'd') {
      if (name[len - 2] == 'i' || name[len - 2] == 'f')
	cum.words = cum.nregs = 1;
      return;
    }
    return;
  }

  auto ret_type = TREE_TYPE(fntype);
  assert(ret_type);

  if (!aggregate_value_p(ret_type, fntype))
    return;

  cum.words = 1;
  cum.nregs = 1;
}

void m68hc11_function_arg_advance(cumulative_args_t pcum_v,
				   const function_arg_info &arg)
{
  auto mode = arg.mode;
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (mode == BLKmode) {
    cum->words += int_size_in_bytes(arg.type);
    return;
  }

  auto size = GET_MODE_SIZE (mode);
  if (cum->words == 0 && size == 4) {
    cum->words = size;
    cum->nregs = 2;
    return;
  }

  cum->words += size;
  if (cum->words <= UNITS_PER_WORD)
    cum->nregs = 1;
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE m68hc11_function_arg_advance

rtx m68hc11_function_incoming_arg(cumulative_args_t pcum_v,
				  const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->words)
    return nullptr;

  auto mode = arg.mode;
  if (mode == BLKmode)
    return nullptr;

  auto size = GET_MODE_SIZE(mode);
  if (size == 2 * UNITS_PER_WORD)
    return gen_rtx_REG(mode, X_REGNUM);

  if (size > UNITS_PER_WORD)
    return nullptr;
  return gen_rtx_REG(mode, D_REGNUM);
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG m68hc11_function_incoming_arg

rtx m68hc11_function_arg(cumulative_args_t pcum_v,
			 const function_arg_info& arg)
{
  return m68hc11_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG m68hc11_function_arg

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == FRAME_POINTER_REGNUM;
}

HOST_WIDE_INT m68hc11_starting_frame_offset()
{
  return 1;
}

#undef  TARGET_STARTING_FRAME_OFFSET
#define TARGET_STARTING_FRAME_OFFSET m68hc11_starting_frame_offset

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.globl	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  switch (regno) {
  case D_REGNUM: case X_REGNUM: return true;
  default: return false;
  }
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  asm("int3");
  return regno == D_REGNUM;
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case X_REGNUM: return X_REGS;
  case D_REGNUM: return D_REGS;
  case Y_REGNUM: return Y_REGS;
  case STACK_POINTER_REGNUM: return SP_REGS;
  case PC_REGNUM: return PC_REGS;
  case A_REGNUM: return A_REGS;
  case B_REGNUM: return B_REGS;
  case CCR_REGNUM: return CCR_REGS;
  case Z_REGNUM: return Z_REGS;
  case FRAME_POINTER_REGNUM: return FP_REGS;
  case DUMMY_REGNUM: return DUMMY_REGS;
  default: abort();
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree func)
{
  (void)func;
  return 9;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  assert(from == FRAME_POINTER_REGNUM);
  assert(to == STACK_POINTER_REGNUM);
  offset = 0;
}

void m68hc11_print_operand(FILE* fp, rtx x, int)
{
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

inline bool is_push(rtx x)
{
  if (!MEM_P(x))
    return false;
  if (GET_MODE(x) != HImode)
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) != PRE_DEC)
    return false;
  if (GET_MODE(y) != HImode)
    return false;
  auto z = XEXP(y, 0);
  if (!REG_P(z))
    return false;
  if (REGNO(z) != STACK_POINTER_REGNUM)
    return false;
  return true;
}

inline void gen_push(rtx x)
{
  assert(REG_P(x));
  auto sp = stack_pointer_rtx;
  auto pd = gen_rtx_PRE_DEC(HImode, sp);
  auto mem = gen_rtx_MEM(Pmode, pd);
  assert(is_push(mem));
  auto insn = emit_move_insn(mem, x);
  RTX_FRAME_RELATED_P(insn) = true;
}

void m68hc11_expand_prologue()
{
  // x := *_.frame
  auto fp = frame_pointer_rtx;
  auto x = gen_rtx_REG(HImode, Y_REGNUM);
  emit_move_insn(x, fp);

  gen_push(x);

  struct last {
    ~last()
    {
      // *_.frame := sp
      auto fp = frame_pointer_rtx;
      auto sp = stack_pointer_rtx;
      emit_move_insn(fp, sp);
    }
  } last; 

  auto size = get_frame_size();
  if (!size)
    return;

  if (size <= 10 && !(size & 1)) {
    int n = size >> 1;
    while (n--)
      gen_push(x);
    return;
  }
  
  // sp := sp - size
  auto sp = stack_pointer_rtx;
  auto tmp = gen_rtx_MINUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
  auto insn = emit_move_insn(sp, tmp);
  RTX_FRAME_RELATED_P(insn) = true;
}

inline bool is_pop(rtx x)
{
  if (!MEM_P(x))
    return false;
  if (GET_MODE(x) != HImode)
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) != POST_INC)
    return false;
  if (GET_MODE(y) != HImode)
    return false;
  auto z = XEXP(y, 0);
  if (!REG_P(z))
    return false;
  if (REGNO(z) != STACK_POINTER_REGNUM)
    return false;
  return true;
}

inline void gen_pop(rtx x)
{
  auto sp = stack_pointer_rtx;
  auto pi = gen_rtx_POST_INC(HImode, sp);
  auto mem = gen_rtx_MEM(HImode, pi);
  assert(is_pop(mem));
  emit_move_insn(x, mem);
}

void m68hc11_expand_epilogue()
{
  auto y = gen_rtx_REG(HImode, Y_REGNUM);

  if (auto size = get_frame_size()) {
    if (size <= 10 && !(size & 1)) {
      int n = size >> 1;
      while (n--)
	gen_pop(y);
    }
    else {
      // sp := sp + size
      auto sp = stack_pointer_rtx;
      auto tmp = gen_rtx_PLUS(Pmode, sp, gen_rtx_CONST_INT(Pmode, size));
      emit_move_insn(sp, tmp);
    }
  }

  gen_pop(y);

  // fp := y
  auto fp = frame_pointer_rtx;
  emit_move_insn(fp, y);
  
  emit_jump_insn(ret_rtx);
}

inline bool d_sp(rtx x, rtx y)
{
  if (REG_P(x) && REGNO(x) == D_REGNUM) {
    if (REG_P(y) && REGNO(y) == STACK_POINTER_REGNUM)
      return true;
  }
  return false;
}

inline bool x_sp(rtx x, rtx y)
{
  if (REG_P(x) && REGNO(x) == X_REGNUM) {
    if (REG_P(y) && REGNO(y) == STACK_POINTER_REGNUM)
      return true;
  }
  return false;
}

const char* m68hc11_movhi(rtx x, rtx y)
{
  if (REG_P(y) && REGNO(y) == FRAME_POINTER_REGNUM) {
    if (REG_P(x)) {
      switch (REGNO(x)) {
      case X_REGNUM: return "ldx	*_.frame";
      case Y_REGNUM: return "ldy	*_.frame";
      }
    }
  }
  if (is_push(x)) {
    if (REG_P(y)) {
      switch (REGNO(y)) {
      case X_REGNUM: return "pshx";
      case Y_REGNUM: return "pshy";
      }
    }
  }
  if (REG_P(x) && REGNO(x) == FRAME_POINTER_REGNUM) {
    if (REG_P(y)) {
      switch (REGNO(y)) {
      case X_REGNUM:             return "stx	*_.frame";
      case Y_REGNUM:             return "sty	*_.frame";
      case STACK_POINTER_REGNUM: return "sts	*_.frame";
      }
    }
  }
  if (is_pop(y)) {
    if (REG_P(x)) {
      switch (REGNO(x)) {
      case X_REGNUM: return "pulx";
      case Y_REGNUM: return "puly";
      }
    }
  }

  int offset;
  if (fp_rel(x, &offset)) {
    if (REG_P(y) && REGNO(y) == X_REGNUM) {
      fprintf(asm_out_file, "	ldy	*_.frame\n");
      fprintf(asm_out_file, "	stx	%d, y\n", offset);
      return "";      
    }
    if (REG_P(y) && REGNO(y) == D_REGNUM) {
      fprintf(asm_out_file, "	ldy	*_.frame\n");
      fprintf(asm_out_file, "	std	%d, y\n", offset);
      return "";      
    }
    if (REG_P(y) && REGNO(y) == STACK_POINTER_REGNUM) {
      fprintf(asm_out_file, "	ldy	*_.frame\n");
      fprintf(asm_out_file, "	tsx\n");
      fprintf(asm_out_file, "	stx	%d, y\n", offset);
      return "";      
    }
  }
  if (REG_P(x) && SYMBOL_REF_P(y)) {
    auto decl = SYMBOL_REF_DECL(y);
    assert(decl);
    auto name = DECL_NAME(decl);
    auto id = IDENTIFIER_POINTER(name);
    assert(*id == '*');
    switch (REGNO(x)) {
    case D_REGNUM:
      fprintf(asm_out_file, "	ldd	#%s\n", id+1);
      return "";
    default:
      abort();
    }
  }
  if (d_sp(x, y)) {
    // d := sp
    fprintf(asm_out_file, "	tsy\n");
    fprintf(asm_out_file, "	xgdy\n");
    // At this point, d is equal to sp + 1 but 
    //  	addd	#-1
    // is not necessary. See the part of `ptr_d'
    return "";
  }
  if (x_sp(x, y)) {
    fprintf(asm_out_file, "	tsx\n");
    // At this point, x is equal to sp + 1 but 
    //  	xgdx
    //  	addd	#-1
    //  	xgdx
    // is not necessary. See the part of `ptr_x'
    return "";
  }
  asm("int3");
  return "%0 := %1";
}

namespace m68hc11_impl {
  inline const char* update_sp(rtx x, rtx y, rtx z, bool add)
  {
    assert(REG_P(x) && REGNO(x) == STACK_POINTER_REGNUM);
    assert(REG_P(y) && REGNO(y) == STACK_POINTER_REGNUM);
    assert(CONST_INT_P(z));
    auto size = INTVAL(z);
    fprintf(asm_out_file, "	tsy\n");
    fprintf(asm_out_file, "	xgdy\n");
    if (add)
      fprintf(asm_out_file, "	addd	#%lld\n", size);
    else
      fprintf(asm_out_file, "	addd	#-%lld\n", size);
    fprintf(asm_out_file, "	xgdy\n");  
    fprintf(asm_out_file, "	tys\n");
    return "";
  }
} // end of namespace m68hc11_impl

const char* m68hc11_subhi3(rtx x, rtx y, rtx z)
{
  return m68hc11_impl::update_sp(x, y, z, false);
}

const char* m68hc11_addhi3(rtx x, rtx y, rtx z)
{
  return m68hc11_impl::update_sp(x, y, z, true);
}

bool m68hc11_expand_movsi(rtx x, rtx y)
{
  if (REG_P(y) && REGNO(y) == X_REGNUM && MEM_P(x)) {
    auto addr = XEXP(x, 0);
    auto hi = gen_rtx_MEM(HImode, addr);
    auto xr = gen_rtx_REG(HImode, X_REGNUM);
    emit_insn(gen_rtx_SET(hi, xr));
    auto lo_addr = gen_rtx_PLUS(Pmode, addr, gen_rtx_CONST_INT(Pmode, 2));
    auto lo = gen_rtx_MEM(HImode, lo_addr);
    auto dr = gen_rtx_REG(HImode, D_REGNUM);    
    emit_insn(gen_rtx_SET(lo, dr));
    return true;
  }
  if (MEM_P(x) && MEM_P(y)) {
    asm("int3");
  }
  return false;
}

inline void load(int regno, int offset)
{
  fprintf(asm_out_file, "	ldy	*_.frame\n");
  assert(regno == D_REGNUM);
  fprintf(asm_out_file, "	ldx	%d, y\n", offset);
  fprintf(asm_out_file, "	ldd	%d, y\n", offset+2);
}

inline void add(int regno, int offset)
{
  assert(regno == D_REGNUM);
  fprintf(asm_out_file, "	addd	%d, y\n", offset+2);
  fprintf(asm_out_file, "	xgdx\n");
  fprintf(asm_out_file, "	adcb	%d, y\n", offset+2);
  fprintf(asm_out_file, "	adca	%d, y\n", offset);
  fprintf(asm_out_file, "	xgdx\n");
}

const char* m68hc11_addsi3(rtx x, rtx y, rtx z)
{
  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    int regno = REGNO(x);
    load(regno, offy);
    add(regno, offz);
    return "";
  }
  asm("int3");
  return "%0 := %1 + %2";
}

inline bool ptr_d(rtx x)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (!REG_P(y))
    return false;
  return REGNO(y) == D_REGNUM;
}

inline bool ptr_x(rtx x)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (!REG_P(y))
    return false;
  return REGNO(y) == X_REGNUM;
}

const char* m68hc11_movsi(rtx x, rtx y)
{
  if (REG_P(x) && REGNO(x) == X_REGNUM) {
    if (REG_P(y) && REGNO(y) == D_REGNUM)
      return "";
  }
  if (REG_P(x) && REGNO(x) == D_REGNUM && CONST_INT_P(y)) {
    auto v = INTVAL(y);
    if (!v) {
      fprintf(asm_out_file, "	ldx	#0\n");
      fprintf(asm_out_file, "	clra\n");
      fprintf(asm_out_file, "	clrb\n");
      return "";
    }
  }
  if (ptr_d(x) && CONST_INT_P(y)) {
    uint32_t v = INTVAL(y);
    uint32_t hi = v >> 16;
    fprintf(asm_out_file, "	xgdy\n");
    fprintf(asm_out_file, "	ldd	#%d\n", hi);
    fprintf(asm_out_file, "	std	0,y\n");
    uint16_t lo = v;
    fprintf(asm_out_file, "	ldd	#%d\n", lo);
    fprintf(asm_out_file, "	std	2,y\n");
    return "";
  }
  if (ptr_x(x) && CONST_INT_P(y)) {
    uint32_t v = INTVAL(y);
    uint32_t hi = v >> 16;
    fprintf(asm_out_file, "	ldd	#%d\n", hi);
    fprintf(asm_out_file, "	std	0,x\n");
    uint16_t lo = v;
    fprintf(asm_out_file, "	ldd	#%d\n", lo);
    fprintf(asm_out_file, "	std	2,x\n");
    return "";
  }
  if (REG_P(x) && REGNO(x) == X_REGNUM && CONST_INT_P(y)) {
    uint32_t v = INTVAL(y);
    uint32_t hi = v >> 16;
    fprintf(asm_out_file, "	ldd	#%d\n", hi);
    fprintf(asm_out_file, "	xgdx\n");
    uint16_t lo = v;
    fprintf(asm_out_file, "	ldd	#%d\n", lo);
    return "";
  }
  int offset;
  if (fp_rel(x, &offset) && REG_P(y) && REGNO(y) == X_REGNUM) {
    fprintf(asm_out_file, "	ldy	*_.frame\n");
    fprintf(asm_out_file, "	stx	%d, y\n", offset);
    fprintf(asm_out_file, "	std	%d, y\n", offset+2);
    return "";
  }
  if (ptr_x(x) && fp_rel(y, &offset)) {
    fprintf(asm_out_file, "	ldy	*_.frame\n");
    fprintf(asm_out_file, "	ldd	%d, y\n", offset);
    fprintf(asm_out_file, "	std	0, x\n");
    fprintf(asm_out_file, "	ldd	%d, y\n", offset+2);
    fprintf(asm_out_file, "	std	2, x\n");
    return "";
  }
  if (ptr_d(x) && fp_rel(y, &offset)) {
    asm("int3");
    return "%0 := %1";
  }
  
  asm("int3");
  return "%0 := %1";
}

const char* m68hc11_call_value(rtx x, rtx fun)
{
  if (MEM_P(fun)) {
    auto y = XEXP(fun, 0);
    assert(SYMBOL_REF_P(y));
    auto z = XSTR(y, 0);
    fprintf(asm_out_file, "	bsr	%s\n", z);
    assert(REG_P(x) && REGNO(x) == X_REGNUM);
    return "";
  }
  asm("int3");
  return "%0 := call %1";
}

const char* m68hc11_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}
