#ifndef HASEGAWA_PROTOS_H
#define HASEGAWA_PROTOS_H

void m68hc11_expand_prologue();
void m68hc11_expand_epilogue();
const char* m68hc11_movhi(rtx x, rtx y);
const char* m68hc11_cbranch(rtx op);
const char* m68hc11_subhi3(rtx x, rtx y, rtx z);
const char* m68hc11_addhi3(rtx x, rtx y, rtx z);
bool m68hc11_expand_movsi(rtx x, rtx y);
const char* m68hc11_addsi3(rtx x, rtx y, rtx z);
const char* m68hc11_movsi(rtx x, rtx y);
const char* m68hc11_call_value(rtx x, rtx fun);

#endif //  HASEGAWA_PROTOS_H
