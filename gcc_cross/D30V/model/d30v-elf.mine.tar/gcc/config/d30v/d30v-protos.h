#ifndef D30V_PROTOS_H
#define D30V_PROTOS_H

void d30v_expand_prologue();
const char* d30v_movsi(rtx x, rtx y);
const char* d30v_subsi3(rtx x, rtx y, rtx z);

void d30v_expand_epilogue();
const char* d30v_addsi3(rtx x, rtx y, rtx z);

const char* d30v_call_value(rtx x, rtx fun);

const char* d30v_cbranch(rtx op);

#endif //  D30V_PROTOS_H
