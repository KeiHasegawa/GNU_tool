#ifndef RX_PROTOS_H
#define RX_PROTOS_H

void rx_expand_prologue();
void rx_expand_epilogue();

const char* rx_movsi(rtx x, rtx y);
const char* rx_subsi3(rtx x, rtx y, rtx z);
const char* rx_addsi3(rtx x, rtx y, rtx z);
const char* rx_call_value(rtx x, rtx fun);

const char* rx_cbranch(rtx op);

#endif //  RX_PROTOS_H
