#define IN_TARGET_CODE 1

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "hash-table.h"
#include "tm.h"
#include "rtl.h"
#include "hash-set.h"
#include "machmode.h"
#include "vec.h"
#include "double-int.h"
#include "input.h"
#include "alias.h"
#include "symtab.h"
#include "wide-int.h"
#include "inchash.h"
#include "tree.h"
#include "fold-const.h"
#include "stringpool.h"
#include "stor-layout.h"
#include "calls.h"
#include "varasm.h"
#include "obstack.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "insn-config.h"
#include "conditions.h"
#include "output.h"
#include "insn-attr.h"
#include "flags.h"
#include "reload.h"
#include "function.h"
#include "hashtab.h"
#include "statistics.h"
#include "real.h"
#include "fixed-value.h"
#include "expmed.h"
#include "profile-count.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "optabs.h"
#include "diagnostic-core.h"
#include "recog.h"
#include "predict.h"
#include "dominance.h"
#include "cfg.h"
#include "cfgrtl.h"
#include "cfganal.h"
#include "lcm.h"
#include "cfgbuild.h"
#include "cfgcleanup.h"
#include "basic-block.h"
#include "hash-map.h"
#include "is-a.h"
#include "plugin-api.h"
#include "ipa-ref.h"
#include "cgraph.h"
#include "ggc.h"
#include "except.h"
#include "tm_p.h"
#include "target.h"
#include "sched-int.h"
#include "attribs.h"
#include "target-def.h"
#include "debug.h"
#include "langhooks.h"
#include "bitmap.h"
#include "df.h"
#include "intl.h"
#include "libfuncs.h"
#include "opts.h"
#include "dumpfile.h"
#include "gimple-expr.h"
#include "builtins.h"
#include "tm-constrs.h"
#include "rtl-iter.h"
#include "sched-int.h"
#include "print-rtl.h"
#include <cassert>
#include <vector>
#include <string>
#include <map>
#include <sstream>

rtx arm_function_value(const_tree ret_type, const_tree, bool)
{
  return gen_rtx_REG(TYPE_MODE(ret_type), R0_REGNUM);
}

#undef TARGET_FUNCTION_VALUE
#define TARGET_FUNCTION_VALUE arm_function_value

bool arm_legitimate_address_p(machine_mode mode, rtx mem, bool strict)
{
  (void)mode;
  (void)mem;
  (void)strict;
  return true;
}

void INIT_CUMULATIVE_ARGS(CUMULATIVE_ARGS& cum, tree fntype, rtx,
			  tree fndecl, int)
{
  (void)fntype;
  (void)fndecl;
  cum.words = cum.nregs = 0;
}

#undef TARGET_LEGITIMATE_ADDRESS_P
#define TARGET_LEGITIMATE_ADDRESS_P arm_legitimate_address_p


void arm_function_arg_advance(cumulative_args_t pcum_v,
			      const function_arg_info &arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 4) {
    ++cum->nregs;
    return;
  }
  (void)arg;
  abort();
}

#undef TARGET_FUNCTION_ARG_ADVANCE
#define TARGET_FUNCTION_ARG_ADVANCE arm_function_arg_advance

rtx arm_function_incoming_arg(cumulative_args_t pcum_v,
			      const function_arg_info& arg)
{
  auto cum = reinterpret_cast<CUMULATIVE_ARGS*>(pcum_v.p);
  if (cum->nregs < 4)
    return gen_rtx_REG(arg.mode, cum->nregs);
  (void)arg;
  abort();
  return nullptr;
}

#undef TARGET_FUNCTION_INCOMING_ARG
#define TARGET_FUNCTION_INCOMING_ARG arm_function_incoming_arg

rtx arm_function_arg(cumulative_args_t pcum_v, function_arg_info const& arg)
{
  return arm_function_incoming_arg(pcum_v, arg);
}

#undef TARGET_FUNCTION_ARG
#define TARGET_FUNCTION_ARG arm_function_arg

std::map<std::string, rtx> sym_ref;

inline void output(FILE* fp, std::string label, rtx sym)
{
  fprintf(fp, "%s:\n", label.c_str());
  fprintf(fp, "	.word	");
  arm_print_operand(fp, sym, 0);
  fputc('\n', fp);
}

void arm_function_pro_epilogue(FILE* fp)
{
  ASM_OUTPUT_ALIGN(fp, 2);
  for (auto p : sym_ref)
    output(fp, p.first, p.second);
  sym_ref.clear();
}

#undef TARGET_ASM_FUNCTION_EPILOGUE
#define TARGET_ASM_FUNCTION_EPILOGUE arm_function_pro_epilogue

gcc_target targetm = TARGET_INITIALIZER;

void default_globalize_label(FILE* fp, const char* name)
{
  fputs("	.globl	", fp);
  assemble_name(fp, name);
  putc('\n', fp);
}

bool FUNCTION_ARG_REGNO_P(int regno)
{
  switch (regno) {
  case R0_REGNUM: case R1_REGNUM: return true;
  default: return false;
  }
}

bool REGNO_OK_FOR_BASE_P(int regno)
{
  (void)regno;
  abort();
}

reg_class REGNO_REG_CLASS(int regno)
{
  switch (regno) {
  case R0_REGNUM: return R0_REGS;
  case R1_REGNUM: return R1_REGS;
  case R2_REGNUM: return R2_REGS;
  case R3_REGNUM: return R3_REGS;
  case R4_REGNUM: return R4_REGS;
  case R5_REGNUM: return R5_REGS;
  case R6_REGNUM: return R6_REGS;
  case R7_REGNUM: return R7_REGS;
  case R8_REGNUM: return R8_REGS;
  case R9_REGNUM: return R9_REGS;
  case R10_REGNUM: return R10_REGS;
  case FRAME_POINTER_REGNUM: return FP_REGS;
  case IP_REGNUM: return IP_REGS;
  case STACK_POINTER_REGNUM: return SP_REGS;
  case LR_REGNUM: return LR_REGS;
  case PC_REGNUM: return PC_REGS;
  default: abort();
  }
}

void ASM_OUTPUT_ALIGN(FILE* fp, int n)
{
  fprintf(fp, "	.align	%d\n", n);
}

int FIRST_PARM_OFFSET(tree)
{
  return 0;
}

void FUNCTION_PROFILER(FILE* fp, int labelno)
{
  fprintf(fp, "	ldy	.LP%d\n", labelno);
  fprintf(fp, "	jsr mcount\n");
}

bool REGNO_OK_FOR_INDEX_P(int regno)
{
  (void)regno;
  abort();
}

void INITIAL_ELIMINATION_OFFSET(int from, int to, poly_int64_pod& offset)
{
  long long int tmp = to - from;
  offset = tmp;
}

inline bool fp_rel(rtx x, int* offset)
{
  if (!MEM_P(x))
    return false;
  auto y = XEXP(x, 0);
  if (GET_CODE(y) == PLUS) {
    auto z = XEXP(y, 1);
    if (!CONST_INT_P(z))
      return false;
    *offset = INTVAL(z);
    y = XEXP(y, 0);
  }
  else
    *offset = 0;
  if (!REG_P(y))
    return false;
  return REGNO(y) == FRAME_POINTER_REGNUM;
}

void arm_print_operand(FILE* fp, rtx x, int)
{
  if (REG_P(x)) {
    int regno = REGNO(x);
    return (void)fprintf(fp, "%s", reg_names[regno]);
  }

  if (CONST_INT_P(x)) {
    auto v = INTVAL(x);
    return (void)fprintf(fp, "%lld", v);
  }

  int offset;
  if (fp_rel(x, &offset))
    return (void)fprintf(fp, "[fp, #%d]", offset);

  if (SYMBOL_REF_P(x)) {
    auto decl = SYMBOL_REF_DECL(x);
    assert(decl);
    auto name = DECL_NAME(decl);
    auto id = IDENTIFIER_POINTER(name);
    assert(*id == '*');
    return (void)fprintf(asm_out_file, "%s", id+1);
  }
  
  rtx_writer w(fp, 0, false, false, NULL);
  w.print_rtx(x);
}

void arm_expand_prologue()
{
  auto fp = frame_pointer_rtx;
  auto lr = gen_rtx_REG(SImode, LR_REGNUM);
  auto insn = emit_insn(gen_arm_push(fp, lr));
  RTX_FRAME_RELATED_P(insn) = true;

  auto sp = stack_pointer_rtx;
  auto size = get_frame_size();
  if (size) {
    // sp := sp - size
    auto tmp = gen_rtx_MINUS(SImode, sp, GEN_INT(size));
    insn = emit_move_insn(sp, tmp);
    RTX_FRAME_RELATED_P(insn) = true;
  }

  // fp := sp
  emit_move_insn(fp, sp);
}

void arm_expand_epilogue()
{
  auto sp = stack_pointer_rtx;
  auto size = get_frame_size();
  if (size) {
    // sp := sp + size
    auto tmp = gen_rtx_PLUS(SImode, sp, GEN_INT(size));
    auto insn = emit_move_insn(sp, tmp);
    RTX_FRAME_RELATED_P(insn) = true;
  }

  auto fp = frame_pointer_rtx;
  auto pc = gen_rtx_REG(SImode, PC_REGNUM);
  auto insn = emit_insn(gen_arm_pop(fp, pc));
  RTX_FRAME_RELATED_P(insn) = true;
}

inline void load(rtx x, rtx y)
{
  fprintf(asm_out_file, "	ldr	");
  arm_print_operand(asm_out_file, x, 0);
  fprintf(asm_out_file, " , ");
  arm_print_operand(asm_out_file, y, 0);
  fprintf(asm_out_file, "\n");
}

const char* arm_addsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y)) {
    if (CONST_INT_P(z))
      return "add	%0, %1, #%2";
  }

  int offy, offz;
  if (REG_P(x) && fp_rel(y, &offy) && fp_rel(z, &offz)) {
    load(x, y);
    auto r2 = gen_rtx_REG(SImode, R2_REGNUM);
    load(r2, z);
    return "add	%0, %0, r2";
  }
  
  return "%0 := %1 + %2";
}

const char* arm_subsi3(rtx x, rtx y, rtx z)
{
  if (REG_P(x) && REG_P(y)) {
    if (CONST_INT_P(z))
      return "sub	%0, %1, #%2";
  }
  return "%0 := %1 - %2";
}

std::string local_label()
{
  using namespace std;
  static int cnt;
  ostringstream os;
  os << ".M" << cnt++;
  return os.str();
}

const char* arm_movsi(rtx x, rtx y)
{
  using namespace std;
  int offset;
  if (fp_rel(x, &offset) && REG_P(y))
    return "str	%1, %0";

  if (REG_P(x) && SYMBOL_REF_P(y)) {
    auto label = local_label();
    sym_ref[label] = y;
    fprintf(asm_out_file, "	ldr	");
    arm_print_operand(asm_out_file, x, 0);
    fprintf(asm_out_file, ", %s\n", label.c_str());
    return "";
  }

  if (REG_P(x) && CONST_INT_P(y))
    return "mov	%0, #%1";

  if (REG_P(x) && REG_P(y))
    return "mov	%0, %1";
  
  return "%0 := %1";
}

const char* arm_call_value(rtx x, rtx fun)
{
  (void)x;
  (void)fun;
  if (MEM_P(fun)) {
    auto y = XEXP(fun, 0);
    assert(SYMBOL_REF_P(y));
    auto z = XSTR(y, 0);
    fprintf(asm_out_file, "	bl	%s\n", z);
    assert(REG_P(x) && REGNO(x) == R0_REGNUM);
    return "";
  }
  return "%0 := call %1";
}

const char* arm_cbranch(rtx op)
{
  auto code = GET_CODE(op);
  switch (code) {
  case NE:   return "if %1 != %2 goto %l3";
  case EQ:   return "if %1 == %2 goto %l3";
  case GE:   return "if %1 >= %2 goto %l3";
  case GT:   return "if %1 > %2 goto %l3";
  case LE:   return "if %1 <= %2 goto %l3";
  case LT:   return "if %1 < %2 goto %l3";
  case LTGT: return "if %1 <> %2 goto %l3";
  case GEU:  return "if %1 >=u %2 goto %l3";
  case GTU:  return "if %1 >u %2 goto %l3";
  case LEU:  return "if %1 <=u %2 goto %l3";
  default:
             assert(code == LTU);
	     return "if %1 <u %2 goto %l3";
  }
}
