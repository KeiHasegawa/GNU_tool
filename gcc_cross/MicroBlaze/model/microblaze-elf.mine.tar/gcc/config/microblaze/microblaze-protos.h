#ifndef MICROBLAZE_PROTOS_H
#define MICROBLAZE_PROTOS_H

void microblaze_expand_prologue();
void microblaze_expand_epilogue();
const char* microblaze_movsi(rtx x, rtx y);
const char* microblaze_addsi3(rtx x, rtx y, rtx z);
const char* microblaze_subsi3(rtx x, rtx y, rtx z);
const char* microblaze_call_value(rtx x, rtx func);

const char* microblaze_cbranch(rtx op);

#endif //  MICROBLAZE_PROTOS_H
