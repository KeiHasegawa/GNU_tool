#ifndef OR1K_PROTOS_H
#define OR1K_PROTOS_H

void or1k_expand_prologue();
void or1k_expand_epilogue();
const char* or1k_movsi(rtx x, rtx y);
const char* or1k_addsi3(rtx x, rtx y, rtx z);
const char* or1k_subsi3(rtx x, rtx y, rtx z);
const char* or1k_call_value(rtx x, rtx fun);

const char* or1k_cbranch(rtx op);

#endif //  OR1K_PROTOS_H
