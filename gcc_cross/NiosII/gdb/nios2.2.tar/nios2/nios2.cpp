#include "config.h"
#include "bfd.h"
#include "sim-main.h"
#include "sim-signal.h"
#include <cassert>
#include <map>
#include <list>

extern "C" sim_cia nios2_pc_get(sim_cpu* cpu)
{
  return cpu->pc;
}

extern "C" void nios2_pc_set(sim_cpu* cpu, sim_cia pc)
{
  cpu->pc = pc;
}

extern "C" uint32_t nios2_reg_get_1(sim_cpu* cpu, int rn)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0])
    return cpu->r[rn];
  if (rn == 32)
    return cpu->pc;
  asm("int3");
  return 0;
}

extern "C"
int nios2_reg_get(sim_cpu* cpu, int rn, unsigned char* buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[8];
  } u = { nios2_reg_get_1(cpu, rn) };
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }
  memcpy(buf, &u.c[0], length);
  return length;
}

extern "C" void nios2_reg_set_1(sim_cpu* cpu, int rn, uint32_t v)
{
  assert(rn >= 0);
  if (rn < sizeof cpu->r/sizeof cpu->r[0]) {
    cpu->r[rn] = v;
    return;
  }
  if (rn == 32) {
    cpu->pc = v;
    return;
  }
  asm("int3");
}

extern "C"
int nios2_reg_set(sim_cpu* cpu, int rn, unsigned char *buf, int length)
{
  assert(length == 4);
  union {
    uint32_t i;
    char c[4];
  } u;
  memcpy(&u.c[0], buf, length);  
  int n = 1;
  if (!*(char*)&n) {
    // simulator runs at big endian processor
    std::swap(u.c[0], u.c[7]);
    std::swap(u.c[1], u.c[6]);
    std::swap(u.c[2], u.c[5]);
    std::swap(u.c[3], u.c[4]);
  }

  nios2_reg_set_1(cpu, rn, u.i);
  return length;
}

typedef void (*FUNC)(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		     sim_cia cia);

static void call(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto IMM26 = insn >> 6;
  cpu->r[31] = cpu->pc + 4;
  cpu->pc = (cpu->pc & 0xf0000000) | (IMM26 << 2);
}

static void addi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->r[B] = cpu->r[A] + IMM16;
  cpu->pc += 4;
}

static void stb(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  auto addr = cpu->r[A] + IMM16;
  auto v = cpu->r[B];
  sim_core_write_aligned_1(cpu, cia, write_map, addr, v);
  cpu->pc += 4;
}

static void ldbu(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  auto addr = cpu->r[A] + IMM16;
  auto v = sim_core_read_aligned_1(cpu, cia, write_map, addr);
  cpu->r[B] = v;
  cpu->pc += 4;
}

static void stw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  auto addr = cpu->r[A] + IMM16;
  auto v = cpu->r[B];
  sim_core_write_aligned_4(cpu, cia, write_map, addr, v);
  cpu->pc += 4;
}

static void ldw(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  auto addr = cpu->r[A] + IMM16;
  auto v = sim_core_read_aligned_4(cpu, cia, write_map, addr);
  cpu->r[B] = v;
  cpu->pc += 4;
}

static void andi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto IMM16 = (insn >> 6) & 0xffff;
  cpu->r[B] = cpu->r[A] & IMM16;
  cpu->pc += 4;
}


static void orhi(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto IMM16 = (insn >> 6) & 0xffff;
  cpu->r[B] = cpu->r[A] | (IMM16 << 16);  
  cpu->pc += 4;
}

static void add(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = cpu->r[A] + cpu->r[B];
  cpu->pc += 4;
}

static void sub(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = cpu->r[A] - cpu->r[B];
  cpu->pc += 4;
}

static void srli(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  auto IMM5 = (insn >> 6) & 0x1f;
  cpu->r[C] = ((int32_t)cpu->r[A]) >> IMM5;
  cpu->pc += 4;
}

static void slli(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  auto IMM5 = (insn >> 6) & 0x1f;
  cpu->r[C] = ((int32_t)cpu->r[A]) << IMM5;
  cpu->pc += 4;
}

static void ret(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  cpu->pc = cpu->r[31];
}

static void and_(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = cpu->r[A] & cpu->r[B];
  cpu->pc += 4;
}

static void or_(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = cpu->r[A] | cpu->r[B];
  cpu->pc += 4;
}

static void srl(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = ((int32_t)cpu->r[A]) >> cpu->r[B];
  cpu->pc += 4;
}

static void sll(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto C = (insn >> 17) & 0x1f;
  cpu->r[C] = ((int32_t)cpu->r[A]) << cpu->r[B];
  cpu->pc += 4;
}

static void
op0x3a(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto key = (insn >> 11) & 0x3f;
  switch (key) {
  case 0x05: return ret(sd, cpu, insn, cia);
  case 0x0e: return and_(sd, cpu, insn, cia);
  case 0x12: return slli(sd, cpu, insn, cia);
  case 0x13: return sll(sd, cpu, insn, cia);
  case 0x16: return or_(sd, cpu, insn, cia);
  case 0x1a: return srli(sd, cpu, insn, cia);
  case 0x1b: return srl(sd, cpu, insn, cia);
  case 0x31: return add(sd, cpu, insn, cia);
  case 0x39: return sub(sd, cpu, insn, cia);
  default:
      asm("int3");
  }
}

static void beq(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->pc += 4;
  if (cpu->r[A] == cpu->r[B])
    cpu->pc += IMM16;
}

static void bne(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->pc += 4;
  if (cpu->r[A] != cpu->r[B])
    cpu->pc += IMM16;
}

static void bltu(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->pc += 4;
  if (cpu->r[A] < cpu->r[B])
    cpu->pc += IMM16;
}

static void bgeu(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->pc += 4;
  if (cpu->r[A] >= cpu->r[B])
    cpu->pc += IMM16;
}

static void br(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  cpu->pc += 4;
  cpu->pc += IMM16;
}

static void ori(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  auto IMM16 = (insn >> 6) & 0xffff;
  cpu->r[B] = cpu->r[A] | IMM16;
  cpu->pc += 4;
}

static void
cmpgei(SIM_DESC sd, sim_cpu* cpu, instruction_word insn, sim_cia cia)
{
  auto A = (insn >> 27) & 0x1f;
  auto B = (insn >> 22) & 0x1f;
  int16_t IMM16 = (insn >> 6) & 0xffff;
  if ((int32_t)cpu->r[A] >= (int32_t)IMM16)
    cpu->r[B] = 1;
  else
    cpu->r[B] = 0;
  cpu->pc += 4;
}

struct table_t : std::map<uint8_t, FUNC> {
  table_t()
  {
    (*this)[0x00] = call;
    (*this)[0x03] = ldbu;
    (*this)[0x04] = addi;
    (*this)[0x05] = stb;
    (*this)[0x06] = br;
    (*this)[0x08] = cmpgei;
    (*this)[0x0c] = andi;
    (*this)[0x14] = ori;
    (*this)[0x15] = stw;
    (*this)[0x17] = ldw;
    (*this)[0x1e] = bne;
    (*this)[0x26] = beq;
    (*this)[0x2e] = bgeu;
    (*this)[0x34] = orhi;
    (*this)[0x36] = bltu;
    (*this)[0x3a] = op0x3a;
  }
} table;

extern "C"
void execute_for_me(SIM_DESC sd, sim_cpu* cpu, instruction_word insn,
		    sim_cia cia)
{
  uint8_t key = insn & 0x3f;
  auto p = table.find(key);
  if (p == end(table)) {
    asm("int3");
    sim_engine_halt(sd, cpu, nullptr, cia, sim_stopped, SIM_SIGILL);
  }

  auto fn = p->second;
  fn(sd, cpu, insn, cia);
  cpu->r[0] = 0;
}

void* zalloc(unsigned long size)
{
  return xcalloc (1, size);
}
