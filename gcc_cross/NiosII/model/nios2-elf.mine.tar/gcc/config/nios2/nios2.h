#ifndef NIOS2_H
#define NIOS2_H

#define REGISTER_NAMES      { \
    "zero", "r1", "r2", "r3", "r4", "r5", "r6", "r7", \
    "r8",   "r9", "r10", "r11", "r12", "r13", "r14", "r15", \
    "r16",  "r17", "r18", "r19", "r20", "r21", "r22", "r23", \
    "r24",  "r25", "gp",  "sp",  "fp",  "r29", "r30", "ra", \
    "dummy" }

#define ZERO_REGNUM           0
#define GP_REGNUM             26
#define STACK_POINTER_REGNUM  27
#define FRAME_POINTER_REGNUM  28
#define ARG_POINTER_REGNUM    FRAME_POINTER_REGNUM
#define RA_REGNUM             31
#define DUMMY_REGNUM          32
#define FIRST_PSEUDO_REGISTER 33

#define FIXED_REGISTERS     { \
    1, 1, 0, 1, 0, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1 }

#define CALL_USED_REGISTERS     { \
    0, 1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1, 1, 1, 1, 1, 1, 1, 1, \
    1 }

enum reg_class {
  NO_REGS, SPECIAL_REGS,
  GENERAL_REGS, ALL_REGS, LIM_REG_CLASSES
};

#define REG_CLASS_NAMES \
  { "NO_REGS", "SPECIAL_REGS" }

#define REG_CLASS_CONTENTS \
/* NO_REGS */      {{ 0x00000000, 0x0 }, \
/* SPECIAL_REGS */  { 0x9c000001, 0x1 }, \
/* GENERAL_REGS */  { 0x63fffffe, 0x0 }, \
/* ALL_REGS */      { 0xffffffff, 0x1 }}

#define N_REG_CLASSES (int)LIM_REG_CLASSES

#define UNITS_PER_WORD 4

typedef int CUMULATIVE_ARGS;
void nios2_init_cumulative_args(CUMULATIVE_ARGS*, tree, rtx, tree, int);
#define INIT_CUMULATIVE_ARGS(CUM, FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS) \
nios2_init_cumulative_args (&(CUM), FNTYPE, LIBNAME, FNDECL, N_NAMED_ARGS)

#define MOVE_MAX 4

#define STRICT_ALIGNMENT 1
#define BITS_BIG_ENDIAN  0
#define BYTES_BIG_ENDIAN 0
#define WORDS_BIG_ENDIAN 0

#define FUNCTION_BOUNDARY 4

#define TRAMPOLINE_SIZE 4

#define TARGET_CPU_CPP_BUILTINS() builtin_define_std("nios2")

#define BIGGEST_ALIGNMENT 8

#define ATTRIBUTE_ALIGNED_VALUE 16

#define Pmode SImode

#define MAX_REGS_PER_ADDRESS 1

extern int FUNCTION_ARG_REGNO_P(int regno);

#define ELIMINABLE_REGS { {FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM} }

extern int nios2_initial_elimination_offset(int, int);
#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET) \
  (OFFSET) = nios2_initial_elimination_offset(FROM, TO)

#define STACK_BOUNDARY 8

#define PARM_BOUNDARY  8

#define FUNCTION_MODE QImode

#define BASE_REG_CLASS SPECIAL_REGS

extern int REGNO_OK_FOR_BASE_P(int);

extern enum reg_class REGNO_REG_CLASS(int);

#define SLOW_BYTE_ACCESS 0

#define ASM_OUTPUT_ALIGN(FILE, N) fprintf(FILE, "	.align	%d\n", N ? 1 << N : 0)

extern int FIRST_PARM_OFFSET(tree);

#define CASE_VECTOR_MODE Pmode

#define ASM_APP_ON "; Begin inline assembler code\n#APP\n"

#define ASM_APP_OFF "; End of inline assembler code\n#NO_APP\n"

#define FUNCTION_PROFILER(FILE, LABELNO) \
  do { fprintf(FILE, "	ldy	.LP%d\n", LABELNO); \
  fprintf(FILE, "	jsr mcount\n"); } while (0)

extern int REGNO_OK_FOR_INDEX_P(int);

#define INDEX_REG_CLASS SPECIAL_REGS

#define DEFAULT_SIGNED_CHAR 0

#define TEXT_SECTION_ASM_OP  "\t.text"
#define DATA_SECTION_ASM_OP  "\t.sdata"
#define BSS_SECTION_ASM_OP   "\t.sbss"

#define STACK_GROWS_DOWNWARD 1
#define FRAME_GROWS_DOWNWARD 1

#define INCOMING_RETURN_ADDR_RTX gen_rtx_REG(Pmode, RA_REGNUM)

#endif // NIOS2_H
